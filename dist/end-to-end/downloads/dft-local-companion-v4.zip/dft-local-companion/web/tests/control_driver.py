"""Manufactured protocol controls only; never scientific evidence."""
from pathlib import Path
import argparse
import hashlib
import json
import os

p=argparse.ArgumentParser()
p.add_argument('--mode',default='normal')
p.add_argument('--out',required=True)
p.add_argument('--source')
a=p.parse_args()
out=Path(a.out);out.mkdir()
payload=out/'CONTROL.json'
payload.write_text(json.dumps({'manufactured_protocol_control':True,'mathematical_proof':False})+'\n',encoding='utf8')
all_claims=['native_dft_executed','raw_source_intake','construction_rounding_enclosed','infinite_basis_tail_enclosed','infinite_orbital_nonlinear_scf_root_enclosed','same_potential_infinite_global_gap']
claims=all_claims if a.mode in ('all-claims','received-full') else ['raw_source_intake']
r={'schema':'dft-portal-stage-receipt.v1','run_id':os.environ['DFT_PORTAL_RUN_ID'],
   'source_fingerprint':os.environ['DFT_PORTAL_SOURCE_FINGERPRINT'],
   'status':'ACCEPTED','reexecution':'fresh_compute','claims':claims,
   'artifacts':[{'path':'CONTROL.json','bytes':payload.stat().st_size,'sha256':hashlib.sha256(payload.read_bytes()).hexdigest()}],
   'scope':'Manufactured protocol control only; no DFT or mathematical claim.'}
if a.mode=='stale':r['run_id']='old-run'
if a.mode=='wrong-source':r['source_fingerprint']='0'*64
if a.mode=='unresolved':r.update(status='UNRESOLVED',claims=[],reason='Manufactured unresolved control')
if a.mode=='inflated':r['claims']=['infinite_orbital_nonlinear_scf_root_enclosed']
if a.mode=='bad-mode':r['reexecution']='old-status-label'
if a.mode=='received-full':r['reexecution']='received_proof_composition'
if a.mode=='changed-input':Path(a.source).write_text('changed',encoding='utf8')
(out/'stage-receipt.json').write_text(json.dumps(r)+'\n',encoding='utf8')
if a.mode=='tamper':payload.write_text('tampered',encoding='utf8')
print('Manufactured protocol control executed; no scientific proof.')
raise SystemExit(7 if a.mode=='nonzero' else 0)
