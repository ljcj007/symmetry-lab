# 本机 DFT 实际作业入口

这个入口启动已登记的真实计算和科学接收器。每次运行建立新任务，保存实际阶段、日志、源身份和接收结果。进程退出与数学证明分别记录；尚缺的证明会保留为 `UNRESOLVED`。

双击 `start.cmd` 打开本机页面。连接已有服务器的配置使用 `start_server.cmd`：密码只在本机启动进程中读取，并传给实际 SSH 驱动；网页没有密码字段，运行记录不保存环境变量。自动调用可使用进程环境 `DFT_SSH_PASSWORD`，或 `portal.py --ssh-password-stdin`。不要把密码写入配置或命令行参数。

服务仅监听 `127.0.0.1:4329`。启动器打开的临时本机地址包含本次页面访问能力；页面立即将其从地址栏移入当前会话。公开网站可以链接启动说明和已有 Si 科学结果，不能通过静态网页直接持有 SSH 凭据或执行本机程序。

## 两类计算案例

- **源接收案例**只运行原生文件结构/完整 NC 因子接收。普通 QE/VASP XML 的元数据接收不等于完整算符证明；VASP PAW 算符尚无接收器时明确返回未完成。
- **服务器原生计算与参考模型链**依据配置运行新 SCF，或明确接收已有 SCF 父源，再实际运行 QE Γ 和完整 72 点非自洽导出任务，下载原始输出，并独立比较新旧算符的全部物理字段、坐标与求积权重。确切算符桥通过后，四片并行重新执行全部 72 点的 Arb 因子构造/舍入接收；随后实际重算 72 点汇总、完整逆矩阵和有限参考 Banach 接收，并组成同势无限冻结谱。逐点响应矩阵和 925 域证明按固定身份接收，不冒充重算。无限轨道非线性自洽根需要独立接收器，缺少时停在该环节。

参考模型仍是指定 80 Ry 载体、48³ 电荷网格、规范 12³ k 求积、理想晶体几何和指定 C¹/PBE 方程。连续网格/BZ 积分极限与全局基态不包含在本机入口的完成标签中。

## 登记实际案例

登记从本机命令行执行，网页只能选择已登记的标识，不能提交任意程序或参数。

```text
python -B register_native.py --id my-qe-source --label "QE 原生源接收" --engine qe --mode intake --chain source --source-root <paper内的实际源目录> --inputs-json <显式相对文件数组JSON>
```

服务器原生计算与参考链使用 `--mode ssh-run --chain reference`。`--source-root` 指向含非秘密服务器配置的目录；`--inputs-json` 必须显式包含该配置，`--ssh-config` 是配置相对文件名。新 SCF 配置须同时显式提供 `scfInput`、`scfExecutable`；可选 `scfExecutableSha256` 提前锁定程序。此模式先从原子初猜求解全新数值 SCF，保留原始/规范化输入、UPF、日志、前后源清单和完整新 `.save`；其输出成为本次 Γ/72 点非自洽导出的唯一父源。未设此对字段时，界面明确表示接收已有 SCF 父源。`native_scf_executed` 只表示新数值 SCF 的执行和源接收，不能替代严格有限或无限根证明。新算符与旧参考不恒等时，保留实际原始源并停止旧证明继承。

配置和已有科学源须已安装在本机，程序不会以模板数值填补缺项。程序或依赖改变后须显式新登记；旧配置与运行保留。

本机 `profiles/`、`jobs/`、`qa/` 是配置及研究记录，不是公开网页资源。发布下载包时只使用明确的代码/静态资源清单；排除实际服务器配置、IP、主机钥匙、绝对私有路径、所有真实运行目录和任何环境变量。

## 阶段收据合同

程序使用参数数组启动，不经过 shell。每阶段得到新的输出目录及以下进程环境：`DFT_PORTAL_RUN_ID`、`DFT_PORTAL_SOURCE_FINGERPRINT`、`DFT_PORTAL_OUTPUT_DIR`、`DFT_PORTAL_JOB_ROOT`。源指纹是以下对象的规范 UTF-8 JSON 的 SHA-256：

```text
{"engine":"qe","files":[{"path":"相对源目录的POSIX文件名","bytes":实际大小,"sha256":"实际摘要"}, ...]}
```

文件按路径排序，JSON 使用 `sort_keys=True,separators=(',',':'),ensure_ascii=False`。输入逐文件流式哈希，并在执行期间及最终重新检查。

阶段必须新写 `stage-receipt.json`，字段为：

```text
schema: "dft-portal-stage-receipt.v1"
run_id: 当前任务ID
source_fingerprint: 当前源指纹
status: "ACCEPTED" | "UNRESOLVED" | "REJECTED"
reexecution: "fresh_compute" | "received_proof_composition"
claims: 受控科学范围字符串数组
artifacts: [{path: 本阶段输出内相对路径, bytes: 大小, sha256: 摘要}, ...]
```

接收器要求新任务身份、正确源、实际输出工件及登记范围全部匹配。非零进程退出不能接收 `ACCEPTED`；缺失、陈旧、错源、超范围或已被改变的收据均停止。受控范围包括原生执行、完整源接收、算符身份、构造舍入、基组尾项、有限 SCF、无限轨道非线性 SCF 和同势无限全域谱。标签只说明登记驱动实际接收的命题；它不是另一份独立数学证明或敌意主机认证。

`runner.py` 的全链标签还要求全部必要范围齐备、本次实际执行模式匹配，且控制夹具永不能形成材料全链证书。原生计算失败、阶段不可用及科学未决分别保留。

## 检查

```text
python -B tests/test_portal.py
```

这会实际启动协议控制子进程与临时本机 HTTP 服务，检查实际执行、日志/报告、访问边界、陈旧/错源收据、工件篡改、非零退出、输入改变、缺失阶段及控制夹具范围。所有输出保存在新的 `qa/` 目录，明确标为制造的协议控制；它们不是材料计算或数学证明。

每次真实材料运行的 `jobs/<id>/RUN.json`、`events.jsonl`、`PROFILE.json`、`SOURCE.json`、阶段日志及实际科学收据共同构成该次执行记录。网页会轮询这些实际记录，不使用模拟进度。
