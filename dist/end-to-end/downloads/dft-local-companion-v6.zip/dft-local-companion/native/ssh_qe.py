"""Bounded, host-key-pinned SSH transport for fresh QE jobs. No secrets stored."""
from pathlib import Path, PurePosixPath
import datetime
import hashlib
import json
import os
import shlex
import socket
import stat
import sys
import time
import uuid

EXPECTED_EXE = '01231dac5b3157f98397ef7eb72bb3d3c1ca730a220bbf1e833c3d0dcfa94770'
EXPECTED_TEMPLATE = 'bd9d920345132b56e0de1f3dc13bac3d6c33b43cc9e5bd7e58ff66483e224f98'
SCRIPT_NAMES = ('fresh_native_remote.py','fresh_scf_remote_v1.py','receive_fresh_remote.py','raw_dft.py','qe_native_adapter.py')
MAX_JSON = 32 * 1024**2


def require(value, reason):
    if not value:
        raise ValueError(reason)


def remote_absolute(value):
    require(isinstance(value,str) and value.startswith('/') and '\\' not in value and '\x00' not in value, 'An absolute Linux path is required')
    path = PurePosixPath(value)
    require('..' not in path.parts and path.as_posix() == value, 'Remote path must be canonical')
    return path


def relative_name(value):
    require(isinstance(value,str) and value and '\\' not in value and ':' not in value, 'Canonical remote relative filename required')
    path = PurePosixPath(value)
    require(not path.is_absolute() and '..' not in path.parts and path.as_posix() == value, 'Remote download path escapes the job')
    return path


def validate_config(value):
    allowed = {'schema','host','user','port','expectedHostKey','hostKeyType','executable','template','serverroot','parentSave','reference72Local','scfInput','scfExecutable','scfExecutableSha256'}
    required = {'schema','host','user','expectedHostKey','executable','template','serverroot','parentSave'}
    require(isinstance(value,dict) and required <= value.keys() and not (value.keys()-allowed), 'SSH config needs only approved non-secret fields')
    require(value['schema']=='native-QE-SSH-profile.v1','Unsupported non-secret SSH profile schema')
    require(all(isinstance(value[k],str) and value[k] for k in ('host','user')), 'Host and username required')
    require(all(c not in value['host']+value['user'] for c in '\r\n\x00'), 'Invalid SSH address')
    require(isinstance(value.get('port',22),int) and 1 <= value.get('port',22) <= 65535, 'Invalid SSH port')
    key = value['expectedHostKey']
    require(isinstance(key,str) and len(key)==64 and all(c in '0123456789abcdef' for c in key), 'expectedHostKey must be the exact lowercase hexadecimal SSH key SHA-256')
    if 'hostKeyType' in value:
        require(isinstance(value['hostKeyType'],str) and value['hostKeyType'] and
                all(c.isalnum() or c in '-_@.' for c in value['hostKeyType']), 'Invalid pinned SSH key algorithm')
    for field in ('executable','template','serverroot','parentSave'):
        remote_absolute(value[field])
    require(('scfInput' in value)==('scfExecutable' in value), 'Fresh SCF requires paired scfInput and scfExecutable paths')
    for field in ('scfInput','scfExecutable'):
        if field in value: remote_absolute(value[field])
    if 'scfExecutableSha256' in value:
        v=value['scfExecutableSha256']
        require('scfExecutable' in value and isinstance(v,str) and len(v)==64 and all(c in '0123456789abcdef' for c in v), 'Invalid pinned SCF executable SHA-256')
    require(value['template'] == value['serverroot']+'/native72_input_v1.in', 'Only the pinned native72 template is supported')
    return value


def select_pinned_key_algorithm(transport, key_type):
    if key_type is None:
        return
    options=transport.get_security_options()
    require(key_type in options.key_types, 'Pinned SSH key algorithm is unavailable in this runtime')
    options.key_types=(key_type,)


def read_remote_json(sftp, path):
    meta = sftp.lstat(str(path))
    require(stat.S_ISREG(meta.st_mode) and 0 < meta.st_size <= MAX_JSON, 'Remote JSON is not a bounded regular file')
    with sftp.open(str(path),'rb') as stream:
        raw = stream.read(MAX_JSON+1)
    require(len(raw)==meta.st_size, 'Remote JSON size changed')
    return json.loads(raw.decode('utf8'))


def remote_command(transport, command, out, label, timeout):
    channel = transport.open_session(timeout=30)
    channel.settimeout(1)
    channel.exec_command(command)
    stdout, stderr = bytearray(),bytearray()
    deadline = time.monotonic()+timeout
    try:
        while True:
            if channel.recv_ready():
                stdout.extend(channel.recv(65536))
            if channel.recv_stderr_ready():
                stderr.extend(channel.recv_stderr(65536))
            require(len(stdout)+len(stderr) <= 8*1024**2, 'Remote command log size limit exceeded')
            if channel.exit_status_ready() and not channel.recv_ready() and not channel.recv_stderr_ready():
                break
            require(time.monotonic()<deadline, 'Remote command exceeded its wall budget')
            time.sleep(.05)
        rc = channel.recv_exit_status()
    finally:
        channel.close()
        (out/(label+'.stdout')).write_bytes(stdout)
        (out/(label+'.stderr')).write_bytes(stderr)
    require(rc==0, 'Remote '+label+' failed; inspect retained logs')
    return stdout.decode('utf8')


def download(sftp, remote_root, name, local_root, expected=None, limit=128*1024**2):
    rel = relative_name(name)
    remote = remote_root/rel
    meta = sftp.lstat(str(remote))
    require(stat.S_ISREG(meta.st_mode) and 0 <= meta.st_size <= limit, 'Download must be a bounded regular file: '+name)
    local = local_root/Path(*rel.parts)
    local.parent.mkdir(parents=True,exist_ok=True)
    digest = hashlib.sha256()
    count = 0
    with sftp.open(str(remote),'rb') as source, local.open('xb') as target:
        while True:
            block = source.read(1024**2)
            if not block:
                break
            count += len(block)
            require(count <= limit, 'Download grew beyond its size limit')
            target.write(block)
            digest.update(block)
    receipt = {'bytes':count,'sha256':digest.hexdigest()}
    require(count==meta.st_size, 'Download changed size in transit')
    require(expected is None or receipt==expected, 'Downloaded file does not match the executed source receipt: '+name)
    return receipt



def scf_snapshot(transport, remote_container, config, out, label, save=None):
    """Read the actual SCF program/input/UPF identities through the pinned host."""
    code = ("import importlib.util,json,sys;from pathlib import Path;"
            "p=Path(sys.argv[1]);sp=importlib.util.spec_from_file_location('scf_worker',p);m=importlib.util.module_from_spec(sp);sp.loader.exec_module(m);"
            "source={'input':m.pin(sys.argv[2]),'executable':m.pin(sys.argv[3]),'pseudopotentials':m.inventory(Path(sys.argv[4])),'worker':m.pin(p)};"
            "result={'source':source};"
            "save=Path(sys.argv[5]) if len(sys.argv)>5 else None;"
            "result.update({'save':m.inventory(save),'execution_inputs':{k:m.pin(save.parent.parent/k) for k in json.loads((save.parent.parent/'INPUT_SOURCE.json').read_text())}}) if save else None;"
            "print(json.dumps(result,sort_keys=True))")
    argv=['python3','-B','-c',code,str(remote_container/'fresh_scf_remote_v1.py'),config['scfInput'],config['scfExecutable'],config['serverroot']+'/pseudo_v1']
    if save is not None: argv.append(str(save))
    result=json.loads(remote_command(transport,' '.join(shlex.quote(v) for v in argv),out,label,60))
    require(isinstance(result.get('source'),dict) and result['source'].get('pseudopotentials'), 'SCF prelaunch source is incomplete')
    if 'scfExecutableSha256' in config:
        require(result['source']['executable']['sha256']==config['scfExecutableSha256'], 'SCF executable differs from the explicit configured identity')
    return result


def receive_scf(sftp, transport, remote_container, remote_job, config, out, source_record, batch, prelaunch, uploaded, api):
    """Receive every SCF execution input and save file, then recheck the source."""
    binding=source_record.get('fresh_scf')
    require(isinstance(binding,dict) and binding.get('worker')==uploaded['fresh_scf_remote_v1.py'], 'Batch does not bind the uploaded fresh SCF worker')
    remote=remote_job/'scf_fresh'
    local=out/'scf_fresh'
    result=read_remote_json(sftp,remote/'RESULTS.json')
    before=read_remote_json(sftp,remote/'SOURCE_BEFORE.json')
    after=read_remote_json(sftp,remote/'SOURCE_AFTER.json')
    inputs=read_remote_json(sftp,remote/'INPUT_SOURCE.json')
    require(result==batch.get('fresh_scf') and batch.get('parent_mode')=='fresh_scf', 'Batch SCF result differs from its actual fresh source')
    require(result.get('status')=='NATIVE_SCF_EXECUTED' and result.get('returncode')==0 and result.get('numerical_convergence') is True and result.get('source_unchanged') is True and result.get('execution_inputs_unchanged') is True, 'Fresh SCF numerical execution was not received')
    require(before==after==prelaunch['source'], 'SCF input, executable, UPF or worker source changed across execution')
    require(binding.get('save')==result.get('save') and isinstance(result.get('save'),dict) and 0<len(result['save'])<=512, 'Fresh SCF save inventory is incomplete or differs from the bound parent')
    require('charge-density.dat' in result['save'] and 'data-file-schema.xml' in result['save'], 'Fresh SCF charge/XML source is absent')
    require(isinstance(inputs,dict) and 0<len(inputs)<=512, 'Fresh SCF input manifest is invalid')
    expected=dict(inputs)
    expected.update({'SOURCE_BEFORE.json':binding['source_before'],'SOURCE_AFTER.json':binding['source_after'],'INPUT_SOURCE.json':binding['input_manifest'],'RESULTS.json':binding['result'],'scf.stdout':result['stdout'],'scf.stderr':result['stderr']})
    expected.update({'out/si.save/'+name:pin for name,pin in result['save'].items()})
    require(expected.get('input-original.in')==before['input'], 'Original SCF input bytes were not retained')
    transferred={}
    for name,pin in sorted(expected.items()):
        transferred[name]=download(sftp,remote,name,local,pin)
    require(api.source_inventory('qe',local,list(inputs))['manifest']['files'], 'SCF execution source inventory is empty')
    for name,pin in result['save'].items():
        require(api.pin(local/'out/si.save'/name)==pin, 'Downloaded fresh parent save differs')
    for name,key in [('scf-driver.stdout','driver_stdout'),('scf-driver.stderr','driver_stderr')]:
        transferred['batch/'+name]=download(sftp,remote_job,name,out/'remote-batch',binding[key],limit=MAX_JSON)
    snapshot=scf_snapshot(transport,remote_container,config,out,'scf-directory-after-download',remote/'out/si.save')
    require(snapshot['source']==before and snapshot.get('save')==result['save'] and snapshot.get('execution_inputs')==inputs, 'Complete SCF source directory changed after execution or during transfer')
    api.write(out/'SCF_SOURCE_RECEIVED.json',{'schema':'fresh-SCF-complete-source-reception.v1','status':'NATIVE_SCF_EXECUTED','prelaunch_source':prelaunch,'source_before':before,'source_after':after,'postdownload_source':snapshot,'downloaded_files':transferred,'native_scf_executed':True,'strict_SCF_root_certified':False})
    return {'received':True,'source':before,'save':result['save'],'downloaded_files':transferred,'numerical_execution_only':True}


def stop_job(transport, remote_job, pid, out):
    # Only terminate the process group launched by this run, after matching its
    # own command line and session leadership. Never kill an unrelated PID.
    code = "import os,signal; p="+str(int(pid))+"; expected="+repr(str(remote_job))+"; cmd=open('/proc/%d/cmdline'%p,'rb').read().decode(); assert expected in cmd and 'fresh_native_remote.py' in cmd and os.getpgid(p)==p; os.killpg(p,signal.SIGTERM)"
    return remote_command(transport,'python3 -c '+shlex.quote(code),out,'timeout-stop',20)


def run(args, out, api):
    root,names,profile_source = api.source_context(args)
    require(args.engine=='qe' and args.ssh_config is not None, 'QE SSH stage needs --ssh-config')
    config_path = args.ssh_config.resolve()
    require(config_path in [api.safe_relative(root,name) for name in names], 'Non-secret SSH config must occur in the explicit input manifest')
    config = validate_config(json.loads(config_path.read_text(encoding='utf8')))
    password = sys.stdin.readline().rstrip('\r\n') if args.password_stdin else os.environ.get('DFT_SSH_PASSWORD')
    require(password, 'Server authentication is absent; start the companion with its in-memory SSH password input')
    import paramiko
    started = time.monotonic()
    deadline = started+args.timeout
    transport,sftp,sock = None,None,None
    remote_job,pid = None,None
    run_tag = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:12]
    serverroot = remote_absolute(config['serverroot'])
    remote_container = serverroot/('portal_native_'+run_tag)
    try:
        sock = socket.create_connection((config['host'],config.get('port',22)),timeout=30)
        transport = paramiko.Transport(sock)
        select_pinned_key_algorithm(transport,config.get('hostKeyType'))
        transport.start_client(timeout=30)
        remote_key=transport.get_remote_server_key()
        observed = hashlib.sha256(remote_key.asbytes()).hexdigest()
        api.write(out/'HOST_KEY_CHECK.json',{'observed_key_type':remote_key.get_name(),
                  'requested_key_type':config.get('hostKeyType'),
                  'observed_sha256':observed,'expected_sha256':config['expectedHostKey'],
                  'matches':observed==config['expectedHostKey']})
        require(observed==config['expectedHostKey'], 'SSH host key differs from the explicitly pinned server identity')
        try:
            transport.auth_password(config['user'],password,fallback=False)
        except Exception:
            raise ValueError('SSH authentication failed') from None
        finally:
            password = None
        sftp = paramiko.SFTPClient.from_transport(transport)
        sftp.get_channel().settimeout(30)
        build = read_remote_json(sftp,serverroot/'qe_private_v1/BUILD_V2_RESULT.json')
        require(build.get('returncode')==0 and build.get('executable')==config['executable'] and build.get('executable_sha256')==EXPECTED_EXE, 'Remote executable build record differs from the pinned profile')
        sftp.mkdir(str(remote_container))
        uploaded = {}
        for name in SCRIPT_NAMES:
            data = (api.HERE/name).read_bytes()
            remote_path = remote_container/name
            with sftp.open(str(remote_path),'wx') as target:
                target.write(data)
            uploaded[name] = {'bytes':len(data),'sha256':hashlib.sha256(data).hexdigest()}
        remote_job = remote_container/'run'
        fresh_scf_requested='scfInput' in config
        prelaunch=scf_snapshot(transport,remote_container,config,out,'scf-prelaunch-source') if fresh_scf_requested else None
        if prelaunch is not None:
            require(prelaunch['source']['worker']==uploaded['fresh_scf_remote_v1.py'], 'Prelaunch SCF worker differs from uploaded source')
            api.write(out/'SCF_PRELAUNCH_SOURCE.json',prelaunch)
        launch_argv=['python3','-B',str(remote_container/'fresh_native_remote.py'),'--root',str(serverroot),'--parent-save',config['parentSave'],'--out',str(remote_job),'--launch']
        if fresh_scf_requested:
            launch_argv+=['--fresh-scf-input',config['scfInput'],'--fresh-scf-executable',config['scfExecutable']]
        command = ' '.join(shlex.quote(v) for v in launch_argv)
        launch = json.loads(remote_command(transport,command,out,'ssh-launch',45))
        require(launch['status']=='LAUNCHED' and launch['out']==str(remote_job), 'Remote launcher returned a different run identity')
        pid = int(launch['pid'])
        api.write(out/'SSH_RUN.json',{'schema':'host-key-pinned-fresh-QE-SSH.v1','host':config['host'],'user':config['user'],'port':config.get('port',22),'observed_host_key_sha256':observed,'remote_job':str(remote_job),'pid':pid,'uploaded_programs':uploaded,'profile_source':profile_source,'credentials_stored':False,'host_key_scope':'Pinned transport endpoint; no hostile-host attestation.'})
        with (out/'ssh-progress.stdout').open('x',encoding='utf8') as progress:
            while True:
                require(time.monotonic()<deadline, 'Fresh remote QE batch exceeded the total wall budget')
                try:
                    failure = read_remote_json(sftp,remote_job/'FAILURE.json')
                except FileNotFoundError:
                    failure = None
                if failure is not None:
                    api.write(out/'REMOTE_FAILURE.json',failure)
                    raise ValueError('Fresh remote QE failed; the remote failure record is retained')
                try:
                    batch = read_remote_json(sftp,remote_job/'RESULTS.json')
                    break
                except FileNotFoundError:
                    progress.write(json.dumps({'elapsed_seconds':round(time.monotonic()-started,1),'status':'RUNNING_FRESH_QE'})+'\n')
                    progress.flush()
                    time.sleep(2)
        require(batch.get('status')=='NATIVE_DFT_EXECUTED' and batch.get('parent_unchanged') is True, 'Remote batch has no complete successful native execution receipt')
        remote_receipts = remote_container/'receipts'
        command = ' '.join(shlex.quote(v) for v in ['python3','-B',str(remote_container/'receive_fresh_remote.py'),'--fresh-run',str(remote_job),'--reference72',str(serverroot/'native72_v1'),'--out',str(remote_receipts)])
        # A changed source legitimately returns 3. Preserve that result and
        # continue the finite-source intake without inheriting its old proof.
        try:
            remote_command(transport,command,out,'ssh-receive',min(360,max(1,deadline-time.monotonic())))
        except ValueError:
            remote_summary = read_remote_json(sftp,remote_receipts/'RESULTS.json')
            require(remote_summary.get('status')=='UNRESOLVED_CHANGED_OPERATOR_SOURCE','Remote scientific receiver failed')
        source_record=read_remote_json(sftp,remote_job/'SOURCE.json')
        scf_received=receive_scf(sftp,transport,remote_container,remote_job,config,out,source_record,batch,prelaunch,uploaded,api) if fresh_scf_requested else None
        require(fresh_scf_requested or batch.get('parent_mode')=='received_existing_scf', 'Unexpected inherited parent mode')
        localjobs = out/'job'
        localjobs.mkdir()
        transfer = {}
        local_intakes = {}
        for name in ('gamma_fresh','native72_fresh'):
            remote = remote_job/name
            local = localjobs/name
            local.mkdir()
            inputs = read_remote_json(sftp,remote/'INTAKE_INPUTS.json')
            report = read_remote_json(sftp,remote/'RUN.json')
            require(report.get('status')=='NATIVE_DFT_EXECUTED' and report.get('returncode')==0 and report.get('program_unchanged') and report.get('parent_unchanged'),'Incomplete native job receipt')
            require(len(inputs)<=128 and isinstance(inputs,list),'Bounded explicit native download list required')
            original_inputs = read_remote_json(sftp,remote/'INPUT_SOURCE.json')
            if scf_received is not None:
                for filename in ('charge-density.dat','data-file-schema.xml'):
                    require(original_inputs.get('out/si.save/'+filename)==scf_received['save'][filename], 'NSCF input did not use this run fresh SCF parent source')
            expected_exports = report['exports']
            require(len(expected_exports)==(1 if name=='gamma_fresh' else 72),'Fresh export point count differs')
            file_names = sorted(set(inputs+['RUN.json','INPUT_SOURCE.json','INTAKE_INPUTS.json','native.stdout','native.stderr']+(['out/si.save/charge-density.dat'] if scf_received is not None else [])))
            for filename in file_names:
                require(time.monotonic()<deadline,'Fresh remote QE transfer exceeded the total wall budget')
                expected = expected_exports.get(filename)
                if filename=='out/si.save/charge-density.dat': expected=original_inputs[filename]
                if filename in ('native.stdout','native.stderr'):
                    expected = report['stdout' if filename=='native.stdout' else 'stderr']
                transfer[name+'/'+filename] = download(sftp,remote,filename,local,expected)
            require(json.loads((local/'RUN.json').read_text())==report,'Native run receipt changed during transfer')
            require(json.loads((local/'INPUT_SOURCE.json').read_text())==original_inputs,'Native execution input manifest changed during transfer')
            for filename in inputs:
                if filename=='pw.in' or filename.startswith('pseudo/'):
                    require(filename in original_inputs and api.pin(local/filename)==original_inputs[filename],'Actual QE input or UPF differs from its pre-execution source pin')
            source = api.source_inventory('qe',local,inputs)
            inspection = api.inspect_native(local,inputs)
            require(source==api.source_inventory('qe',local,inputs),'Downloaded native source changed during local reception')
            local_intakes[name] = {'source':source,'inspection':inspection}
        for filename in ('SOURCE.json','PARENT_BEFORE.json','PARENT_AFTER.json','RESULTS.json','LAUNCH.json','worker.stdout','worker.stderr'):
            transfer['batch/'+filename] = download(sftp,remote_job,filename,out/'remote-batch',limit=MAX_JSON)
        require(json.loads((out/'remote-batch/SOURCE.json').read_text())==source_record,'Batch source binding changed during transfer')
        require(source_record['worker']==uploaded['fresh_native_remote.py'] and source_record['program']['sha256']==EXPECTED_EXE and source_record['template']['sha256']==EXPECTED_TEMPLATE,'Remote worker, executable or template identity differs from the uploaded pinned program')
        before_parent = json.loads((out/'remote-batch/PARENT_BEFORE.json').read_text())
        after_parent = json.loads((out/'remote-batch/PARENT_AFTER.json').read_text())
        require(before_parent==after_parent,'Preserved parent source inventory actually changed')
        if scf_received is not None:
            require(before_parent==scf_received['save'],'NSCF batch parent differs from the complete received fresh SCF save')
        for folder in ('gamma_fresh_intake','native72_fresh_intake','native72_exact_bridge'):
            for filename in ('RESULTS.json','stage-receipt.json'):
                key = folder+'/'+filename
                transfer['receipts/'+key] = download(sftp,remote_receipts,key,out/'remote-receipts',limit=MAX_JSON)
        # Recompute the source bridge locally from the actual downloaded native
        # factors and the preserved local source. Remote status alone is unused.
        local_reference = Path(config.get('reference72Local',str(api.HERE.parent.parent/'qe_si_end_to_end_20261117/root/native72_v1'))).resolve()
        require(local_reference.is_relative_to(api.HERE.parents[2]), 'Preserved local science reference must stay inside paper')
        comparisons = []
        if local_reference.is_dir():
            reference_names = ['pw.in']+sorted(p.name for p in local_reference.glob('ncs_native_k*.bin'))
            reference_source = api.source_inventory('qe',local_reference,reference_names)
            previous = api.inspect_native(local_reference,reference_names)
            comparisons = api.compare_native_inspections(local_intakes['native72_fresh']['inspection'],previous)
            require(reference_source==api.source_inventory('qe',local_reference,reference_names),'Preserved reference changed during local bridge reception')
        else:
            reference_source = None
        bridge = bool(comparisons) and all(row['operator_source_identical'] for row in comparisons)
        require(profile_source==api.source_inventory('qe',root,names),'SSH profile source changed during execution')
        result = {'schema':'fresh-remote-QE-and-local-source-reception.v1','status':'NATIVE_DFT_EXECUTED','source':profile_source,'remote_job':str(remote_job),'executable_sha256':EXPECTED_EXE,'native_process_execution_completed':True,'native_scf_executed':scf_received is not None,'fresh_scf_source':scf_received,'parent_mode':batch.get('parent_mode'),'downloaded_files':transfer,'local_intakes':local_intakes,'reference_source':reference_source,'exact_operator_bridge':{'received':bridge,'points':comparisons},'seconds':time.monotonic()-started,'transport_programs':{name:api.pin(api.HERE/name) for name in ('ssh_qe.py',)+SCRIPT_NAMES},'scientific_claims':{'complete_finite_NC_operator_source':True,'exact_operator_identity_bridge':bridge,'old_proofs_automatically_inherited':False,'infinite_orbital_nonlinear_SCF':False,'infinite_frozen_spectrum':False}}
        api.write(out/'RESULTS.json',result)
        claims = ['native_dft_executed','raw_source_intake']+(['native_scf_executed'] if scf_received is not None else [])+(['operator_identity_bridge'] if bridge else [])
        api.stage_receipt(out,profile_source['fingerprint'],'ACCEPTED',claims)
        return 0
    except Exception:
        if remote_job is not None and sftp is not None:
            for name in ('worker.stdout','worker.stderr','FAILURE.json'):
                try:
                    download(sftp,remote_job,name,out/'remote-failure-logs',limit=MAX_JSON)
                except Exception:
                    pass
        if time.monotonic()>=deadline and pid is not None and transport is not None:
            try:
                stop_job(transport,remote_job,pid,out)
            except Exception:
                pass
        raise
    finally:
        password = None
        if sftp is not None:
            sftp.close()
        if transport is not None:
            transport.close()
        if sock is not None:
            sock.close()
