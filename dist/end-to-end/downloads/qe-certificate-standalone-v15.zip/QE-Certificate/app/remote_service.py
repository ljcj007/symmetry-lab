"""SSH transport for the separately installed, source-bound QE certificate service.

Passwords are carried in memory and an SSH stdin stream only. This module never
constructs shell commands containing credentials and never logs exception text.
SPDX-License-Identifier: GPL-3.0-or-later
"""
from __future__ import annotations

import datetime
import io
import json
import os
from pathlib import Path, PurePosixPath
import shlex
import stat
import time
import uuid
import zipfile


class ServiceError(RuntimeError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def load_json(sftp, path):
    with sftp.open(str(path), 'rb') as stream:
        data = stream.read(16 * 1024 * 1024 + 1)
    if len(data) > 16 * 1024 * 1024:
        raise ServiceError('INVALID_SERVICE', '服务器返回的运行记录过大。')
    return json.loads(data.decode('utf-8-sig'))


def write_request(sftp, path, value):
    # Paramiko's 'x' sets CREATE|EXCL but does not imply WRITE. 'wx' is both
    # writable and exclusive. Read back the closed file before starting QE.
    with sftp.open(str(path), 'wx') as stream:
        stream.write(json.dumps(value, ensure_ascii=False))
    if load_json(sftp, path) != value:
        raise ServiceError('REQUEST_UPLOAD', '服务器没有完整接收本次运行请求。')


def absolute_remote(value):
    if not isinstance(value, str) or not value.startswith('/') or '\n' in value or '\r' in value:
        raise ServiceError('INVALID_SERVICE', '服务器的运行服务设置不完整。')
    path = PurePosixPath(value)
    if '..' in path.parts:
        raise ServiceError('INVALID_SERVICE', '服务器的运行服务设置不完整。')
    return path


def inside_remote(root, value):
    path = absolute_remote(value)
    if not path.is_relative_to(root):
        raise ServiceError('INVALID_SERVICE', '服务器返回了运行目录以外的文件。')
    return path


def safe_extract(archive, destination):
    """Extract only regular files under a fresh result directory."""
    destination = Path(destination).resolve()
    with zipfile.ZipFile(archive) as z:
        if len(z.infolist()) > 100000 or sum(row.file_size for row in z.infolist()) > 12 * 1024**3:
            raise ServiceError('INVALID_RESULTS', '服务器结果包超出支持的大小。')
        seen = set()
        for info in z.infolist():
            name = PurePosixPath(info.filename)
            mode = (info.external_attr >> 16) & 0o170000
            normalized = name.as_posix().rstrip('/').casefold()
            if (name.is_absolute() or '..' in name.parts or ':' in info.filename
                    or '\\' in info.filename or mode not in (0, stat.S_IFREG, stat.S_IFDIR)
                    or normalized in seen):
                raise ServiceError('INVALID_RESULTS', '服务器结果包包含无效路径。')
            seen.add(normalized)
        z.extractall(destination)


def connect(request, known_hosts):
    import paramiko

    host = str(request.get('host', '')).strip()
    user = str(request.get('user', '')).strip()
    password = request.get('password', '')
    try:
        port = int(request.get('port', 22))
    except (TypeError, ValueError):
        raise ServiceError('CONNECTION_FIELDS', '请填写有效的服务器端口。')
    if not host or not user or not 1 <= port <= 65535 or not password:
        raise ServiceError('CONNECTION_FIELDS', '请填写服务器地址、用户名和密码。')
    known_hosts = Path(known_hosts)
    known_hosts.parent.mkdir(parents=True, exist_ok=True)
    client = paramiko.SSHClient()
    if known_hosts.is_file():
        client.load_host_keys(str(known_hosts))
    # First connection records the server key automatically. Changed keys fail.
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(hostname=host, username=user, port=port, password=password,
                       allow_agent=False, look_for_keys=False, timeout=20,
                       auth_timeout=30, banner_timeout=30)
        client.save_host_keys(str(known_hosts))
        client.get_transport().set_keepalive(15)
        return client
    except paramiko.BadHostKeyException:
        client.close()
        raise ServiceError('SERVER_CHANGED', '服务器身份与上次连接不同，连接已停止。') from None
    except paramiko.AuthenticationException:
        client.close()
        raise ServiceError('AUTH_FAILED', '服务器登录失败，请检查用户名和密码。') from None
    except Exception:
        client.close()
        raise ServiceError('CONNECTION_FAILED', '暂时无法连接服务器，请检查地址和网络。') from None


def run(request, result_directory, state_directory, on_event=lambda event: None,
        poll_seconds=3, max_seconds=10800):
    """Run one fresh server job and download the resulting certificate bundle."""
    request.setdefault('port', 22)
    result_directory = Path(result_directory).resolve()
    result_directory.mkdir(parents=True, exist_ok=False)
    client = None
    sftp = None
    password = request.pop('password', '')
    started = time.monotonic()
    try:
        on_event({'event': 'progress', 'message': '正在连接计算服务器…'})
        client = connect(dict(request, password=password), Path(state_directory)/'known_hosts')
        sftp = client.open_sftp()
        home = absolute_remote(sftp.normalize('.'))
        manifest = load_json(sftp, home/'.local/share/qe-certificate/server.json')
        if manifest.get('schema') != 'qe-certificate-server.v1':
            raise ServiceError('SERVICE_NOT_INSTALLED', '这台服务器尚未安装完整的 QE 证书运行服务。')
        root = absolute_remote(manifest.get('root'))
        python = absolute_remote(manifest.get('python'))
        entry = inside_remote(root, manifest.get('entry'))
        safe_request = {
            'schema': 'qe-certificate-request.v1',
            'connection': {key: request[key] for key in ('host', 'user', 'port')},
        }
        if request.get('resume_output'):
            output = inside_remote(root/'runs', request['resume_output'])
            if output.name != 'output':
                raise ServiceError('INVALID_SERVICE', '上次任务的连接记录无效。')
            sftp.stat(str(output))
            run_id = output.parent.name
            on_event({'event': 'progress', 'message': '正在重新连接上次任务；不会重新提交 QE 计算。'})
        else:
            run_id = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dt%H%M%S-') + uuid.uuid4().hex[:12]
            run_root = root/'runs'/run_id
            sftp.mkdir(str(run_root))
            request_path = run_root/'REQUEST.json'
            output = run_root/'output'
            safe_request['id'] = run_id
            write_request(sftp, request_path, safe_request)
            command = ' '.join(shlex.quote(str(x)) for x in
                               (python, entry, 'start', '--request', request_path, '--out', output))
            stdin, stdout, stderr = client.exec_command(command, timeout=60)
            stdin.write(json.dumps({'password': password})+'\n')
            stdin.flush()
            stdin.channel.shutdown_write()
            # Server start returns after a detached worker has accepted its stdin.
            stdout.channel.settimeout(60)
            response = stdout.read(65537)
            error = stderr.read(65537)
            code = stdout.channel.recv_exit_status()
            stdin.close(); stdout.close(); stderr.close()
            if code != 0:
                raise ServiceError('START_FAILED', '服务器未能启动新任务，请查看服务器运行服务。')
            del response, error
        password = None
        safe_request['id'] = run_id
        on_event({'event': 'started', 'run_id': run_id, 'remote_output': str(output),
                  'result_directory': str(result_directory)})
        local_status = result_directory/'connection.json'
        local_status.write_text(json.dumps(dict(safe_request, remote_output=str(output)),
                                          ensure_ascii=False, indent=2)+'\n', encoding='utf8')
        last = None
        while True:
            if time.monotonic()-started > max_seconds:
                raise ServiceError('WAIT_TIMEOUT', '等待已结束；服务器任务会继续，连接记录已保存在结果目录。')
            try:
                service = load_json(sftp, output/'service.json')
            except FileNotFoundError:
                time.sleep(poll_seconds)
                continue
            status = service.get('status')
            state = None
            if service.get('run_json'):
                run_json = inside_remote(root, service['run_json'])
                try:
                    state = load_json(sftp, run_json)
                except FileNotFoundError:
                    pass
            progress = {'event': 'progress', 'status': status,
                        'stages': [{key: row.get(key) for key in ('id', 'label', 'state')}
                                   for row in (state or {}).get('stages', [])]}
            if progress != last:
                on_event(progress)
                last = progress
            if status in ('SUCCEEDED', 'PARTIAL', 'FAILED', 'ERROR', 'UNRESOLVED'):
                certified = service.get('full_chain_certified') is True
                archive_path = service.get('result_zip')
                if archive_path:
                    remote_archive = inside_remote(output, archive_path)
                    on_event({'event': 'progress', 'message': '计算已结束，正在取回证书和运行记录…'})
                    local_archive = result_directory/'QE-certificate-results.zip'
                    sftp.get(str(remote_archive), str(local_archive))
                    safe_extract(local_archive, result_directory/'results')
                public_result = dict(schema='qe-certificate-client-result.v1', run_id=run_id,
                                     status=status, full_chain_certified=certified,
                                     full_chain_recomputed=service.get('full_chain_recomputed') is True,
                                     elapsed_seconds=round(time.monotonic()-started, 3),
                                     result_directory=str(result_directory))
                (result_directory/'RESULT.json').write_text(json.dumps(public_result, ensure_ascii=False,
                                                                       indent=2)+'\n', encoding='utf8')
                on_event(dict(public_result, event='finished'))
                return 0 if status == 'SUCCEEDED' and certified else 2
            time.sleep(poll_seconds)
    except ServiceError:
        raise
    except (FileNotFoundError, OSError):
        raise ServiceError('SERVICE_IO', '无法读取服务器运行服务或取回结果，请检查服务器配置。') from None
    except Exception:
        raise ServiceError('SERVICE_FAILED', '服务器任务未完成，已有连接记录保存在结果目录。') from None
    finally:
        password = None
        request.pop('password', None)
        if sftp:
            sftp.close()
        if client:
            client.close()
