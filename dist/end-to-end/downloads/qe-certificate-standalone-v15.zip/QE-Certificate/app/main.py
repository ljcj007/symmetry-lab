"""Portable desktop entry for QE to infinite-orbital SCF certificates.
SPDX-License-Identifier: GPL-3.0-or-later
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import uuid

# GUI workers use an explicitly UTF-8 JSON pipe even on a Windows host whose
# default console code page is cp936. pythonw may not have standard streams.
for _stream in (sys.stdin, sys.stdout, sys.stderr):
    if _stream is not None and hasattr(_stream, 'reconfigure'):
        _stream.reconfigure(encoding='utf-8')

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
STATE = ROOT/'Settings'
RESULTS = ROOT/'Results'
os.environ['TCL_LIBRARY'] = str(ROOT/'runtime/tcl/tcl8.6')
os.environ['TK_LIBRARY'] = str(ROOT/'runtime/tcl/tk8.6')
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
if hasattr(sys, 'set_int_max_str_digits'):
    sys.set_int_max_str_digits(0)


def emit(event):
    if sys.stdout is not None:
        print(json.dumps(event, ensure_ascii=False), flush=True)


def load_settings():
    try:
        value = json.loads((STATE/'connection.json').read_text(encoding='utf8'))
        return {key: value[key] for key in ('host', 'user', 'port') if key in value}
    except (OSError, ValueError, TypeError):
        return {}


def save_settings(request):
    STATE.mkdir(parents=True, exist_ok=True)
    (STATE/'connection.json').write_text(json.dumps({key: request[key] for key in ('host', 'user', 'port')},
                                                   ensure_ascii=False, indent=2)+'\n', encoding='utf8')


def load_last_job():
    try:
        value = json.loads((STATE/'last-job.json').read_text(encoding='utf8'))
        return {key: value[key] for key in ('host', 'user', 'port', 'remote_output')}
    except (OSError, ValueError, KeyError, TypeError):
        return None


def diagnose(smoke_tk=False):
    import importlib
    modules = ('ssl', 'tkinter', 'paramiko', 'cryptography', 'bcrypt', 'nacl', 'cffi', 'invoke')
    origins = {name: str(Path(importlib.import_module(name).__file__).resolve()) for name in modules}
    result = dict(schema='qe-certificate-portable-diagnostics.v1', python=sys.version.split()[0],
                  executable=str(Path(sys.executable).resolve()), modules=origins,
                  all_modules_inside_bundle=all(Path(path).is_relative_to(ROOT) for path in origins.values()),
                  sys_path=list(sys.path), local_project_required=False,
                  external_python_required=False)
    import tkinter
    tcl = tkinter.Tcl()
    result['tcl_library'] = tcl.eval('info library')
    result['tcl_version'] = tcl.eval('info patchlevel')
    if smoke_tk:
        window = tkinter.Tk()
        window.withdraw()
        window.title('QE 独立运行')
        window.update_idletasks()
        result['tk_version'] = window.tk.eval('package present Tk')
        window.destroy()
    return result


def worker(out):
    from remote_service import ServiceError, run
    request = None
    try:
        request = json.loads(sys.stdin.readline())
        return run(request, out, STATE, on_event=emit)
    except ServiceError as exc:
        emit(dict(event='error', code=exc.code, message=str(exc)))
        return 2
    except Exception:
        emit(dict(event='error', code='REQUEST_FAILED', message='无法启动本次任务，请检查连接信息。'))
        return 2
    finally:
        if isinstance(request, dict):
            request.pop('password', None)


def execute(request, out, callback):
    environment = os.environ.copy()
    for key in ('DFT_SSH_PASSWORD', 'PYTHONPATH', 'PYTHONHOME'):
        environment.pop(key, None)
    command = [str(ROOT/'runtime/python.exe'), '-I', '-X', 'utf8', '-B', str(HERE/'main.py'),
               '--headless-run', '--result-directory', str(out)]
    flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    try:
        child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=subprocess.DEVNULL, text=True, encoding='utf8',
                                 env=environment, creationflags=flags)
    except Exception:
        request.pop('password', None)
        callback(dict(event='error', code='START_FAILED', message='程序的运行环境不完整，请重新解压完整下载包。'))
        return 2
    child.stdin.write(json.dumps(request, ensure_ascii=False)+'\n')
    child.stdin.close()
    request.pop('password', None)
    terminal = False
    for line in child.stdout:
        try:
            event = json.loads(line)
            if event.get('event') in ('progress', 'started', 'finished', 'error'):
                terminal = terminal or event['event'] in ('finished', 'error')
                callback(event)
        except (ValueError, AttributeError):
            continue
    child.stdout.close()
    code = child.wait()
    if not terminal:
        callback(dict(event='error', code='STOPPED', message='程序已停止，已有记录保存在结果目录。'))
    return code


def gui():
    import tkinter as tk
    from tkinter import messagebox, ttk

    window = tk.Tk()
    window.title('QE 独立运行')
    window.geometry('740x670')
    window.minsize(690, 620)
    window.configure(background='#f3f8f6')
    style = ttk.Style()
    style.theme_use('clam')
    style.configure('TFrame', background='#f3f8f6')
    style.configure('TLabel', background='#f3f8f6', foreground='#243d3a', font=('Microsoft YaHei UI', 11))
    style.configure('Title.TLabel', font=('Microsoft YaHei UI', 22, 'bold'), foreground='#103e39')
    style.configure('Start.TButton', font=('Microsoft YaHei UI', 13, 'bold'), padding=11)
    frame = ttk.Frame(window, padding=28)
    frame.pack(fill='both', expand=True)
    ttk.Label(frame, text='从 QE 计算到最终证书', style='Title.TLabel').pack(anchor='w')
    ttk.Label(frame, text='连接已部署证书服务的服务器，自动计算、验证并取回结果。',
              wraplength=660).pack(anchor='w', pady=(8, 20))
    fields = ttk.Frame(frame)
    fields.pack(fill='x')
    fields.columnconfigure(1, weight=1)
    saved = load_settings()
    host = tk.StringVar(value=str(saved.get('host', '')))
    user = tk.StringVar(value=str(saved.get('user', '')))
    port = tk.StringVar(value=str(saved.get('port', 22)))
    password = tk.StringVar()
    entries = []
    for row, (label, value) in enumerate((('服务器地址', host), ('用户名', user), ('端口', port), ('密码', password))):
        ttk.Label(fields, text=label).grid(row=row, column=0, sticky='w', padx=(0, 18), pady=5)
        entry = ttk.Entry(fields, textvariable=value, show='●' if label == '密码' else '', font=('Microsoft YaHei UI', 11))
        entry.grid(row=row, column=1, sticky='ew', pady=5)
        entries.append(entry)
    ttk.Label(frame, text='密码仅用于本次连接；程序会记住地址和用户名。',
              font=('Microsoft YaHei UI', 9)).pack(anchor='w', pady=(9, 15))
    progress = ttk.Progressbar(frame, mode='indeterminate')
    progress.pack(fill='x')
    status = tk.StringVar(value='准备就绪。无需安装 Python，也无需原有 paper 文件夹。')
    ttk.Label(frame, textvariable=status, wraplength=650).pack(anchor='w', pady=(12, 7))
    stages = tk.StringVar(value='① 全新 QE 自洽计算与原生输出\n② 原始输入势及算符衔接\n③ 无限轨道自洽与完整响应证书')
    ttk.Label(frame, textvariable=stages, wraplength=650, justify='left').pack(anchor='w', pady=(0, 14))
    actions = ttk.Frame(frame)
    actions.pack(fill='x')
    start = ttk.Button(actions, text='连接并开始运行', style='Start.TButton')
    start.pack(side='left')
    last_job = [load_last_job()]
    resume_button = ttk.Button(actions, text='继续上次任务', state='normal' if last_job[0] else 'disabled')
    resume_button.pack(side='left', padx=(14, 0))
    open_button = ttk.Button(actions, text='打开结果文件夹', state='disabled')
    open_button.pack(side='left', padx=14)
    ttk.Label(frame, text='当前完整流程：固定 Si / QE 模型、72 点和无限轨道空间。\n大型证明在服务器接收，最终存在性和完整响应闭合在本次任务重新运行。',
              wraplength=650, font=('Microsoft YaHei UI', 9)).pack(anchor='w', pady=(18, 0))
    events = queue.Queue()
    running = [False]
    current_out = [None]
    running_connection = [None]

    def open_results():
        if current_out[0] and current_out[0].is_dir():
            os.startfile(str(current_out[0]))

    def begin(resume=False):
        if running[0]:
            return
        try:
            port_number = int(port.get())
            if not host.get().strip() or not user.get().strip() or not password.get() or not 1 <= port_number <= 65535:
                raise ValueError()
        except ValueError:
            messagebox.showinfo('连接信息', '请填写服务器地址、用户名、有效端口和密码。', parent=window)
            return
        request = dict(host=host.get().strip(), user=user.get().strip(), port=port_number, password=password.get())
        if resume:
            previous = last_job[0]
            if not previous or any(request[key] != previous[key] for key in ('host', 'user', 'port')):
                messagebox.showinfo('继续上次任务', '请填写上次任务使用的服务器地址、用户名和端口。', parent=window)
                return
            request['resume_output'] = previous['remote_output']
        password.set('')
        save_settings(request)
        running_connection[0] = {key: request[key] for key in ('host', 'user', 'port')}
        stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S-')+uuid.uuid4().hex[:8]
        current_out[0] = RESULTS/stamp
        RESULTS.mkdir(parents=True, exist_ok=True)
        running[0] = True
        start.configure(state='disabled')
        resume_button.configure(state='disabled')
        for entry in entries:
            entry.configure(state='disabled')
        progress.start(15)
        status.set('正在连接计算服务器…')
        stages.set('等待服务器启动新的完整流程。')
        threading.Thread(target=execute, args=(request, current_out[0], events.put), daemon=True).start()

    def receive():
        try:
            while True:
                event = events.get_nowait()
                if event['event'] == 'progress':
                    if event.get('message'):
                        status.set(event['message'])
                    rows = event.get('stages')
                    if rows:
                        labels = {'SUCCEEDED': '完成', 'RUNNING': '运行中', 'FAILED': '未完成', 'QUEUED': '等待'}
                        stages.set('\n'.join(f"{labels.get(row.get('state'), '等待')}  ·  {row.get('label') or row['id']}" for row in rows))
                elif event['event'] == 'started':
                    status.set('服务器正在执行新的 QE 至证书流程，完成后会自动取回结果。')
                    open_button.configure(state='normal')
                    last_job[0] = dict(running_connection[0], remote_output=event['remote_output'])
                    (STATE/'last-job.json').write_text(json.dumps(last_job[0], ensure_ascii=False, indent=2)+'\n', encoding='utf8')
                elif event['event'] in ('finished', 'error'):
                    running[0] = False
                    progress.stop()
                    start.configure(state='normal')
                    resume_button.configure(state='normal' if last_job[0] else 'disabled')
                    for entry in entries:
                        entry.configure(state='normal')
                    open_button.configure(state='normal' if current_out[0].is_dir() else 'disabled')
                    if event['event'] == 'error':
                        status.set(event['message'])
                    elif event.get('full_chain_certified'):
                        status.set('运行完成：无限轨道自洽存在性和完整响应证书已通过，结果已保存。')
                    else:
                        status.set('本次运行未获得完整证书，请打开结果文件夹查看运行记录。')
        except queue.Empty:
            pass
        window.after(180, receive)

    def close():
        if running[0]:
            messagebox.showinfo('任务正在运行', '服务器任务正在运行。请等待结果取回后再关闭程序。', parent=window)
            return
        window.destroy()

    start.configure(command=begin)
    resume_button.configure(command=lambda: begin(resume=True))
    open_button.configure(command=open_results)
    window.protocol('WM_DELETE_WINDOW', close)
    entries[0].focus_set()
    receive()
    window.mainloop()


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--headless-run', action='store_true')
    parser.add_argument('--result-directory', type=Path)
    parser.add_argument('--diagnose', action='store_true')
    parser.add_argument('--smoke-tk', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if args.diagnose:
        result = diagnose(args.smoke_tk)
        if args.report:
            args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
        emit(result)
        return 0
    if args.headless_run:
        if args.result_directory is None:
            parser.error('--result-directory is required')
        return worker(args.result_directory)
    gui()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
