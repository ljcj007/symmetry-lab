"""Offline client protocol controls; no installed SSH package or server needed."""
import io
import json
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import remote_service as client


class WriteFile(io.StringIO):
    def __init__(self, owner, path):
        super().__init__()
        self.owner, self.path = owner, path

    def close(self):
        if not self.closed:
            self.owner.saved[self.path] = self.getvalue()
        super().close()


class ReadOnlyCreate(WriteFile):
    def write(self, value):
        raise PermissionError('Paramiko x mode has no WRITE flag')


class FakeSFTP:
    def __init__(self):
        self.saved = {}
        self.run_root = '/srv/cert/runs/existing'
        self.closed = False
        self.modes = []

    def normalize(self, path):
        return '/home/test'

    def mkdir(self, path):
        self.run_root = path

    def stat(self, path):
        return object()

    def open(self, path, mode):
        self.modes.append((path, mode))
        if mode == 'wx':
            return WriteFile(self, path)
        if mode == 'x':
            return ReadOnlyCreate(self, path)
        if path in self.saved:
            return io.BytesIO(self.saved[path].encode('utf8'))
        if path.endswith('/server.json'):
            value = dict(schema='qe-certificate-server.v1', root='/srv/cert',
                         python='/opt/python/bin/python', entry='/srv/cert/service.py')
        elif path.endswith('/service.json'):
            value = dict(status='SUCCEEDED', full_chain_certified=True, full_chain_recomputed=False,
                         run_json='/srv/cert/science/web/jobs/one/RUN.json',
                         result_zip=self.run_root+'/output/results.zip')
        elif path.endswith('/RUN.json'):
            value = dict(stages=[dict(id='native-dft', label='QE', state='SUCCEEDED')])
        else:
            raise FileNotFoundError(path)
        return io.BytesIO(json.dumps(value).encode())

    def get(self, remote, local):
        with zipfile.ZipFile(local, 'w') as z:
            z.writestr('certificate/RESULTS.json', '{"root_exists":true}')

    def close(self):
        self.closed = True


class FakeChannel:
    def shutdown_write(self): pass
    def settimeout(self, value): pass
    def recv_exit_status(self): return 0


class FakeStream(io.BytesIO):
    def __init__(self):
        super().__init__(b'{}')
        self.channel = FakeChannel()


class FakeInput(io.StringIO):
    def __init__(self, owner):
        super().__init__()
        self.owner = owner
        self.channel = FakeChannel()

    def close(self):
        if not self.closed:
            self.owner.stdin_data = self.getvalue()
        super().close()


class FakeSSH:
    def __init__(self):
        self.sftp = FakeSFTP()
        self.commands = []
        self.stdin_data = None

    def open_sftp(self): return self.sftp
    def exec_command(self, command, timeout):
        self.commands.append(command)
        return FakeInput(self), FakeStream(), FakeStream()
    def close(self): pass


class ClientControls(unittest.TestCase):
    def test_fresh_chain_uses_stdin_and_downloads_without_changing_scientific_claims(self):
        ssh = FakeSSH()
        request = dict(host='example.invalid', user='test', port=22, password='one-time-secret-TEST')
        events = []
        with tempfile.TemporaryDirectory() as temp, patch.object(client, 'connect', return_value=ssh):
            out = Path(temp)/'fresh'
            code = client.run(request, out, Path(temp)/'state', events.append, poll_seconds=0)
            self.assertEqual(code, 0)
            self.assertEqual(len(ssh.commands), 1)
            self.assertTrue(any(path.endswith('/REQUEST.json') and mode == 'wx' for path, mode in ssh.sftp.modes))
            self.assertNotIn('one-time-secret', ssh.commands[0])
            self.assertEqual(json.loads(ssh.stdin_data), {'password':'one-time-secret-TEST'})
            self.assertNotIn('password', request)
            self.assertTrue((out/'results/certificate/RESULTS.json').is_file())
            result = json.loads((out/'RESULT.json').read_text())
            self.assertTrue(result['full_chain_certified'])
            self.assertFalse(result['full_chain_recomputed'])
            for path in out.rglob('*'):
                if path.is_file():
                    self.assertNotIn(b'one-time-secret-TEST', path.read_bytes())
            self.assertTrue(events[-1]['full_chain_certified'])

    def test_resume_does_not_start_another_qe_run(self):
        ssh = FakeSSH()
        request = dict(host='example.invalid', user='test', port=22, password='resume-secret',
                       resume_output='/srv/cert/runs/existing/output')
        with tempfile.TemporaryDirectory() as temp, patch.object(client, 'connect', return_value=ssh):
            self.assertEqual(client.run(request, Path(temp)/'resumed', Path(temp)/'state', poll_seconds=0), 0)
            self.assertEqual(ssh.commands, [])
            self.assertEqual(ssh.sftp.saved, {})
            self.assertIsNone(ssh.stdin_data)

    def test_failed_authentication_never_echoes_secret(self):
        request = dict(host='example.invalid', user='test', port=22, password='auth-secret')
        error = client.ServiceError('AUTH_FAILED', '服务器登录失败，请检查用户名和密码。')
        with tempfile.TemporaryDirectory() as temp, patch.object(client, 'connect', side_effect=error):
            with self.assertRaises(client.ServiceError) as caught:
                client.run(request, Path(temp)/'failed', Path(temp)/'state', poll_seconds=0)
            self.assertNotIn('auth-secret', str(caught.exception))
            self.assertNotIn('password', request)

    def test_resume_outside_service_root_is_rejected(self):
        ssh = FakeSSH()
        request = dict(host='example.invalid', user='test', port=22, password='x', resume_output='/tmp/foreign/output')
        with tempfile.TemporaryDirectory() as temp, patch.object(client, 'connect', return_value=ssh):
            with self.assertRaises(client.ServiceError):
                client.run(request, Path(temp)/'failed', Path(temp)/'state')
            self.assertEqual(ssh.commands, [])

    def test_archive_path_escape_duplicate_and_symlink_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            cases = [('escape', [('../outside.txt', b'x')]),
                     ('duplicate', [('file.txt', b'a'), ('FILE.txt', b'b')])]
            for name, members in cases:
                with zipfile.ZipFile(root/(name+'.zip'), 'w') as z:
                    for entry, data in members:
                        z.writestr(entry, data)
                with self.assertRaises(client.ServiceError):
                    client.safe_extract(root/(name+'.zip'), root/name)
            info = zipfile.ZipInfo('link')
            info.external_attr = (stat.S_IFLNK | 0o777) << 16
            with zipfile.ZipFile(root/'symlink.zip', 'w') as z:
                z.writestr(info, 'outside')
            with self.assertRaises(client.ServiceError):
                client.safe_extract(root/'symlink.zip', root/'symlink')
            self.assertFalse((root/'outside.txt').exists())

    def test_remote_absolute_and_scientific_path_guards(self):
        for value in ('../a', 'relative', '/srv/../etc', '/srv/evil\ncommand'):
            with self.assertRaises(client.ServiceError): client.absolute_remote(value)
        self.assertEqual(str(client.inside_remote(client.absolute_remote('/srv/cert'), '/srv/cert/science/RUN.json')),
                         '/srv/cert/science/RUN.json')

    def test_request_upload_mode_really_requires_write_and_is_read_back(self):
        sftp = FakeSFTP()
        with sftp.open('/wrong.json', 'x') as stream:
            with self.assertRaises(PermissionError):
                stream.write('must not succeed')
        self.assertEqual(sftp.saved['/wrong.json'], '')
        request = {'schema':'qe-certificate-request.v1', 'connection':{'user':'中文用户'}}
        client.write_request(sftp, '/correct.json', request)
        self.assertEqual(json.loads(sftp.saved['/correct.json']), request)
        self.assertEqual(sftp.modes[-2:], [('/correct.json','wx'),('/correct.json','rb')])


if __name__ == '__main__':
    unittest.main()
