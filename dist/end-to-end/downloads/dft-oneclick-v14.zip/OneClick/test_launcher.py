"""Manufactured launcher controls; no material calculation is inferred."""
from pathlib import Path
import contextlib
import importlib.util
import json
import os
import subprocess
import sys
import tempfile
import time
import unittest

HERE=Path(__file__).resolve().parent
SCRIPT=HERE/'launcher.py'
spec=importlib.util.spec_from_file_location('tested_oneclick_launcher',SCRIPT)
app=importlib.util.module_from_spec(spec)
sys.modules[spec.name]=app
spec.loader.exec_module(app)
SECRET='control-only-secret-Ω'

FAKE_RUNNER='''from pathlib import Path
import json,os,time,uuid
HERE=Path(__file__).resolve().parent
JOBS=HERE/'jobs'
PROFILES=HERE/'profiles'
def load(p):return json.loads(Path(p).read_text(encoding='utf8'))
def profile_path(i):return PROFILES/(i+'.json')
def create_job(i):
 if os.environ.get('ONECLICK_CONTROL_RAISE'):
  raise ValueError(os.environ.get('DFT_SSH_PASSWORD',''))
 assert bool(os.environ.get('DFT_SSH_PASSWORD'))
 jid=uuid.uuid4().hex
 p=JOBS/jid;p.mkdir(parents=True)
 (p/'RUN.json').write_text(json.dumps(dict(status='RUNNING',secret_present=True,stages=[])),encoding='utf8')
 return jid
def execute(jid):
 if os.environ.get('ONECLICK_CONTROL_SLEEP'):time.sleep(2)
 state=dict(status='COMPLETED',full_chain_certified=True,full_chain_recomputed=False,
            stages=[dict(id=k,state='SUCCEEDED')for k in ('native-dft','ionic-input','infinite-scf')],elapsed_seconds=0.01)
 (JOBS/jid/'RUN.json').write_text(json.dumps(state),encoding='utf8')
 return dict(id=jid,**state)
'''


def fixture(base):
    paper=Path(base)/'paper'
    web=paper/'work/infinite_scf_20261122/web'
    (web/'profiles').mkdir(parents=True)
    (web/'jobs').mkdir()
    (paper/'START_HERE.md').write_text('manufactured control workspace',encoding='utf8')
    (web/'runner.py').write_text(FAKE_RUNNER,encoding='utf8')
    profile=dict(schema='dft-portal-profile.v1',id=app.PREFERRED_PROFILE,engine='qe',
                 full_chain_kind='infinite',python_executable=sys.executable,
                 target_claims=sorted(app.REQUIRED_CLAIMS),requires_server_auth=True,
                 stages=[dict(id=k,program='manufactured.py')for k in ('native-dft','ionic-input','infinite-scf')])
    (web/'profiles'/f'{app.PREFERRED_PROFILE}.json').write_text(json.dumps(profile),encoding='utf8')
    return paper,web


@contextlib.contextmanager
def cwd(path):
    previous=Path.cwd();os.chdir(path)
    try:yield
    finally:os.chdir(previous)


class Controls(unittest.TestCase):
    def setUp(self):
        self.temp=tempfile.TemporaryDirectory(prefix='qe-oneclick-control-')
        self.base=Path(self.temp.name).resolve()
        assert self.base.is_relative_to(Path(tempfile.gettempdir()).resolve())
        assert self.base.name.startswith('qe-oneclick-control-')
    def tearDown(self):
        assert self.base.is_relative_to(Path(tempfile.gettempdir()).resolve())
        assert self.base.name.startswith('qe-oneclick-control-')
        self.temp.cleanup()
    def launch(self,paper,extra=None):
        env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
        env.pop('DFT_SSH_PASSWORD',None)
        env.update(extra or {})
        command=[sys.executable,'-B',str(SCRIPT),'--headless-run','--workspace',str(paper)]
        self.assertNotIn(SECRET,' '.join(command))
        result=subprocess.run(command,input=json.dumps(dict(password=SECRET))+'\n',
                              capture_output=True,text=True,encoding='utf8',timeout=15,env=env)
        self.assertNotIn(SECRET,result.stdout+result.stderr)
        return result
    def test_workspace_and_project_root(self):
        paper,web=fixture(self.base/'project')
        self.assertEqual(app.select_profile(paper).web,web)
        self.assertEqual(app.select_profile(paper.parent).web,web)
    def test_missing_workspace_and_shallow_scan(self):
        (self.base/'home/Downloads/package').mkdir(parents=True)
        fixture(self.base/'home/Videos/a/b/c/project')
        with cwd(self.base/'home/Downloads/package'):
            self.assertIsNone(app.discover_workspace(start=Path.cwd(),home=self.base/'home',max_depth=1))
        self.assertIsNone(app.select_profile(self.base/'missing'))
    def test_unrelated_download_automatic_discovery(self):
        package=self.base/'home/Downloads/package';package.mkdir(parents=True)
        paper,web=fixture(self.base/'home/Videos/a/b/c/project')
        with cwd(package):
            selected=app.discover_workspace(start=package,home=self.base/'home')
        self.assertEqual(selected.paper,paper)
        self.assertEqual(selected.web,web)
    def test_original_registered_runtime_used(self):
        paper,_=fixture(self.base/'project')
        selected=app.select_profile(paper)
        command=app.child_command(selected)
        self.assertEqual(Path(command[0]).resolve(),Path(sys.executable).resolve())
        self.assertIn('--worker',command)
        self.assertNotIn(SECRET,' '.join(command))
    def test_success_child_pipeline_and_no_saved_secret(self):
        paper,web=fixture(self.base/'project')
        result=self.launch(paper)
        self.assertEqual(result.returncode,0,result.stderr+result.stdout)
        events=[json.loads(line)for line in result.stdout.splitlines()]
        self.assertEqual([x['event']for x in events],['started','finished'])
        self.assertTrue(events[-1]['full_chain_certified'])
        self.assertFalse(events[-1]['full_chain_recomputed'])
        for path in paper.rglob('*'):
            if path.is_file():self.assertNotIn(SECRET,path.read_text(encoding='utf8',errors='replace'))
    def test_raw_exception_secret_is_not_emitted(self):
        paper,_=fixture(self.base/'project')
        result=self.launch(paper,{'ONECLICK_CONTROL_RAISE':'1'})
        self.assertEqual(result.returncode,2)
        events=[json.loads(line)for line in result.stdout.splitlines()]
        self.assertEqual(events[-1]['code'],'START_FAILED')
        self.assertNotIn(SECRET,result.stdout+result.stderr)
    def test_existing_active_job_stops_new_job(self):
        paper,web=fixture(self.base/'project')
        old=web/'jobs/existing';old.mkdir()
        (old/'RUN.json').write_text(json.dumps(dict(status='RUNNING')),encoding='utf8')
        result=self.launch(paper)
        self.assertEqual(result.returncode,3)
        self.assertEqual(json.loads(result.stdout)['code'],'BUSY')
        self.assertEqual(len(list((web/'jobs').glob('*/RUN.json'))),1)
    def test_cross_process_double_launch_lock(self):
        paper,web=fixture(self.base/'project')
        env=dict(os.environ,PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1',ONECLICK_CONTROL_SLEEP='1')
        first=subprocess.Popen([sys.executable,'-B',str(SCRIPT),'--headless-run','--workspace',str(paper)],
                               stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,
                               encoding='utf8',env=env)
        first.stdin.write(json.dumps(dict(password=SECRET))+'\n');first.stdin.close()
        deadline=time.monotonic()+5
        while time.monotonic()<deadline and not list((web/'jobs').glob('*/RUN.json')):time.sleep(0.02)
        self.assertTrue(list((web/'jobs').glob('*/RUN.json')))
        second=self.launch(paper)
        self.assertEqual(second.returncode,3)
        self.assertEqual(json.loads(second.stdout)['code'],'BUSY')
        first.wait(timeout=10)
        text=first.stdout.read()+first.stderr.read()
        first.stdout.close();first.stderr.close()
        self.assertNotIn(SECRET,text)
        self.assertEqual(first.returncode,0)
        self.assertEqual(len(list((web/'jobs').glob('*/RUN.json'))),1)


if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(Controls)
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    print(json.dumps(dict(status='PASS'if result.wasSuccessful()else'FAIL',
                          manufactured_controls=result.testsRun,material_certificate_inferred=False)))
    raise SystemExit(0 if result.wasSuccessful()else 1)
