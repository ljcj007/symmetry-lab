"""One-click desktop entry for a complete, previously registered QE workspace."""
from __future__ import annotations

import argparse
from collections import deque
from dataclasses import dataclass
import importlib.util
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import time

PREFERRED_PROFILE = 'qe-si-infinite-complete-r72af'
REQUIRED_CLAIMS = {'native_scf_executed', 'ionic_input_source_bridge_enclosed',
                   'infinite_orbital_nonlinear_scf_root_enclosed',
                   'complete_infinite_scf_response_invertibility_enclosed'}
SKIP_DIRS = {'.git','node_modules','.venv','venv','__pycache__','AppData',
             '_archive_20261118','research','work','runtime','upstream'}


def load(path):
    return json.loads(Path(path).read_text(encoding='utf-8-sig'))


@dataclass(frozen=True)
class Selection:
    paper: Path
    web: Path
    profile_id: str
    python: Path
    requires_password: bool


def select_profile(candidate):
    """Read metadata only. The original runner validates every scientific input."""
    candidate = Path(candidate).expanduser().resolve()
    roots = [candidate, candidate/'paper']
    for paper in roots:
        if not (paper/'START_HERE.md').is_file() or not (paper/'work').is_dir():
            continue
        preferred = paper/'work/infinite_scf_20261122/web/profiles'/f'{PREFERRED_PROFILE}.json'
        profiles = [preferred]
        profiles.extend(sorted((paper/'work').glob('*/web/profiles/*.json')))
        seen = set()
        for path in profiles:
            if path in seen or not path.is_file():
                continue
            seen.add(path)
            try:
                p = load(path)
                web = path.parent.parent
                runtime = Path(p.get('python_executable','')).expanduser()
                if (p.get('schema') != 'dft-portal-profile.v1' or p.get('engine') != 'qe'
                    or p.get('full_chain_kind') != 'infinite'
                    or not REQUIRED_CLAIMS <= set(p.get('target_claims',[]))
                    or not (web/'runner.py').is_file() or not runtime.is_file()
                    or len(p.get('stages',[])) < 3
                    or not all(s.get('program') for s in p.get('stages',[]))):
                    continue
                return Selection(paper,web,p['id'],runtime.resolve(),bool(p.get('requires_server_auth')))
            except (OSError,ValueError,KeyError,TypeError):
                continue
    return None


def discover_workspace(start=None, home=None, max_depth=5, max_nodes=5000):
    """Bounded folder discovery, without opening science arrays or old archives."""
    start = Path(start or __file__).resolve()
    start = start if start.is_dir() else start.parent
    home = Path(home or Path.home()).resolve()
    for path in [start,*list(start.parents)[:10],Path.cwd()]:
        result = select_profile(path)
        if result:
            return result
    folders = [home/name for name in ('Videos','Desktop','Documents','Downloads')]
    pending = deque((p,0) for p in folders if p.is_dir())
    seen = set()
    while pending and len(seen)<max_nodes:
        path,depth = pending.popleft()
        try:
            resolved = path.resolve()
            if resolved in seen:
                continue
            seen.add(resolved)
            result = select_profile(path)
            if result:
                return result
            if depth >= max_depth:
                continue
            children = sorted(path.iterdir(),key=lambda p:p.name.casefold())
            for child in children:
                if child.name not in SKIP_DIRS and not child.name.startswith('.') and child.is_dir() and not child.is_symlink():
                    pending.append((child,depth+1))
        except OSError:
            continue
    return None


class WorkspaceBusy(RuntimeError):
    pass


class RunLock:
    def __init__(self, jobs):
        self.path = Path(jobs)/'.oneclick-run.lock'
        self.handle = None

    def __enter__(self):
        self.path.parent.mkdir(parents=True,exist_ok=True)
        self.handle = self.path.open('a+b')
        if self.path.stat().st_size == 0:
            self.handle.write(b'0'); self.handle.flush()
        self.handle.seek(0)
        try:
            if os.name == 'nt':
                import msvcrt
                msvcrt.locking(self.handle.fileno(),msvcrt.LK_NBLCK,1)
            else:
                import fcntl
                fcntl.flock(self.handle.fileno(),fcntl.LOCK_EX|fcntl.LOCK_NB)
        except OSError:
            self.handle.close(); self.handle=None
            raise WorkspaceBusy('已有任务正在运行，请等待当前任务结束。')
        return self

    def __exit__(self,*_):
        if self.handle:
            self.handle.close()


def ensure_idle(jobs):
    for path in Path(jobs).glob('*/RUN.json'):
        try:
            state=load(path)
            if state.get('status') in ('RUNNING','QUEUED'):
                raise WorkspaceBusy('已有任务正在运行，请等待当前任务结束。')
        except (OSError,ValueError):
            continue


def emit(value):
    try:
        print(json.dumps(value,ensure_ascii=False),flush=True)
    except (BrokenPipeError,OSError):
        pass


def worker(web,profile_id):
    request = json.loads(sys.stdin.readline())
    password = request.pop('password','')
    request.clear()
    web=Path(web).resolve()
    module_path=web/'runner.py'
    spec=importlib.util.spec_from_file_location('oneclick_registered_runner',module_path)
    runner=importlib.util.module_from_spec(spec)
    sys.path.insert(0,str(web))
    spec.loader.exec_module(runner)
    try:
        with RunLock(runner.JOBS):
            ensure_idle(runner.JOBS)
            profile=runner.load(runner.profile_path(profile_id))
            if profile.get('requires_server_auth') and not password:
                raise ValueError('请填写服务器密码。')
            if password:
                os.environ['DFT_SSH_PASSWORD']=password
            password=None
            job_id=runner.create_job(profile_id)
            emit(dict(event='started',job_id=job_id))
            state=runner.execute(job_id)
            emit(dict(event='finished',job_id=job_id,status=state['status'],
                      full_chain_certified=bool(state.get('full_chain_certified')),
                      full_chain_recomputed=bool(state.get('full_chain_recomputed')),
                      elapsed_seconds=state.get('elapsed_seconds')))
            return 0 if state.get('full_chain_certified') else 2
    except WorkspaceBusy:
        emit(dict(event='error',code='BUSY',message='已有任务正在运行，请等待当前任务结束。'))
        return 3
    except Exception:
        emit(dict(event='error',code='START_FAILED',message='暂时无法运行，请确认选择了完整科研工作区。'))
        return 2
    finally:
        password=None
        os.environ.pop('DFT_SSH_PASSWORD',None)


def child_command(selection,script=None):
    return [str(selection.python),'-B',str(Path(script or __file__).resolve()),
            '--worker','--web',str(selection.web),'--profile',selection.profile_id]


def execute(selection,password,callback=emit,script=None):
    """The password travels only in a pipe, never in arguments or saved config."""
    environment=os.environ.copy()
    environment.pop('DFT_SSH_PASSWORD',None)
    environment.update(PYTHONUTF8='1',PYTHONDONTWRITEBYTECODE='1')
    flags=subprocess.CREATE_NO_WINDOW if os.name=='nt' else 0
    child=subprocess.Popen(child_command(selection,script),stdin=subprocess.PIPE,
                           stdout=subprocess.PIPE,stderr=subprocess.DEVNULL,
                           encoding='utf8',env=environment,creationflags=flags)
    child.stdin.write(json.dumps(dict(password=password),ensure_ascii=False)+'\n')
    child.stdin.close()
    password=None
    terminal=False
    for line in child.stdout:
        try:
            event=json.loads(line)
            if isinstance(event,dict) and event.get('event') in ('started','finished','error'):
                terminal=terminal or event['event'] in ('finished','error')
                callback(event)
        except ValueError:
            continue
    child.stdout.close()
    code=child.wait()
    if not terminal:
        callback(dict(event='error',code='WORKER_STOPPED',message='本次运行已停止，请确认科研工作区和运行环境完整。'))
    return code


def gui():
    import tkinter as tk
    from tkinter import filedialog,ttk,messagebox
    window=tk.Tk(); window.title('QE 一键运行'); window.geometry('680x490')
    window.minsize(600,460)
    window.configure(background='#f4f8f7')
    style=ttk.Style(); style.theme_use('clam')
    style.configure('TFrame',background='#f4f8f7')
    style.configure('TLabel',background='#f4f8f7',font=('Microsoft YaHei UI',11))
    style.configure('Title.TLabel',font=('Microsoft YaHei UI',21,'bold'),foreground='#103c3a')
    style.configure('Start.TButton',font=('Microsoft YaHei UI',13,'bold'),padding=11)
    frame=ttk.Frame(window,padding=28); frame.pack(fill='both',expand=True)
    ttk.Label(frame,text='从 QE 到无限轨道自洽证书',style='Title.TLabel').pack(anchor='w')
    ttk.Label(frame,text='自动识别现有工作区，接续计算并保存结果。').pack(anchor='w',pady=(8,20))
    status=tk.StringVar(value='正在寻找现有工作区…')
    ttk.Label(frame,textvariable=status,wraplength=600).pack(anchor='w')
    selection=[None]; current_job=[None]; running=[False]; events=queue.Queue()
    browse_button=ttk.Button(frame,text='选择科研文件夹')
    browse_button.pack(anchor='w',pady=(6,14))
    password_label=ttk.Label(frame,text='服务器密码')
    password_label.pack(anchor='w')
    password=tk.StringVar()
    password_entry=ttk.Entry(frame,textvariable=password,show='●',font=('Microsoft YaHei UI',12))
    password_entry.pack(fill='x',pady=(4,4))
    ttk.Label(frame,text='密码只用于本次连接。',font=('Microsoft YaHei UI',9)).pack(anchor='w')
    start_button=ttk.Button(frame,text='开始运行',style='Start.TButton',state='disabled')
    start_button.pack(fill='x',pady=(18,12))
    progress=ttk.Progressbar(frame,mode='indeterminate'); progress.pack(fill='x')
    stages=tk.StringVar(value='准备 → QE 计算 → 输入势接收 → 无限自洽证书')
    ttk.Label(frame,textvariable=stages,wraplength=600).pack(anchor='w',pady=(10,8))
    result_button=ttk.Button(frame,text='打开本次结果',state='disabled')
    result_button.pack(anchor='w')

    def accept(found):
        selection[0]=found
        if found:
            status.set('已找到完整工作区，可以直接运行。')
            start_button.configure(state='normal')
            password_entry.configure(state='normal' if found.requires_password else 'disabled')
        else:
            status.set('未找到完整工作区。请选择项目文件夹或其中的 paper 文件夹。')
            start_button.configure(state='disabled')

    def browse():
        folder=filedialog.askdirectory(title='选择完整科研工作区（项目或 paper 文件夹）')
        if folder:
            accept(select_profile(folder))

    def start():
        if running[0] or not selection[0]:
            return
        secret=password.get()
        if selection[0].requires_password and not secret:
            status.set('请填写服务器密码，再点击开始运行。'); password_entry.focus_set(); return
        running[0]=True
        password.set(''); password_entry.configure(state='disabled')
        start_button.configure(state='disabled'); browse_button.configure(state='disabled')
        result_button.configure(state='disabled'); progress.start(12)
        status.set('正在启动本次计算…')
        def task():
            try:
                code=execute(selection[0],secret,events.put)
                events.put(dict(event='exited',returncode=code))
            except Exception:
                events.put(dict(event='error',message='启动失败，请确认科研工作区和运行环境完整。'))
                events.put(dict(event='exited',returncode=2))
        threading.Thread(target=task,daemon=True).start()

    def open_result():
        if current_job[0] and os.name=='nt':
            os.startfile(str(selection[0].web/'jobs'/current_job[0]))

    names={'native-dft':'QE 计算','ionic-input':'输入势接收','infinite-scf':'无限自洽证书'}
    state_names={'WAITING':'等待','QUEUED':'等待','RUNNING':'运行中','SUCCEEDED':'完成',
                 'NOT_RUN':'未运行','FAILED':'未完成','UNRESOLVED':'未完成','REJECTED':'未通过'}
    def tick():
        try:
            while True:
                event=events.get_nowait()
                if event['event']=='discovered':
                    accept(event['selection'])
                elif event['event']=='started':
                    current_job[0]=event['job_id']; status.set('正在运行，请保持本窗口打开。')
                    result_button.configure(state='normal')
                elif event['event']=='finished':
                    status.set('运行完成：无限轨道自洽证书与完整响应均通过。' if event.get('full_chain_certified') else '本次运行未获得完整证书，请查看结果。')
                elif event['event']=='error':
                    status.set(event.get('message','本次运行未完成，请查看结果。'))
                elif event['event']=='exited':
                    running[0]=False; progress.stop()
                    browse_button.configure(state='normal'); start_button.configure(state='normal')
                    password_entry.configure(state='normal' if selection[0].requires_password else 'disabled')
        except queue.Empty:
            pass
        if current_job[0] and selection[0]:
            try:
                run=load(selection[0].web/'jobs'/current_job[0]/'RUN.json')
                stages.set('  ·  '.join(names.get(s['id'],s['id'])+'：'+state_names.get(s['state'],s['state']) for s in run['stages']))
            except (OSError,ValueError,KeyError):
                pass
        window.after(500,tick)

    def close():
        if running[0]:
            messagebox.showinfo('任务继续运行','关闭窗口后，已启动的计算仍会继续，结果保存在科研工作区。')
        window.destroy()

    browse_button.configure(command=browse); start_button.configure(command=start)
    result_button.configure(command=open_result); window.protocol('WM_DELETE_WINDOW',close)
    threading.Thread(target=lambda:events.put(dict(event='discovered',selection=discover_workspace())),daemon=True).start()
    window.after(100,tick); window.mainloop()


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--worker',action='store_true')
    parser.add_argument('--web',type=Path)
    parser.add_argument('--profile')
    parser.add_argument('--headless-run',action='store_true')
    parser.add_argument('--workspace',type=Path)
    parser.add_argument('--discover',action='store_true')
    args=parser.parse_args()
    if args.worker:
        return worker(args.web,args.profile)
    if args.headless_run or args.discover:
        selection=select_profile(args.workspace) if args.workspace else discover_workspace()
        if not selection:
            emit(dict(event='error',code='WORKSPACE_MISSING',message='未找到完整科研工作区。'))
            return 2
        if args.discover:
            emit(dict(event='ready',profile_id=selection.profile_id,requires_password=selection.requires_password))
            return 0
        request=json.loads(sys.stdin.readline())
        secret=request.pop('password',''); request.clear()
        return execute(selection,secret)
    gui()
    return 0


if __name__=='__main__':
    raise SystemExit(main())
