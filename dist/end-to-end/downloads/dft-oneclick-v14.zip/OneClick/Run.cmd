@echo off
setlocal EnableExtensions DisableDelayedExpansion
set "PYTHONUTF8=1"
set "PYTHONDONTWRITEBYTECODE=1"
set "DFT_ONECLICK_SCRIPT=%~dp0launcher.py"
set "DFT_ONECLICK_PY="
set "DFT_ONECLICK_FLAGS=-B"
if exist "%USERPROFILE%\miniconda3\pythonw.exe" set "DFT_ONECLICK_PY=%USERPROFILE%\miniconda3\pythonw.exe"
if defined DFT_ONECLICK_PY goto launch
if exist "%USERPROFILE%\anaconda3\pythonw.exe" set "DFT_ONECLICK_PY=%USERPROFILE%\anaconda3\pythonw.exe"
if defined DFT_ONECLICK_PY goto launch
for %%V in (314 313 312 311 310) do if exist "%LOCALAPPDATA%\Programs\Python\Python%%V\pythonw.exe" if not defined DFT_ONECLICK_PY set "DFT_ONECLICK_PY=%LOCALAPPDATA%\Programs\Python\Python%%V\pythonw.exe"
if defined DFT_ONECLICK_PY goto launch
for /f "delims=" %%P in ('where pythonw.exe 2^>nul') do if not defined DFT_ONECLICK_PY set "DFT_ONECLICK_PY=%%P"
if defined DFT_ONECLICK_PY goto launch
for /f "delims=" %%P in ('where pyw.exe 2^>nul') do if not defined DFT_ONECLICK_PY set "DFT_ONECLICK_PY=%%P"
if defined DFT_ONECLICK_PY set "DFT_ONECLICK_FLAGS=-3 -B"
if defined DFT_ONECLICK_PY goto launch
echo Python desktop environment was not found.
echo Open this launcher on the computer with the complete research workspace.
echo This launcher uses the Python environment already installed there.
if defined DFT_ONECLICK_BOOTSTRAP_CHECK exit /b 2
pause
exit /b 2
:launch
if defined DFT_ONECLICK_BOOTSTRAP_CHECK (
  echo ONECLICK_BOOTSTRAP_READY
  exit /b 0
)
start "" "%DFT_ONECLICK_PY%" %DFT_ONECLICK_FLAGS% "%DFT_ONECLICK_SCRIPT%"
exit /b 0
