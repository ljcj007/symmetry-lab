"""Run a fresh Gamma pilot and 72-point QE native export, preserving every source.

Run on the authorized Linux host. --launch detaches this same script; its printed
JSON names the PID, logs, and new output directory. No credentials are accepted.
Native completion is recorded separately from mathematical source acceptance.
"""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import shutil
import subprocess
import sys
import time
import traceback

EXPECTED_EXE = '01231dac5b3157f98397ef7eb72bb3d3c1ca730a220bbf1e833c3d0dcfa94770'
EXPECTED_TEMPLATE = 'bd9d920345132b56e0de1f3dc13bac3d6c33b43cc9e5bd7e58ff66483e224f98'


def pin(path):
    path = Path(path)
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for chunk in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(chunk)
    return {'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


def write(path, obj):
    with Path(path).open('x', encoding='utf8') as stream:
        json.dump(obj, stream, indent=2, sort_keys=True, allow_nan=False)
        stream.write('\n')


def inventory(folder):
    return {p.relative_to(folder).as_posix(): pin(p)
            for p in sorted(folder.rglob('*')) if p.is_file()}


def require(test, reason):
    if not test:
        raise ValueError(reason)


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--root', type=Path, required=True)
    parser.add_argument('--parent-save', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    parser.add_argument('--fresh-scf-input', type=Path)
    parser.add_argument('--fresh-scf-executable', type=Path)
    parser.add_argument('--export-unmixed-input', action='store_true')
    parser.add_argument('--launch', action='store_true')
    parser.add_argument('--worker', action='store_true', help=argparse.SUPPRESS)
    args = parser.parse_args()
    out = args.out.resolve()
    if args.launch:
        require(not out.exists(), 'Output already exists; choose a new run name')
        out.mkdir(parents=True)
        command = [sys.executable, str(Path(__file__).resolve()), '--worker', '--root', str(args.root), '--parent-save', str(args.parent_save), '--out', str(out)]
        if args.fresh_scf_input is not None:
            require(args.fresh_scf_executable is not None, 'Fresh SCF requires an explicit executable')
            command += ['--fresh-scf-input', str(args.fresh_scf_input), '--fresh-scf-executable', str(args.fresh_scf_executable)]
        if args.export_unmixed_input:
            command += ['--export-unmixed-input']
        with (out/'worker.stdout').open('xb') as stdout, (out/'worker.stderr').open('xb') as stderr:
            child = subprocess.Popen(command, stdout=stdout, stderr=stderr, start_new_session=True)
        launch = {'status': 'LAUNCHED', 'pid': child.pid, 'out': str(out), 'command': command}
        write(out/'LAUNCH.json', launch)
        print(json.dumps(launch), flush=True)
        return 0
    if not args.worker:
        require(not out.exists(), 'Output already exists; choose a new run name')
        out.mkdir(parents=True)
    try:
        build = json.loads((args.root/'qe_private_v1/BUILD_V2_RESULT.json').read_text())
        exe = Path(build['executable']).resolve()
        require(build['returncode'] == 0 and pin(exe)['sha256'] == build['executable_sha256'] == EXPECTED_EXE, 'Pinned private QE executable identity differs')
        template_path = args.root/'native72_input_v1.in'
        require(pin(template_path)['sha256'] == EXPECTED_TEMPLATE, 'Pinned 72-point input template differs')
        template = template_path.read_text()
        require(template.count('K_POINTS tpiba') == 1, 'Expected explicit 72-point card')
        import re
        template, count = re.subn(r"pseudo_dir\s*=\s*'[^']*'", "pseudo_dir='./pseudo'", template)
        require(count == 1, 'Expected one pseudopotential path')
        fresh_scf = None
        if args.fresh_scf_input is not None:
            require(args.fresh_scf_executable is not None, 'Fresh SCF requires an explicit executable')
            scf_program = Path(__file__).with_name('fresh_scf_remote_v1.py')
            scf_out = out/'scf_fresh'
            command = [sys.executable, '-B', str(scf_program), '--input', str(args.fresh_scf_input), '--pseudo', str(args.root/'pseudo_v1'), '--executable', str(args.fresh_scf_executable), '--out', str(scf_out)]
            with (out/'scf-driver.stdout').open('xb') as stdout, (out/'scf-driver.stderr').open('xb') as stderr:
                scf_run = subprocess.run(command, stdout=stdout, stderr=stderr, timeout=2500)
            require(scf_run.returncode == 0, 'Fresh SCF failed; inspect retained SCF logs')
            fresh_scf = json.loads((scf_out/'RESULTS.json').read_text())
            require(fresh_scf['status'] == 'NATIVE_SCF_EXECUTED' and fresh_scf['source_unchanged'] and fresh_scf.get('execution_inputs_unchanged') is True, 'Fresh SCF source was not accepted')
            args.parent_save = scf_out/'out/si.save'
        before = inventory(args.parent_save)
        write(out/'PARENT_BEFORE.json', before)
        write(out/'SOURCE.json', {'program': {'path': str(exe), **pin(exe)}, 'parent_save': str(args.parent_save), 'template': {'path': str(template_path), **pin(template_path)}, 'worker': pin(__file__), 'fresh_scf': ({'worker': pin(scf_program), 'source_before': pin(scf_out/'SOURCE_BEFORE.json'), 'source_after': pin(scf_out/'SOURCE_AFTER.json'), 'input_manifest': pin(scf_out/'INPUT_SOURCE.json'), 'result': pin(scf_out/'RESULTS.json'), 'driver_stdout': pin(out/'scf-driver.stdout'), 'driver_stderr': pin(out/'scf-driver.stderr'), 'save': before} if fresh_scf else None), 'scope': 'Fresh finite native scalar NC exports; execution is not spectral or nonlinear SCF certification.'})
        env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
        jobs = []
        for name, points in [('gamma_fresh', 1), ('native72_fresh', 72)]:
            job = out/name
            job.mkdir()
            save = job/'out/si.save'
            save.mkdir(parents=True)
            for src in sorted(args.parent_save.iterdir()):
                if src.is_file() and (src.name in ('charge-density.dat', 'data-file-schema.xml') or src.suffix.lower() == '.upf'):
                    shutil.copy2(src, save/src.name)
            pseudo = job/'pseudo'
            pseudo.mkdir()
            for src in sorted((args.root/'pseudo_v1').iterdir()):
                if src.is_file():
                    shutil.copy2(src, pseudo/src.name)
            text = template if points == 72 else template.split('K_POINTS tpiba')[0] + 'K_POINTS tpiba\n1\n0 0 0 1\n'
            (job/'pw.in').write_text(text)
            input_inventory = inventory(job)
            write(job/'INPUT_SOURCE.json', input_inventory)
            started = time.monotonic()
            timed_out = False
            with (job/'native.stdout').open('xb') as stdout, (job/'native.stderr').open('xb') as stderr:
                try:
                    run = subprocess.run([str(exe), '-in', 'pw.in'], cwd=job, env=env, stdout=stdout, stderr=stderr, timeout=2400)
                    returncode = run.returncode
                except subprocess.TimeoutExpired:
                    timed_out, returncode = True, None
            raw_stdout = (job/'native.stdout').read_text(errors='replace')
            exports = {p.name: pin(p) for p in sorted(job.glob('ncs_native_k*.bin'))}
            expected = ['ncs_native_k%05d.bin' % i for i in range(1, points+1)]
            completed = returncode == 0 and 'JOB DONE.' in raw_stdout and list(exports) == expected
            parent_unchanged = inventory(args.parent_save) == before
            report = {'schema': 'fresh-native-QE-job.v2', 'status': 'NATIVE_DFT_EXECUTED' if completed else 'FAILED_NATIVE_EXECUTION', 'returncode': returncode, 'timed_out': timed_out, 'seconds': time.monotonic()-started, 'expected_k_points': points, 'exports': exports, 'stdout': pin(job/'native.stdout'), 'stderr': pin(job/'native.stderr'), 'parent_unchanged': parent_unchanged, 'program_unchanged': pin(exe)['sha256'] == EXPECTED_EXE, 'complete_finite_NC_operator_source_received': False, 'nonlinear_SCF_certified': False, 'utc': datetime.datetime.now(datetime.timezone.utc).isoformat()}
            write(job/'RUN.json', report)
            intake_names = ['pw.in'] + list(exports)
            if (save/'data-file-schema.xml').is_file():
                intake_names.append('out/si.save/data-file-schema.xml')
            intake_names += [p.relative_to(job).as_posix() for p in sorted(pseudo.iterdir()) if p.is_file()]
            write(job/'INTAKE_INPUTS.json', intake_names)
            jobs.append({'directory': str(job), **report})
            write(out/(name.upper()+'_RESULT.json'), report)
            require(completed and parent_unchanged and report['program_unchanged'], 'Fresh native job failed; inspect retained logs in '+str(job))
        unmixed=None
        if args.export_unmixed_input:
            from unmixed_input_remote import execute as export_unmixed
            unmixed=export_unmixed(args.parent_save,out/'native72_fresh/pw.in',out/'native72_fresh/pseudo',exe,out/'unmixed_input')
        write(out/'PARENT_AFTER.json', inventory(args.parent_save))
        write(out/'RESULTS.json', {'schema': 'fresh-native-QE-batch.v4', 'status': 'NATIVE_DFT_EXECUTED', 'jobs': jobs, 'unmixed_input':unmixed, 'parent_unchanged': inventory(args.parent_save)==before, 'fresh_scf': fresh_scf, 'parent_mode': 'fresh_scf' if fresh_scf else 'received_existing_scf', 'old_proofs_inherited': False, 'scope': 'Fresh binary exports require a separate structural intake and exact operator bridge. Numerical execution does not certify an SCF root.'})
        print(json.dumps({'status': 'NATIVE_DFT_EXECUTED', 'out': str(out), 'fresh_operator_files': 73}), flush=True)
        return 0
    except Exception as error:
        write(out/'FAILURE.json', {'status': 'FAILED_NATIVE_EXECUTION', 'error': type(error).__name__, 'reason': str(error), 'traceback': traceback.format_exc(), 'SCF_or_spectrum_certified': False})
        raise


if __name__ == '__main__':
    raise SystemExit(main())
