"""Raw DFT execution and strict scalar-NC intake. No SCF theorem is inferred.

Only the explicit NCS_NATIVE_NC_V2 s/p norm-conserving export defines a complete
finite operator here. Standard QE/VASP output is inspected as metadata. Every
fresh process, copied input, output and stage claim is separately recorded.
"""
from __future__ import annotations
import argparse
import hashlib
import json
import math
import os
from pathlib import Path
import re
import shutil
import subprocess
import struct
import sys
import time
import xml.etree.ElementTree as ET
from fractions import Fraction as Q

sys.dont_write_bytecode = True
HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE))
import qe_native_adapter as NC

MAX_XML = 64 * 1024**2
MAX_NATIVE = 128 * 1024**2
FORBIDDEN_QE_FLAGS = ('lda_plus_u', 'lelfield', 'lspinorb', 'noncolin', 'gamma_only')


class Rejected(ValueError):
    pass


def require(value, reason):
    if not value:
        raise Rejected(reason)


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf8')


def pin(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as f:
        for block in iter(lambda: f.read(1024**2), b''):
            h.update(block)
    return {'bytes': Path(path).stat().st_size, 'sha256': h.hexdigest()}


def write(path, value):
    with Path(path).open('x', encoding='utf8', newline='\n') as f:
        json.dump(value, f, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False)
        f.write('\n')


def safe_relative(root, name):
    require(isinstance(name, str) and name and '\\' not in name, 'POSIX relative input name required')
    p = Path(name)
    require(not p.is_absolute() and '..' not in p.parts and ':' not in name, 'Input path escapes source root')
    require(p.as_posix() == name, 'Canonical POSIX relative input path required')
    target = (root / p).resolve()
    require(target.is_relative_to(root.resolve()) and target.is_file(), 'Input absent or outside source root: '+name)
    return target


def source_inventory(engine, root, input_names):
    require(engine in ('qe', 'vasp'), 'Unsupported raw engine')
    require(isinstance(input_names, list) and input_names and all(isinstance(n, str) for n in input_names) and len(set(input_names)) == len(input_names), 'Unique explicit nonempty input list required')
    rows = [{'path': name, **pin(safe_relative(root, name))} for name in sorted(input_names)]
    body = {'engine': engine, 'files': rows}
    return {'manifest': body, 'fingerprint': hashlib.sha256(canonical(body)).hexdigest()}


def decimal(value):
    return str(Q(value.replace('D', 'e').replace('d', 'e')))


def safe_xml(path):
    require(path.stat().st_size <= MAX_XML, 'XML exceeds bounded intake size')
    data = path.read_bytes()
    require(b'<!DOCTYPE' not in data.upper() and b'<!ENTITY' not in data.upper(), 'DTD/entity input is unsupported')
    root = ET.fromstring(data)
    for node in root.iter():
        node.tag = node.tag.rsplit('}', 1)[-1]
    return root


def qelist(node, name):
    item = node.find(name)
    return None if item is None or not item.text else [decimal(x) for x in item.text.split()]


def inspect_qe_xml(path):
    root = safe_xml(path)
    out = root.find('output')
    require(out is not None, 'QE output element missing')
    band = out.find('band_structure')
    require(band is not None, 'QE band_structure missing')
    rows = []
    for n in band.findall('ks_energies'):
        eigen = qelist(n, 'eigenvalues')
        occ = qelist(n, 'occupations')
        require(eigen is not None and occ is not None and len(eigen) == len(occ), 'QE energy/occupation count mismatch')
        kp = n.find('k_point')
        require(kp is not None and len(kp.text.split()) == 3, 'QE k point missing')
        rows.append({'coordinate': [decimal(x) for x in kp.text.split()], 'attributes': kp.attrib,
                     'eigenvalues_as_printed_exact': eigen, 'occupations_as_printed_exact': occ,
                     'npw': n.findtext('npw')})
    nks = int(band.findtext('nks', '0'))
    require(nks == len(rows) and nks > 0, 'QE nks inventory mismatch')
    labels = {}
    for name in ('nbnd', 'nelec', 'lsda', 'noncolin', 'spinorbit'):
        labels[name] = band.findtext(name)
    cell = out.find('atomic_structure')
    require(cell is not None, 'QE atomic_structure missing')
    return {'schema': 'qe-schema-metadata-intake.v1', 'source': pin(path),
            'metadata_only': True, 'band_labels': labels, 'k_points': rows,
            'structure_attributes': cell.attrib,
            'cell': [[decimal(x) for x in n.text.split()] for n in cell.findall('cell/*')],
            'positions': [{'name': n.attrib.get('name'), 'position': [decimal(x) for x in n.text.split()]}
                          for n in cell.findall('atomic_positions/atom')],
            'units': 'Exact decimal strings as printed; schema units/attributes retained. Not binary pre-print values.',
            'whole_operator_received': False, 'nonlinear_SCF_root_certified': False}


def inspect_vasp_xml(path):
    root = safe_xml(path)
    require(root.tag == 'modeling', 'VASP modeling root missing')
    generator = {n.attrib.get('name'): (n.text or '').strip() for n in root.findall('generator/i')}
    require(generator.get('program', '').lower() == 'vasp', 'VASP generator identity missing')
    settings = {n.attrib.get('name'): (n.text or '').strip() for n in root.findall('parameters//i')}
    klist = root.find("kpoints/varray[@name='kpointlist']")
    weights = root.find("kpoints/varray[@name='weights']")
    require(klist is not None and weights is not None, 'VASP k point arrays missing')
    kpoints = [[decimal(v) for v in n.text.split()] for n in klist]
    ww = [[decimal(v) for v in n.text.split()] for n in weights]
    require(len(kpoints) == len(ww) and all(len(x) == 3 for x in kpoints), 'VASP k point/weight mismatch')
    return {'schema': 'vasp-metadata-intake.v1', 'source': pin(path), 'generator': generator,
            'settings': settings, 'k_points': kpoints, 'weights': ww, 'metadata_only': True,
            'whole_operator_received': False, 'nonlinear_SCF_root_certified': False,
            'missing': ['Source-bound PAW overlap S and augmentation operators',
                        'complete plane-wave/local/nonlocal Hamiltonian construction',
                        'PAW dataset interpretation and controlled arithmetic receiver']}


def explicit_points(path):
    lines = [x.split('!')[0].strip() for x in path.read_text(encoding='utf8').splitlines()]
    idx = [i for i, x in enumerate(lines) if re.match(r'^k_points\b', x, re.I)]
    require(len(idx) == 1, 'One explicit K_POINTS card required for whole-carrier intake')
    i = idx[0]
    mode = lines[i].lower().replace('{', '').replace('}', '').replace('(', '').replace(')', '').split()
    require(len(mode) == 2 and mode[1] in ('tpiba', 'crystal'), 'Only explicit tpiba/crystal k input received')
    n = int(lines[i+1]); require(0 < n <= 10000, 'Bounded explicit k point count required')
    points = [[Q(decimal(v)) for v in row.split()] for row in lines[i+2:i+2+n]]
    require(len(points) == n and all(len(row) == 4 and row[3] >= 0 for row in points), 'Explicit k inventory malformed')
    return mode[1], points


# Every source record participating in H or its native/infinite-source bridge is
# named here. Saved eigenvalues and trial vectors/actions do not define H.
OPERATOR_RECORDS = {
    0: 'format_magic', 2: 'k_inverse_bohr', 3: 'reciprocal_columns_inverse_bohr',
    5: 'kinetic', 6: 'G', 7: 'fft_slots_1based', 8: 'vrs', 9: 'beta', 10: 'D',
    15: 'radial_header', 16: 'tpiba_omega_dq', 17: 'cell_at', 18: 'atoms_tau',
    19: 'species', 20: 'radial_nh', 21: 'radial_offsets', 22: 'angular_l',
    23: 'angular_lm', 24: 'radial_index', 25: 'radial_table',
}
DIAGNOSTIC_RECORDS = {4: 'eigenvalues', 11: 'trial_psi', 12: 'H_trial_psi',
                      13: 'probe_psi', 14: 'H_probe_psi'}


def operator_identity(path, obj=None):
    """Bit-exact source-field identity, distinct from a whole-file raw pin.

    The identity is deliberately conservative: even signed-zero bit changes in
    an operator field require a new bridge. Source endianness is included.
    Header ik is only a point label; nbnd/nprobe size diagnostic records.
    """
    raw = Path(path).read_bytes()
    obj = NC.decode_bytes(raw) if obj is None else obj
    reader = NC.Records(raw)
    payloads = []
    while reader.offset < len(raw):
        payloads.append(reader.record())
    require(len(payloads) == 26, 'Exactly 26 supported native source records required')
    fields = {name: {'bytes': len(payloads[i]), 'sha256': hashlib.sha256(payloads[i]).hexdigest()}
              for i, name in OPERATOR_RECORDS.items()}
    fields['operator_dimensions'] = {k: v for k, v in obj.header.items() if k not in ('ik', 'nbnd', 'nprobe')}
    fields['source_endianness'] = reader.endian
    digest = hashlib.sha256(canonical(fields)).hexdigest()
    return {'schema': 'native-NC-operator-source-identity.v1', 'sha256': digest,
            'fields': fields, 'raw_file': {'bytes': len(raw), 'sha256': hashlib.sha256(raw).hexdigest()},
            'excluded_records': DIAGNOSTIC_RECORDS,
            'excluded_header_labels': ['ik', 'nbnd', 'nprobe'],
            'equality_contract': 'Exact bit identity of every actual operator-source field: G,k,T,D,beta,vrs,FFT,cell,atoms,species,radial table and angular maps. Diagnostics may differ; no numerical tolerance.'}


def inspect_native(root, input_names):
    files = sorted(name for name in input_names if re.search(r'(^|/)ncs_native_k\d{5}\.bin$', name))
    if not files:
        return {'complete_NC_source_received': False, 'reason': 'No complete scalar-NC native operator export. Standard stdout/XML is insufficient.'}
    qinputs = [n for n in input_names if Path(n).name == 'pw.in']
    require(len(qinputs) == 1, 'Native intake needs its actual pw.in coordinate and cutoff contract')
    mode, coords = explicit_points(safe_relative(root, qinputs[0]))
    text = safe_relative(root, qinputs[0]).read_text(encoding='utf8')
    cutoff = re.findall(r'\becutwfc\s*=\s*([\d.eEdD+-]+)', text, re.I)
    require(len(cutoff) == 1 and Q(decimal(cutoff[0])) == 80, 'Current complete carrier receiver supports exactly80Ry')
    require(len(files) == len(coords), 'Complete native k point inventory differs from explicit input')
    before = {n: pin(safe_relative(root, n)) for n in files}
    rows, base = [], None
    for index, name in enumerate(files, 1):
        path = safe_relative(root, name)
        require(path.stat().st_size <= MAX_NATIVE, 'Native export exceeds bounded intake size')
        obj = NC.decode(path)
        require(obj.header['ik'] == index, 'Native point index gap/duplicate')
        if base is None:
            base = obj
        else:
            NC.same_frozen_constants(base, obj)
        k = tuple(coords[index-1][:3])
        if mode == 'tpiba':
            at = [[NC.exact(v) for v in row] for row in obj.fields['at']]
            k = tuple(sum(at[j][l] * k[j] for j in range(3)) for l in range(3))
        carrier = NC.complete_carrier(obj, k)
        require(all(v >= 0 for v in obj.fields['kinetic']), 'Nonnegative kinetic diagonal required')
        rows.append({'file': name, 'source': before[name], 'ik': index,
                     'carrier': carrier, 'header': obj.header,
                     'nominal_crystal_k_exact': list(map(str, k)),
                     'input_coordinate_mode': mode,
                     'nominal_input_k_exact': list(map(str, coords[index-1][:3])),
                     'quadrature_weight_exact': str(coords[index-1][3]),
                     'operator_identity': operator_identity(path, obj),
                     'all_native_records_consumed': True,
                     'full_nonlocal_channels': obj.header['nkb'],
                     'whole_operator_definition': 'diag(T)+U_G^* diag(V) U_G+beta D beta^*; exported binary64 factors are exact dyadics',
                     'floating_native_program_or_continuous_PBE_certified': False})
    require(before == {n: pin(safe_relative(root, n)) for n in files}, 'Raw exports changed during intake')
    family_identity = [{'operator': row['operator_identity']['sha256'],
                        'input_coordinate_mode': row['input_coordinate_mode'],
                        'nominal_input_k_exact': row['nominal_input_k_exact'],
                        'quadrature_weight_exact': row['quadrature_weight_exact']} for row in rows]
    return {'schema': 'complete-scalar-NC-raw-intake.v1', 'complete_NC_source_received': True,
            'operator_family_identity_sha256': hashlib.sha256(canonical(family_identity)).hexdigest(),
            'k_points': len(rows), 'shared_frozen_constants_exactly_equal': True, 'points': rows,
            'scope': 'Complete exported finite scalar NC operators at the explicit input points; no rounding bridge, infinite tail or SCF fixed point is inferred.'}


def inspect_source(engine, root, names):
    metadata = []
    for name in names:
        if engine == 'qe' and Path(name).name == 'data-file-schema.xml':
            metadata.append(inspect_qe_xml(safe_relative(root, name)))
        elif engine == 'vasp' and Path(name).name == 'vasprun.xml':
            metadata.append(inspect_vasp_xml(safe_relative(root, name)))
    operator = inspect_native(root, names) if engine == 'qe' else {
        'complete_NC_source_received': False, 'reason': 'VASP PAW Hamiltonian/overlap augmentation receiver is not implemented.'}
    return {'metadata': metadata, 'operator': operator,
            'nonlinear_SCF_root_certified': False, 'infinite_frozen_spectrum_certified': False}


def new_output(value):
    out = Path(value).resolve()
    require(not out.exists(), 'Choose a new output directory; previous evidence is preserved')
    out.mkdir(parents=True)
    return out


def source_context(args):
    root = args.source_root.resolve()
    require(root.is_dir(), 'Source root absent')
    names = json.loads(args.inputs_json.read_text(encoding='utf8'))
    inv = source_inventory(args.engine, root, names)
    supplied = os.environ.get('DFT_PORTAL_SOURCE_FINGERPRINT')
    require(supplied is None or supplied == inv['fingerprint'], 'Portal source fingerprint differs from actual input bytes')
    return root, names, inv


def stage_receipt(out, source_fp, status, claims):
    artifacts = [{'path': p.relative_to(out).as_posix(), **pin(p)} for p in sorted(out.rglob('*')) if p.is_file()]
    write(out/'stage-receipt.json', {'schema': 'dft-portal-stage-receipt.v1',
          'run_id': os.environ.get('DFT_PORTAL_RUN_ID', 'standalone'),
          'source_fingerprint': source_fp, 'status': status,
          'receiver_programs': {name: pin(HERE/name) for name in ('raw_dft.py','qe_native_adapter.py','ssh_qe.py','fresh_native_remote.py','fresh_scf_remote_v1.py','receive_fresh_remote.py') if (HERE/name).is_file()},
          'runtime': {'executable': str(Path(sys.executable).resolve()), 'python_version': sys.version},
          'reexecution': 'fresh_compute', 'claims': claims, 'artifacts': artifacts,
          'actual_science_received': {'complete_finite_NC_operator_source': 'raw_source_intake' in claims,
             'native_process_execution_completed': 'native_dft_executed' in claims,
             'native_scf_execution_completed': 'native_scf_executed' in claims,
             'exact_operator_identity_bridge': 'operator_identity_bridge' in claims,
             'nonlinear_SCF_root': False, 'infinite_frozen_spectrum': False},
          'logs': [p['path'] for p in artifacts if p['path'].endswith(('.stdout', '.stderr', 'FAILURE.json'))]})


def bridge_operators(args, out):
    root, names, inv = source_context(args)
    require(args.engine == 'qe', 'Only the implemented scalar NC bridge can be compared')
    require(args.reference_root is not None and args.reference_inputs_json is not None, 'Explicit reference operator source required')
    refroot = args.reference_root.resolve()
    refnames = json.loads(args.reference_inputs_json.read_text(encoding='utf8'))
    refinv = source_inventory('qe', refroot, refnames)
    current = inspect_native(root, names)
    previous = inspect_native(refroot, refnames)
    comparisons = compare_native_inspections(current, previous)
    require(inv == source_inventory('qe', root, names) and refinv == source_inventory('qe', refroot, refnames), 'Source changed during bridge reception')
    same = all(row['operator_source_identical'] for row in comparisons)
    result = {'schema': 'explicit-native-NC-operator-bridge.v1', 'status': 'ACCEPTED_EXACT_OPERATOR_IDENTITY' if same else 'UNRESOLVED_CHANGED_OPERATOR_SOURCE',
       'source': inv, 'reference_source': refinv, 'points': comparisons, 'every_actual_operator_field_identical': same,
       'current_operator_family_identity': current['operator_family_identity_sha256'],
       'reference_operator_family_identity': previous['operator_family_identity_sha256'],
       'proof_reuse_eligibility': same, 'old_proofs_automatically_inherited': False,
       'scope': 'Identity bridge only. Any reused theorem must be separately received with its premises and reference source identity; a changed source cannot inherit it.'}
    write(out/'RESULTS.json', result)
    stage_receipt(out, inv['fingerprint'], 'ACCEPTED' if same else 'UNRESOLVED', ['raw_source_intake', 'operator_identity_bridge'] if same else ['raw_source_intake'])
    return 0 if same else 3


def compare_native_inspections(current, previous):
    require(current['complete_NC_source_received'] and previous['complete_NC_source_received'], 'Both sides need complete native NC source intake')
    require(len(current['points']) == len(previous['points']), 'Reference/source point counts differ')
    comparisons = []
    for new, old in zip(current['points'], previous['points']):
        a, b = new['operator_identity'], old['operator_identity']
        changed = [key for key in sorted(set(a['fields']) | set(b['fields'])) if a['fields'].get(key) != b['fields'].get(key)]
        changed_contract = [key for key in ('input_coordinate_mode','nominal_input_k_exact','quadrature_weight_exact') if new[key] != old[key]]
        comparisons.append({'ik': new['ik'], 'current_file': new['file'], 'reference_file': old['file'],
            'raw_files_identical': a['raw_file'] == b['raw_file'], 'operator_source_identical': not changed and not changed_contract,
            'changed_input_coordinate_or_quadrature_contract': changed_contract,
            'changed_operator_fields': changed, 'current_operator_identity': a['sha256'], 'reference_operator_identity': b['sha256']})
    return comparisons


def intake(args, out):
    root, names, inv = source_context(args)
    inspection = inspect_source(args.engine, root, names)
    require(inv == source_inventory(args.engine, root, names), 'Input bytes changed during intake')
    accepted = inspection['operator']['complete_NC_source_received']
    result = {'schema': 'raw-DFT-source-intake.v1', 'status': 'ACCEPTED_COMPLETE_FINITE_NC_SOURCE' if accepted else 'UNRESOLVED_OPERATOR_SOURCE',
              'source': inv, 'inspection': inspection, 'scientific_claims': {'complete_finite_NC_operator_source': accepted,
              'rounding_bridge': False, 'infinite_orbital_nonlinear_SCF': False}}
    write(out/'RESULTS.json', result)
    stage_receipt(out, inv['fingerprint'], 'ACCEPTED' if accepted else 'UNRESOLVED', ['raw_source_intake'] if accepted else [])
    return 0 if accepted else 3


def relative_qe_paths(text):
    # A copied job may only read/write paths in its own declared directory.
    text = '\n'.join(line.split('!')[0] for line in text.splitlines())
    for name in ('outdir', 'pseudo_dir', 'wfcdir'):
        values = re.findall(r'\b'+name+r"\s*=\s*['\"]([^'\"]+)['\"]", text, re.I)
        require(len(values) <= 1, 'Duplicate QE path setting '+name)
        require(name == 'wfcdir' or len(values) == 1, 'Explicit copied-job path required: '+name)
        for value in values:
            p = Path(value)
            require(value and not value.startswith('/') and not p.is_absolute() and '..' not in p.parts and '\\' not in value and ':' not in value, 'QE job path must stay relative: '+name)


def run_native(args, out):
    root, names, inv = source_context(args)
    exe_name = args.executable or ('pw.x' if args.engine == 'qe' else 'vasp_std')
    exe_value = shutil.which(exe_name)
    require(exe_value is not None, 'Native executable is absent')
    exe = Path(exe_value).resolve()
    exe_pin = pin(exe)
    job = out/'job'; job.mkdir()
    for name in names:
        target = job/name
        target.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(safe_relative(root, name), target)
    if args.engine == 'qe':
        require(args.qe_input in names, 'Actual QE input must occur in explicit input manifest')
        require('/' not in args.qe_input and '\\' not in args.qe_input, 'QE input must be in job root')
        relative_qe_paths((job/args.qe_input).read_text(encoding='utf8'))
        command = [str(exe), '-in', args.qe_input]
    else:
        require(all(n in names for n in ('INCAR','POSCAR','POTCAR','KPOINTS')), 'VASP input quartet required')
        command = [str(exe)]
    env = dict(os.environ, OMP_NUM_THREADS='1', OPENBLAS_NUM_THREADS='1', MKL_NUM_THREADS='1')
    started = time.time()
    with (job/'native.stdout').open('xb') as stdout, (job/'native.stderr').open('xb') as stderr:
        process = subprocess.run(command, cwd=job, env=env, stdout=stdout, stderr=stderr, timeout=args.timeout)
    text = (job/'native.stdout').read_text(encoding='utf8', errors='replace')
    done = 'JOB DONE.' in text if args.engine == 'qe' else (job/'OUTCAR').is_file() and 'General timing and accounting informations' in (job/'OUTCAR').read_text(errors='replace')
    require(process.returncode == 0 and done, 'Native DFT did not complete; retained logs are not a theorem')
    require(pin(exe) == exe_pin and inv == source_inventory(args.engine, root, names), 'Executable or source inputs changed')
    all_names = sorted(p.relative_to(job).as_posix() for p in job.rglob('*') if p.is_file())
    derived = source_inventory(args.engine, job, all_names)
    inspection = inspect_source(args.engine, job, all_names)
    result = {'schema': 'fresh-native-DFT-execution.v1', 'status': 'NATIVE_DFT_EXECUTED', 'source': inv,
              'executable': {'path': str(exe), **exe_pin}, 'command': command, 'returncode': process.returncode,
              'seconds': time.time()-started, 'derived_output': derived, 'inspection': inspection,
              'native_process_execution_completed': True, 'SCF_or_infinite_spectrum_certified': False}
    write(out/'RESULTS.json', result)
    claims = ['native_dft_executed']
    if inspection['operator']['complete_NC_source_received']:
        claims.append('raw_source_intake')
    stage_receipt(out, inv['fingerprint'], 'ACCEPTED', claims)
    return 0


def main():
    p = argparse.ArgumentParser(description=__doc__)
    p.add_argument('action', choices=('intake','run-qe','run-vasp','bridge-operators','run-ssh-qe'))
    p.add_argument('--engine', choices=('qe','vasp'))
    p.add_argument('--source-root', type=Path, required=True)
    p.add_argument('--inputs-json', type=Path, required=True)
    p.add_argument('--out', type=Path, default=os.environ.get('DFT_PORTAL_OUTPUT_DIR'))
    p.add_argument('--qe-input', default='pw.in')
    p.add_argument('--executable')
    p.add_argument('--timeout', type=int, default=3600)
    p.add_argument('--reference-root', type=Path)
    p.add_argument('--reference-inputs-json', type=Path)
    p.add_argument('--ssh-config', type=Path)
    p.add_argument('--password-stdin', action='store_true')
    args = p.parse_args()
    args.engine = args.engine or ('vasp' if args.action == 'run-vasp' else 'qe')
    require(args.action not in ('run-qe', 'run-vasp') or args.engine == ('qe' if args.action == 'run-qe' else 'vasp'), 'Action and engine differ')
    require(args.out is not None and 0 < args.timeout <= 172800, 'New output and bounded native wall budget required')
    out = new_output(args.out)
    try:
        if args.action == 'intake':
            rc = intake(args, out)
        elif args.action == 'bridge-operators':
            rc = bridge_operators(args, out)
        elif args.action == 'run-ssh-qe':
            import ssh_qe
            rc = ssh_qe.run(args, out, sys.modules[__name__])
        else:
            rc = run_native(args, out)
    except Exception as e:
        write(out/'FAILURE.json', {'status': 'REJECTED_RAW_DFT_STAGE', 'error': type(e).__name__, 'reason': str(e),
                                 'nonlinear_SCF_root_certified': False})
        stage_receipt(out, os.environ.get('DFT_PORTAL_SOURCE_FINGERPRINT', ''), 'REJECTED', [])
        print(json.dumps({'status':'REJECTED','reason':str(e)}), file=sys.stderr)
        return 2
    print(json.dumps({'status':json.loads((out/'RESULTS.json').read_text(encoding='utf8'))['status'], 'out':str(out)}))
    return rc


if __name__ == '__main__':
    raise SystemExit(main())
