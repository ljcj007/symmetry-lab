"""Export one unmixed QE input-state stream from copied source files.

The diagnostic is deliberately limited to one SCF iteration. Its native stream
needs independent reception; neither a file nor a process exit proves a root.
"""
from pathlib import Path
import argparse,hashlib,json,os,re,shutil,subprocess,time

def pin(path):
    with Path(path).open('rb') as stream: h=hashlib.file_digest(stream,'sha256').hexdigest()
    return dict(bytes=Path(path).stat().st_size,sha256=h)

def inventory(folder):
    result={}
    for path in sorted(folder.rglob('*')):
        if path.is_symlink(): raise ValueError('Source links are not allowed')
        if path.is_file(): result[path.relative_to(folder).as_posix()]=pin(path)
    return result

def write(path,value):
    with path.open('x',encoding='utf8') as stream:
        json.dump(value,stream,indent=2,sort_keys=True);stream.write('\n')

def diagnostic_input(text):
    for key,value in [('calculation',"'scf'"),('electron_maxstep','1'),('conv_thr','1.0d-30')]:
        pattern=r'(?i)\b'+key+r"\s*=\s*(?:'[^']*'|\"[^\"]*\"|[^,\s/]+)"
        text,n=re.subn(pattern,key+'='+value,text)
        if n!=1: raise ValueError('Exactly one '+key+' is required')
    for key,value in [('outdir','./out'),('pseudo_dir','./pseudo'),('startingpot','file'),('restart_mode','from_scratch')]:
        text,n=re.subn(r'(?i)\b'+key+r"\s*=\s*['\"][^'\"]*['\"]",key+"='"+value+"'",text)
        if n!=1: raise ValueError('Exactly one '+key+' is required')
    return text

def execute(parent,template,pseudo,executable,out,timeout=240):
    parent=parent.resolve(strict=True);template=template.resolve(strict=True)
    pseudo=pseudo.resolve(strict=True);executable=executable.resolve(strict=True)
    if out.exists(): raise ValueError('Fresh output required')
    if not 1<=timeout<=600: raise ValueError('Diagnostic timeout must be bounded')
    before=dict(parent=inventory(parent),pseudo=inventory(pseudo),template=pin(template),executable=pin(executable),worker=pin(__file__))
    for name in ('charge-density.dat','data-file-schema.xml'):
        if name not in before['parent']: raise ValueError('Missing actual input-state file: '+name)
    text=diagnostic_input(template.read_text())
    out.mkdir();(out/'out/si.save').mkdir(parents=True);shutil.copytree(pseudo,out/'pseudo')
    for name in ('charge-density.dat','data-file-schema.xml'): shutil.copy2(parent/name,out/'out/si.save'/name)
    if inventory(out/'pseudo')!=before['pseudo']: raise ValueError('Copied pseudopotential identity differs')
    for name in ('charge-density.dat','data-file-schema.xml'):
        if pin(out/'out/si.save'/name)!=before['parent'][name]: raise ValueError('Copied input-state identity differs')
    (out/'pw.in').write_text(text,encoding='utf8')
    write(out/'PARENT_BEFORE.json',before)
    write(out/'INPUT_SOURCE.json',inventory(out))
    started=time.monotonic();timed_out=False;returncode=None
    with (out/'probe.stdout').open('xb') as fo,(out/'probe.stderr').open('xb') as fe:
        try:
            process=subprocess.run([str(executable),'-in','pw.in'],cwd=out,stdout=fo,stderr=fe,
                env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1'),timeout=timeout)
            returncode=process.returncode
        except subprocess.TimeoutExpired: timed_out=True
    after=dict(parent=inventory(parent),pseudo=inventory(pseudo),template=pin(template),executable=pin(executable),worker=pin(__file__))
    write(out/'PARENT_AFTER.json',after)
    streams={p.name:pin(p) for p in sorted(out.glob('ncs_scf_iter*.bin')) if p.is_file()}
    emitted=bool(streams) and not timed_out and before==after and returncode in (0,2)
    result=dict(schema='QE-unmixed-input-state-export.v1',status='UNMIXED_INPUT_STREAM_EXPORTED' if emitted else 'UNRESOLVED_INPUT_STATE_EXPORT',
        returncode=returncode,timed_out=timed_out,seconds=time.monotonic()-started,parent_sources_unchanged=before==after,
        streams=streams,maximum_SCF_iterations=1,numerical_SCF_convergence_claimed=False,
        input_source_mathematically_received=False,nonlinear_SCF_certified=False,
        scope='One native unmixed input-state stream. Independently decode actualV and input Hxc; do not subtract an output-density model.')
    write(out/'RESULTS.json',result)
    downloads=['pw.in','PARENT_BEFORE.json','PARENT_AFTER.json','INPUT_SOURCE.json','RESULTS.json','probe.stdout','probe.stderr',*streams]
    write(out/'DOWNLOAD_FILES.json',{name:pin(out/name) for name in downloads})
    if not emitted: raise ValueError('Native unmixed input stream not received; inspect retained diagnostic')
    return result

def main():
    parser=argparse.ArgumentParser(description=__doc__)
    for name in ('parent-save','template','pseudo','executable','out'): parser.add_argument('--'+name,type=Path,required=True)
    parser.add_argument('--timeout',type=int,default=240)
    args=parser.parse_args()
    print(json.dumps(execute(args.parent_save,args.template,args.pseudo,args.executable,args.out,args.timeout)))

if __name__=='__main__': main()
