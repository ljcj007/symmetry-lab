"""Receive fresh native operators and compare all 72 to the explicit old source.

Place beside raw_dft.py and qe_native_adapter.py on the Linux server. Run only
after fresh_native_remote.py produced RESULTS.json. Every result uses a new
directory, and no old theorem is automatically inherited by the bridge.
"""
from pathlib import Path
import argparse
import json
import subprocess
import sys


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--fresh-run', type=Path, required=True)
    parser.add_argument('--reference72', type=Path, required=True)
    parser.add_argument('--out', type=Path, required=True)
    args = parser.parse_args()
    if args.out.exists():
        raise ValueError('Choose a new receipt directory')
    batch = json.loads((args.fresh_run/'RESULTS.json').read_text())
    if batch['status'] != 'NATIVE_DFT_EXECUTED':
        raise ValueError('Fresh native batch did not finish')
    args.out.mkdir(parents=True)
    reference_names = ['pw.in'] + sorted(p.name for p in args.reference72.glob('ncs_native_k*.bin'))
    if len(reference_names) != 73:
        raise ValueError('Reference is not the explicit complete 72-point source')
    reference_list = args.out/'REFERENCE72_INPUTS.json'
    reference_list.write_text(json.dumps(reference_names, indent=2)+'\n')
    cli = Path(__file__).with_name('raw_dft.py')
    records = []
    for name in ('gamma_fresh','native72_fresh'):
        source = args.fresh_run/name
        command = [sys.executable,'-B',str(cli),'intake','--engine','qe','--source-root',str(source),'--inputs-json',str(source/'INTAKE_INPUTS.json'),'--out',str(args.out/(name+'_intake'))]
        run = subprocess.run(command, capture_output=True, text=True)
        (args.out/(name+'.stdout')).write_text(run.stdout)
        (args.out/(name+'.stderr')).write_text(run.stderr)
        records.append({'stage':name+'_intake','returncode':run.returncode,'command':command})
        if run.returncode:
            raise ValueError('Native source intake failed; inspect '+name+' logs')
    source = args.fresh_run/'native72_fresh'
    command = [sys.executable,'-B',str(cli),'bridge-operators','--engine','qe','--source-root',str(source),'--inputs-json',str(source/'INTAKE_INPUTS.json'),'--reference-root',str(args.reference72),'--reference-inputs-json',str(reference_list),'--out',str(args.out/'native72_exact_bridge')]
    run = subprocess.run(command,capture_output=True,text=True)
    (args.out/'bridge.stdout').write_text(run.stdout)
    (args.out/'bridge.stderr').write_text(run.stderr)
    records.append({'stage':'native72_exact_bridge','returncode':run.returncode,'command':command})
    with (args.out/'RESULTS.json').open('x') as stream:
        json.dump({'status':'ACCEPTED_EXACT_OPERATOR_IDENTITY' if run.returncode == 0 else 'UNRESOLVED_CHANGED_OPERATOR_SOURCE','stages':records,'old_proofs_automatically_inherited':False,'nonlinear_SCF_certified':False},stream,indent=2)
        stream.write('\n')
    print(json.dumps({'status':'ACCEPTED_EXACT_OPERATOR_IDENTITY' if run.returncode == 0 else 'UNRESOLVED_CHANGED_OPERATOR_SOURCE','out':str(args.out)}))
    return run.returncode


if __name__ == '__main__':
    raise SystemExit(main())
