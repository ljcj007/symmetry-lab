"""Independent, stdlib-only decoder for the archived QE scalar-NC export.

No eigenvectors, h_psi actions, NumPy, or previous source receiver is used to
define or compare operators. Binary64 values are retained as exact dyadics.
"""
from __future__ import annotations

from dataclasses import dataclass
from fractions import Fraction as Q
from pathlib import Path
import hashlib
import itertools
import math
import struct


class Rejected(ValueError):
    pass


def require(condition, message):
    if not condition:
        raise Rejected(message)


def sha(path):
    with Path(path).open("rb") as handle:
        return hashlib.file_digest(handle, "sha256").hexdigest()


def pin(path):
    path = Path(path)
    return {"bytes": path.stat().st_size, "sha256": sha(path)}


def exact(value):
    require(type(value) is float and math.isfinite(value), "finite binary64 input")
    return Q.from_float(value)


def sqrt_bounds(value, bits=192):
    value = Q(value)
    require(value >= 0, "nonnegative square root")
    scaled = value.numerator << (2 * bits)
    floor = math.isqrt(scaled // value.denominator)
    ceil = floor + (floor * floor * value.denominator < scaled)
    return Q(floor, 1 << bits), Q(ceil, 1 << bits)


def columns(values, rows, cols):
    require(len(values) == rows * cols, "column-major matrix length")
    return tuple(tuple(values[i + rows * j] for j in range(cols)) for i in range(rows))


@dataclass
class NativeExport:
    header: dict
    fields: dict
    radial_header: dict
    radial: dict
    record_payload_offsets: tuple


class Records:
    def __init__(self, raw):
        self.raw = raw
        self.offset = 0
        self.offsets = []
        require(len(raw) >= 8, "record header exists")
        candidates = [e for e in ("<", ">") if struct.unpack_from(e + "i", raw)[0] == 32]
        require(len(candidates) == 1, "unique four-byte Fortran record endianness")
        self.endian = candidates[0]

    def record(self, size=None):
        require(self.offset + 8 <= len(self.raw), "complete record framing")
        n = struct.unpack_from(self.endian + "i", self.raw, self.offset)[0]
        require(n >= 0 and self.offset + 8 + n <= len(self.raw), "record fits file")
        require(size is None or n == size, "record has required exact byte count")
        begin = self.offset + 4
        self.offsets.append(begin)
        require(struct.unpack_from(self.endian + "i", self.raw, begin + n)[0] == n,
                "matching Fortran trailing record marker")
        self.offset += n + 8
        return self.raw[begin:begin + n]

    def values(self, code, count):
        width = {"i": 4, "d": 8}[code]
        out = struct.unpack(self.endian + str(count) + code, self.record(width * count))
        if code == "d":
            require(all(math.isfinite(v) for v in out), "every exported binary64 is finite")
        return out


def decode_bytes(raw):
    reader = Records(raw)
    require(reader.record(32).rstrip(b" \x00") == b"NCS_NATIVE_NC_V2", "supported export magic")
    keys = ("ik npw npwx nbnd nkb nat nspin current_spin nr1 nr2 nr3 "
            "nr1x nr2x nr3x nnr nprobe").split()
    h = dict(zip(keys, reader.values("i", 16)))
    require(all(0 < h[k] <= 1000000 for k in keys), "positive bounded native dimensions")
    require(h["npw"] <= h["npwx"] and h["nspin"] == h["current_spin"] == 1,
            "scalar non-spin-polarized full plane-wave export")
    require(h["nnr"] == h["nr1x"] * h["nr2x"] * h["nr3x"], "full serial FFT grid")
    require(all(h["nr" + str(j)] == h["nr" + str(j) + "x"] for j in (1, 2, 3)),
            "this receiver requires the archived unpadded serial grid")
    n, m, bands, probes = h["npw"], h["nkb"], h["nbnd"], h["nprobe"]
    x = {}
    x["k_inverse_bohr"] = reader.values("d", 3)
    x["reciprocal_columns_inverse_bohr"] = columns(reader.values("d", 9), 3, 3)
    # Keep every record structurally authenticated, but do not use saved states
    # or h_psi probes in the proof.
    reader.values("d", bands)
    x["kinetic"] = reader.values("d", n)
    x["G"] = tuple(zip(*columns(reader.values("i", 3 * n), 3, n)))
    x["fft_slots_1based"] = reader.values("i", n)
    x["V"] = reader.values("d", h["nnr"])
    bparts = reader.values("d", 2 * n * m)
    x["beta"] = columns(tuple(complex(bparts[i], bparts[i + 1])
                             for i in range(0, len(bparts), 2)), n, m)
    x["D"] = columns(reader.values("d", m * m), m, m)
    for count in (n * bands, n * bands, n * probes, n * probes):
        reader.values("d", 2 * count)
    keys = ("nat nsp nhm lmaxkb nqx tab_dim1 tab_dim2 tab_dim3 "
            "map_dim1 map_dim2 dense_nr1 dense_nr2 dense_nr3").split()
    rh = dict(zip(keys, reader.values("i", 13)))
    require(rh["nat"] == h["nat"] and rh["lmaxkb"] == 1, "same atom count and actual s/p source")
    require(all(0 < v <= 100000 for k, v in rh.items() if k != "lmaxkb"), "bounded radial dimensions")
    require(rh["tab_dim1"] >= 4, "four-node radial table exists")
    x["tpiba"], x["omega"], x["dq"] = reader.values("d", 3)
    x["at"] = columns(reader.values("d", 9), 3, 3)
    x["tau"] = columns(reader.values("d", 3 * h["nat"]), 3, h["nat"])
    x["species"] = reader.values("i", h["nat"])
    r = {"nh": reader.values("i", rh["nsp"]),
         "offsets": reader.values("i", h["nat"])}
    for key in ("l", "lm", "radial_index"):
        r[key] = columns(reader.values("i", rh["map_dim1"] * rh["map_dim2"]),
                         rh["map_dim1"], rh["map_dim2"])
    r["table"] = reader.values("d", rh["tab_dim1"] * rh["tab_dim2"] * rh["tab_dim3"])
    require(reader.offset == len(raw), "no trailing native export bytes")
    obj = NativeExport(h, x, rh, r, tuple(reader.offsets))
    validate_structure(obj)
    return obj


def decode(path):
    return decode_bytes(Path(path).read_bytes())


def validate_structure(obj):
    h, x, rh, r = obj.header, obj.fields, obj.radial_header, obj.radial
    require(x["tpiba"] > 0 and x["dq"] > 0 and x["omega"] > 0, "positive physical scales")
    require(len(set(x["G"])) == h["npw"], "unique exported reciprocal carrier")
    nr = tuple(h["nr" + str(j)] for j in (1, 2, 3))
    slots = tuple(g[0] % nr[0] + nr[0] * (g[1] % nr[1] + nr[1] * (g[2] % nr[2])) + 1
                  for g in x["G"])
    require(len(set(slots)) == h["npw"] and slots == x["fft_slots_1based"],
            "injective integer-G to exact Fourier-grid compression")
    require(all(x["D"][i][j] == x["D"][j][i] for i in range(h["nkb"]) for j in range(h["nkb"])),
            "exact symmetric projector-weight matrix")
    require(all(x["D"][i][j] == 0 for i in range(h["nkb"]) for j in range(h["nkb"]) if i != j),
            "this actual Si bridge requires exact diagonal D")
    require(all(x["D"][j][j] > 0 for j in range(h["nkb"])), "all actual Si weights positive")
    channels = []
    for nt in range(rh["nsp"]):
        require(0 < r["nh"][nt] <= rh["map_dim1"], "native channel count fits map")
        for atom in range(h["nat"]):
            if x["species"][atom] != nt + 1:
                continue
            require(r["offsets"][atom] == len(channels), "native species/atom/channel ordering")
            for ih in range(r["nh"][nt]):
                ell, lm, nb = (r[k][ih][nt] for k in ("l", "lm", "radial_index"))
                require((ell, lm) in ((0, 1), (1, 2), (1, 3), (1, 4)), "supported s/p channel map")
                require(1 <= nb <= rh["tab_dim2"], "radial channel exists")
                channels.append((atom, nt, ell, lm, nb - 1))
    require(len(channels) == h["nkb"], "complete native projector channel inventory")
    require(all(1 <= v <= rh["nsp"] for v in x["species"]), "valid atom species map")
    return tuple(channels)


def reciprocal(at):
    a = tuple(tuple(exact(v) for v in row) for row in at)
    det = (a[0][0] * (a[1][1] * a[2][2] - a[1][2] * a[2][1])
           - a[0][1] * (a[1][0] * a[2][2] - a[1][2] * a[2][0])
           + a[0][2] * (a[1][0] * a[2][1] - a[1][1] * a[2][0]))
    require(det != 0, "nonsingular exact lattice")
    bg = tuple(tuple((a[(i + 1) % 3][(j + 1) % 3] * a[(i + 2) % 3][(j + 2) % 3]
                      - a[(i + 1) % 3][(j + 2) % 3] * a[(i + 2) % 3][(j + 1) % 3]) / det
                     for j in range(3)) for i in range(3))
    # The cofactor matrix is inverse-transpose: at^T bg = I.
    require(all(sum(a[t][i] * bg[t][j] for t in range(3)) == (1 if i == j else 0)
                for i in range(3) for j in range(3)), "exact reciprocal identity")
    return a, bg


def nominal_points(path):
    lines = Path(path).read_text(encoding="utf-8").splitlines()
    indices = [i for i, line in enumerate(lines) if line.strip().lower() == "k_points crystal"]
    require(len(indices) == 1, "one explicit crystal momentum list")
    i = indices[0]
    require(int(lines[i + 1]) == 5, "five nominal source points")
    return tuple(tuple(Q(v) for v in line.split()[:3]) for line in lines[i + 2:i + 7])


def kinetic(obj, k, g):
    _, bg = reciprocal(obj.fields["at"])
    tpiba = exact(obj.fields["tpiba"])
    q = tuple(tpiba * sum(bg[i][j] * (g[j] + k[j]) for j in range(3)) for i in range(3))
    return sum(v * v for v in q)


def complete_carrier(obj, k):
    a, bg = reciprocal(obj.fields["at"])
    tpiba = exact(obj.fields["tpiba"])
    radii = []
    for j in range(3):
        bound = Q(9) * sum(abs(a[i][j]) for i in range(3)) / tpiba + abs(k[j])
        radii.append(-((-bound.numerator) // bound.denominator))
    actual = set(obj.fields["G"])
    require(len(actual) == obj.header["npw"], "unique physical carrier")
    inside = set()
    ties = []
    candidates = math.prod(2 * n + 1 for n in radii)
    require(candidates <= 200000, "complete enumeration finite resource guard")
    # Clear all rational denominators once. Every following comparison remains
    # exact integer arithmetic; this avoids millions of Fraction allocations.
    coeff = tuple(tuple(tpiba * bg[i][j] for j in range(3)) for i in range(3))
    offset = tuple(sum(coeff[i][j] * k[j] for j in range(3)) for i in range(3))
    den = math.lcm(*(v.denominator for row in coeff for v in row), *(v.denominator for v in offset))
    ci = tuple(tuple(int(v * den) for v in row) for row in coeff)
    oi = tuple(int(v * den) for v in offset)
    cutoff = 80 * den * den
    for g in itertools.product(*(range(-n, n + 1) for n in radii)):
        qi = tuple(oi[i] + ci[i][0]*g[0] + ci[i][1]*g[1] + ci[i][2]*g[2] for i in range(3))
        ti = sum(v*v for v in qi)
        if ti < cutoff:
            inside.add(g)
        elif ti == cutoff:
            ties.append(g)
    require(inside <= actual and actual <= inside | set(ties), "every mandatory cutoff row and no forbidden row")
    return {"complete_integer_box_radii": radii, "candidates": candidates,
            "mandatory_inside": len(inside), "ties": len(ties), "actual": len(actual),
            "proof": "T<=80 implies |q_i|<9; G+k=at^T q/tpiba. Exact rational exhaustive test of the resulting enclosing integer box."}


def same_frozen_constants(base, other):
    keys = ("V", "D", "at", "tau", "species", "tpiba", "omega", "dq")
    require(all(base.fields[k] == other.fields[k] for k in keys), "same frozen potential, weights, geometry and scales")
    require(base.radial_header == other.radial_header and base.radial == other.radial, "same complete radial table and maps")
    require(all(base.header[k] == other.header[k] for k in
                ("nat", "nkb", "nspin", "current_spin", "nr1", "nr2", "nr3", "nr1x", "nr2x", "nr3x", "nnr")),
            "same frozen Fourier space and channel dimensions")
