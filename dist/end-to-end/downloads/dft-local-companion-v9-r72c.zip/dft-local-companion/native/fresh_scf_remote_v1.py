"""Execute a new QE SCF source; preserve inputs, logs and output identities.

A successful process establishes numerical execution, not a validated SCF root.
All program/input/pseudopotential locations are explicit operator choices.
"""
from pathlib import Path
import argparse,datetime,hashlib,json,os,shutil,subprocess,sys,time,traceback,re

def pin(p):
 p=Path(p)
 with p.open('rb') as f:h=hashlib.file_digest(f,'sha256').hexdigest()
 return {'bytes':p.stat().st_size,'sha256':h}

def write(p,x):
 with p.open('x',encoding='utf8') as f:json.dump(x,f,indent=2,sort_keys=True);f.write('\n')

def inventory(p):return {q.relative_to(p).as_posix():pin(q) for q in sorted(p.rglob('*')) if q.is_file()}

def main():
 ap=argparse.ArgumentParser(description=__doc__)
 ap.add_argument('--input',type=Path,required=True)
 ap.add_argument('--pseudo',type=Path,required=True)
 ap.add_argument('--executable',type=Path,required=True)
 ap.add_argument('--out',type=Path,required=True)
 ap.add_argument('--timeout',type=int,default=2400)
 ap.add_argument('--launch',action='store_true')
 ap.add_argument('--worker',action='store_true')
 a=ap.parse_args();a.out=a.out.resolve();a.input=a.input.resolve();a.pseudo=a.pseudo.resolve();a.executable=a.executable.resolve()
 if not a.worker:
  if a.out.exists():raise ValueError('Preserve prior output: select a new run directory')
  a.out.mkdir(parents=True)
 if a.launch:
  command=[sys.executable,'-B',str(Path(__file__).resolve()),'--worker','--input',str(a.input),'--pseudo',str(a.pseudo),'--executable',str(a.executable),'--out',str(a.out),'--timeout',str(a.timeout)]
  with (a.out/'worker.stdout').open('xb') as fo,(a.out/'worker.stderr').open('xb') as fe:p=subprocess.Popen(command,stdout=fo,stderr=fe,start_new_session=True)
  x={'status':'LAUNCHED','pid':p.pid,'command':command,'out':str(a.out)};write(a.out/'LAUNCH.json',x);print(json.dumps(x));return
 try:
  input_bytes=a.input.read_bytes()
  input_pin={'bytes':len(input_bytes),'sha256':hashlib.sha256(input_bytes).hexdigest()}
  text=input_bytes.decode('utf8')
  if not re.search(r"calculation\s*=\s*['\"]scf['\"]",text,re.I):raise ValueError('SCF input required')
  if re.search(r"startingpot\s*=\s*['\"]file['\"]|restart_mode\s*=\s*['\"]restart['\"]",text,re.I):raise ValueError('Fresh SCF must not reuse old parent potential or restart')
  for name,value in [('outdir','./out'),('pseudo_dir','./pseudo')]:
   text,n=re.subn(name+r"\s*=\s*['\"][^'\"]*['\"]",name+"='"+value+"'",text,flags=re.I)
   if n!=1:raise ValueError('Exactly one '+name+' required')
  original={'input':pin(a.input),'executable':pin(a.executable),'pseudopotentials':inventory(a.pseudo),'worker':pin(__file__)}
  if original['input']!=input_pin:raise ValueError('SCF input changed while being read')
  write(a.out/'SOURCE_BEFORE.json',original)
  (a.out/'input-original.in').write_bytes(input_bytes)
  (a.out/'pw.in').write_text(text)
  shutil.copytree(a.pseudo,a.out/'pseudo')
  if not original['pseudopotentials']:raise ValueError('Empty pseudopotential source')
  if inventory(a.out/'pseudo')!=original['pseudopotentials']:raise ValueError('Copied pseudopotential source differs')
  input_source=inventory(a.out)
  write(a.out/'INPUT_SOURCE.json',input_source)
  env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1')
  start=time.monotonic()
  with (a.out/'scf.stdout').open('xb') as fo,(a.out/'scf.stderr').open('xb') as fe:
   run=subprocess.run([str(a.executable),'-in','pw.in'],cwd=a.out,env=env,stdout=fo,stderr=fe,timeout=a.timeout)
  stdout=(a.out/'scf.stdout').read_text(errors='replace')
  after={'input':pin(a.input),'executable':pin(a.executable),'pseudopotentials':inventory(a.pseudo),'worker':pin(__file__)}
  write(a.out/'SOURCE_AFTER.json',after)
  inputs_unchanged=all((a.out/name).is_file() and pin(a.out/name)==value for name,value in input_source.items())
  completed=run.returncode==0 and 'JOB DONE.' in stdout and 'convergence has been achieved' in stdout and (a.out/'out/si.save/charge-density.dat').is_file()
  result={'schema':'fresh-QE-SCF-source.v1','status':'NATIVE_SCF_EXECUTED' if completed else 'FAILED_NATIVE_SCF','returncode':run.returncode,'seconds':time.monotonic()-start,'source_unchanged':original==after,'execution_inputs_unchanged':inputs_unchanged,'stdout':pin(a.out/'scf.stdout'),'stderr':pin(a.out/'scf.stderr'),'save':inventory(a.out/'out/si.save'),'numerical_convergence':completed,'finite_SCF_certified':False,'infinite_nonlinear_SCF_certified':False,'utc':datetime.datetime.now(datetime.timezone.utc).isoformat(),'scope':'Numerical SCF convergence plus exact raw-file identities. New operators require independent source intake, rounding, basis and nonlinear proof receivers; no old proof is inherited.'}
  write(a.out/'RESULTS.json',result);print(json.dumps(result))
  if not completed or original!=after or not inputs_unchanged:raise ValueError('Fresh SCF execution not accepted')
 except Exception as e:
  write(a.out/'FAILURE.json',{'error':type(e).__name__,'reason':str(e),'traceback':traceback.format_exc(),'certified':False});raise
if __name__=='__main__':main()
