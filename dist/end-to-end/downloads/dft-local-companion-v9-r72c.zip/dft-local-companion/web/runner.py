"""Run registered scientific stages; process completion is not certification."""
from pathlib import Path
import argparse
import datetime
import hashlib
import json
import os
import re
import signal
import subprocess
import sys
import time
import uuid

HERE = Path(__file__).resolve().parent
PAPER = HERE.parents[2]
JOBS = HERE / 'jobs'
PROFILES = HERE / 'profiles'
ID = re.compile(r'^[a-z0-9][a-z0-9_-]{0,79}$')
CLAIMS = {
    'native_scf_executed': '已执行新的数值 SCF（未代替严格根证明）',
    'native_dft_executed': '已执行原生 DFT',
    'raw_source_intake': '完整原生源接收',
    'ionic_input_source_bridge_enclosed': '原始输入态离子势衔接已接收',
    'operator_identity_bridge': '接收源的算符身份一致',
    'construction_rounding_enclosed': '算符构造与舍入误差已接收',
    'infinite_basis_tail_enclosed': '遗漏基组及耦合已控制',
    'finite_reference_scf_root_enclosed': '有限参考自洽根已包围',
    'infinite_orbital_nonlinear_scf_root_enclosed': '无限轨道非线性自洽根已包围',
    'same_potential_infinite_global_gap': '同势全布里渊区谱结论已接收',
}
FULL_CHAIN = [
    'native_scf_executed', 'native_dft_executed', 'raw_source_intake', 'construction_rounding_enclosed',
    'infinite_basis_tail_enclosed', 'infinite_orbital_nonlinear_scf_root_enclosed',
    'same_potential_infinite_global_gap',
]
INFINITE_CHAIN = ['native_scf_executed','native_dft_executed','raw_source_intake',
                  'ionic_input_source_bridge_enclosed','infinite_orbital_nonlinear_scf_root_enclosed']


def require(condition, message):
    if not condition:
        raise ValueError(message)


def now():
    return datetime.datetime.now(datetime.timezone.utc).isoformat()


def canonical(value):
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False).encode('utf8')


def digest(path):
    h = hashlib.sha256()
    with path.open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return {'bytes': path.stat().st_size, 'sha256': h.hexdigest()}


def load(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def save(path, value):
    path.parent.mkdir(parents=True, exist_ok=True)
    temporary = path.with_name(path.name + '.pending-' + uuid.uuid4().hex)
    with temporary.open('x', encoding='utf8', newline='\n') as stream:
        json.dump(value, stream, ensure_ascii=False, indent=2)
        stream.write('\n')
    os.replace(temporary, path)


def inside(root, relative, *, exists=True):
    require(isinstance(relative, str) and relative and '\\' not in relative,
            'Use nonempty relative POSIX paths')
    p = Path(relative)
    require(not p.is_absolute() and ':' not in relative and '..' not in p.parts,
            'A path escapes its declared root')
    resolved = (root / p).resolve()
    require(resolved.is_relative_to(root.resolve()), 'A path resolves outside its declared root')
    if exists:
        require(resolved.exists(), 'Required input is missing: ' + relative)
    return resolved


def profile_path(profile_id):
    require(ID.fullmatch(profile_id or '') is not None, 'Invalid profile identifier')
    return PROFILES / (profile_id + '.json')


def validate_profile(profile):
    require(profile.get('schema') == 'dft-portal-profile.v1', 'Unsupported profile schema')
    require(ID.fullmatch(profile.get('id', '')) is not None, 'Invalid profile identifier')
    require(profile.get('engine') in ('qe', 'vasp', 'control'), 'Unsupported engine')
    require(isinstance(profile.get('label'), str), 'Profile label is missing')
    source = inside(PAPER, profile['source_root'])
    require(source.is_dir(), 'Source root must be a directory inside paper')
    files = profile.get('inputs')
    require(isinstance(files, list) and files and len(files) <= 100000, 'An explicit input file list is required')
    require(len(files) == len(set(files)), 'Duplicate input paths')
    for name in files:
        require(inside(source, name).is_file(), 'Input is not a file: ' + name)
    stages = profile.get('stages')
    require(isinstance(stages, list) and 0 < len(stages) <= 32, 'A bounded stage list is required')
    stage_ids = []
    for stage in stages:
        require(ID.fullmatch(stage.get('id', '')) is not None, 'Invalid stage identifier')
        stage_ids.append(stage['id'])
        require(isinstance(stage.get('label'), str), 'Stage label is missing')
        require(set(stage.get('claims', [])) <= set(CLAIMS), 'Unsupported scientific claim')
        require(set(stage.get('optional_claims', [])) <= set(CLAIMS), 'Unsupported optional scientific claim')
        if stage.get('program') is None:
            require(isinstance(stage.get('unavailable_reason'), str), 'Unconfigured stages need a reason')
            continue
        program = inside(PAPER, stage['program'])
        require(program.is_file() and program.suffix == '.py', 'Only a registered Python driver may be executed')
        require(digest(program) == stage.get('program_pin'), 'Registered program bytes changed: ' + stage['id'])
        for dependency in stage.get('dependencies', []):
            require(digest(inside(PAPER, dependency['path'])) == {k: dependency[k] for k in ('bytes','sha256')},
                    'Registered dependency changed: ' + dependency['path'])
        require(isinstance(stage.get('arguments'), list) and all(isinstance(a, str) for a in stage['arguments']),
                'Arguments must be a string array')
        require(isinstance(stage.get('timeout_seconds'), int) and 1 <= stage['timeout_seconds'] <= 604800,
                'Stage timeout must be between one second and seven days')
        require(stage.get('receipt') == 'stage-receipt.json', 'Use the fresh stage receipt contract')
    require(len(stage_ids) == len(set(stage_ids)), 'Duplicate stage identifiers')
    require(set(profile.get('target_claims', [])) <= set(CLAIMS), 'Unsupported target claim')
    return profile


def input_manifest(profile):
    source = inside(PAPER, profile['source_root'])
    rows = [{'path': name, **digest(inside(source, name))} for name in sorted(profile['inputs'])]
    manifest = {'engine': profile['engine'], 'files': rows}
    return manifest, hashlib.sha256(canonical(manifest)).hexdigest()


def append_event(job, kind, **detail):
    with (job / 'events.jsonl').open('a', encoding='utf8', newline='\n') as stream:
        stream.write(json.dumps({'time': now(), 'kind': kind, **detail}, ensure_ascii=False) + '\n')


def create_job(profile_id):
    config = profile_path(profile_id)
    profile = validate_profile(load(config))
    job_id = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S').lower() + '-' + uuid.uuid4().hex[:10]
    JOBS.mkdir(exist_ok=True)
    job = JOBS / job_id
    job.mkdir()
    save(job / 'PROFILE.json', profile)
    save(job / 'INPUT_FILES.json', profile['inputs'])
    manifest, fingerprint = input_manifest(profile)
    save(job / 'SOURCE.json', {'manifest': manifest, 'source_fingerprint': fingerprint})
    state = {
        'schema': 'dft-portal-run.v1', 'id': job_id, 'profile_id': profile_id,
        'label': profile['label'], 'engine': profile['engine'], 'status': 'QUEUED',
        'created_at': now(), 'updated_at': now(), 'profile_pin': digest(config),
        'source_fingerprint': fingerprint,
        'runner_pin': digest(Path(__file__)), 'target_claims': profile.get('target_claims', []),
        'verified_claims': [], 'full_chain_certified': False,
        'scientific_status': 'NOT_EVALUATED',
        'stages': [{'id': s['id'], 'label': s['label'], 'state': 'WAITING', 'claims': []}
                   for s in profile['stages']],
        'scope': profile.get('scope', ''),
        'evidence_boundary': 'Program and file identity plus actual registered receiver execution. '
                             'The portal itself is not an independent mathematical proof or hostile-host attestation.',
    }
    save(job / 'RUN.json', state)
    append_event(job, 'CREATED', profile_id=profile_id)
    return job_id


def receive_stage(receipt, stage, output, run_id, source_fingerprint):
    r = load(receipt)
    require(r.get('schema') == 'dft-portal-stage-receipt.v1', 'Unsupported stage receipt')
    require(r.get('run_id') == run_id, 'Stale receipt: run identifier differs')
    require(r.get('source_fingerprint') == source_fingerprint, 'Receipt belongs to a different source')
    require(r.get('status') in ('ACCEPTED', 'UNRESOLVED', 'REJECTED'), 'Unknown scientific stage status')
    require(r.get('reexecution') in ('fresh_compute', 'received_proof_composition'), 'Missing replay boundary')
    claims = r.get('claims')
    require(isinstance(claims, list) and len(claims) == len(set(claims)), 'Malformed claims')
    require(set(claims) <= set(stage.get('claims', [])) | set(stage.get('optional_claims', [])),
            'Stage claimed a result outside its registered scope')
    artifacts = r.get('artifacts')
    require(isinstance(artifacts, list) and artifacts, 'A receipt must bind actual output artifacts')
    seen = set()
    for item in artifacts:
        name = item['path']
        require(name != 'stage-receipt.json' and name not in seen, 'Invalid or duplicated artifact identity')
        seen.add(name)
        path = inside(output, name)
        require(path.is_file(), 'A receipt artifact is not a file')
        require(digest(path) == {k: item[k] for k in ('bytes', 'sha256')}, 'Output artifact bytes changed: ' + name)
    if r['status'] == 'ACCEPTED':
        require(set(stage.get('claims', [])) <= set(claims), 'Required stage claim was not received')
    return r


def execute(job_id):
    require(ID.fullmatch(job_id or '') is not None, 'Invalid job identifier')
    job = inside(JOBS, job_id)
    state = load(job / 'RUN.json')
    require(state['status'] == 'QUEUED', 'Each created job executes at most once')
    profile = validate_profile(load(job / 'PROFILE.json'))
    manifest, fingerprint = input_manifest(profile)
    require(fingerprint == state['source_fingerprint'], 'Source inputs changed after job creation')
    runtime = Path(profile.get('python_executable') or sys.executable).resolve()
    require(runtime.is_file(), 'Registered scientific Python runtime is absent')
    state.update(status='RUNNING', started_at=now(), source_fingerprint=fingerprint,
                 runner_pid=os.getpid(), python_executable=str(runtime), python_pin=digest(runtime))
    verified = set()
    modes = {}
    failure = None
    start = time.monotonic()

    def update():
        state['updated_at'] = now()
        state['elapsed_seconds'] = round(time.monotonic() - start, 3)
        state['verified_claims'] = sorted(verified)
        save(job / 'RUN.json', state)

    update()
    try:
        for i, stage in enumerate(profile['stages']):
            row = state['stages'][i]
            if stage.get('program') is None:
                row.update(state='UNRESOLVED', reason=stage['unavailable_reason'])
                state.update(status='UNRESOLVED', scientific_status='UNRESOLVED')
                append_event(job, 'UNAVAILABLE_STAGE', stage=stage['id'], reason=stage['unavailable_reason'])
                break
            require(input_manifest(profile)[1] == fingerprint, 'Source inputs changed during the run')
            program = inside(PAPER, stage['program'])
            require(digest(program) == stage['program_pin'], 'Registered program changed before execution')
            dependency_pins = {d['path']: digest(inside(PAPER, d['path'])) for d in stage.get('dependencies', [])}
            folder = job / 'stages' / stage['id']
            folder.mkdir(parents=True)
            output = folder / 'output'
            require(not output.exists(), 'Stage output must be fresh')
            values = {'paper_root': str(PAPER), 'web_root': str(HERE), 'job_root': str(job),
                      'source_root': str(inside(PAPER, profile['source_root'])),
                      'input_list': str(job/'INPUT_FILES.json'), 'stage_output': str(output),
                      'run_id': job_id}
            arguments = [a.format_map(values) for a in stage['arguments']]
            command = [str(runtime), '-B', str(program), *arguments]
            env = os.environ.copy()
            env.update(PYTHONDONTWRITEBYTECODE='1', PYTHONUTF8='1',
                       DFT_PORTAL_RUN_ID=job_id, DFT_PORTAL_SOURCE_FINGERPRINT=fingerprint,
                       DFT_PORTAL_OUTPUT_DIR=str(output), DFT_PORTAL_JOB_ROOT=str(job))
            row.update(state='RUNNING', started_at=now(), program_pin=digest(program),
                       dependency_pins=dependency_pins, command=command)
            append_event(job, 'STAGE_STARTED', stage=stage['id'])
            update()
            stage_start = time.monotonic()
            with (folder/'stdout.log').open('xb') as stdout, (folder/'stderr.log').open('xb') as stderr:
                flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
                process = subprocess.Popen(command, cwd=PAPER, env=env, stdout=stdout, stderr=stderr,
                                           creationflags=flags, start_new_session=os.name != 'nt')
                row['pid'] = process.pid
                while process.poll() is None:
                    row['elapsed_seconds'] = round(time.monotonic() - stage_start, 3)
                    if time.monotonic() - stage_start > stage['timeout_seconds']:
                        if os.name == 'nt':
                            subprocess.run(['taskkill', '/PID', str(process.pid), '/T', '/F'],
                                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                           creationflags=subprocess.CREATE_NO_WINDOW)
                        else:
                            os.killpg(process.pid, signal.SIGTERM)
                        try:
                            process.wait(timeout=10)
                        except subprocess.TimeoutExpired:
                            process.kill()
                            process.wait()
                        raise TimeoutError('Stage exhausted its declared wall-time budget')
                    update()
                    time.sleep(0.5)
            row.update(returncode=process.returncode, finished_at=now(),
                       elapsed_seconds=round(time.monotonic()-stage_start, 3))
            require(digest(program) == stage['program_pin'], 'Program changed while executing')
            require(all(digest(inside(PAPER, name)) == pin for name,pin in dependency_pins.items()),
                    'Registered dependency changed while executing')
            receipt = output / 'stage-receipt.json'
            if not receipt.is_file():
                row.update(state='FAILED', reason='The driver did not produce its required fresh stage receipt')
                raise ValueError(row['reason'])
            r = receive_stage(receipt, stage, output, job_id, fingerprint)
            row.update(receipt_pin=digest(receipt), scientific_status=r['status'],
                       reexecution=r['reexecution'], reported_claims=r['claims'])
            require(process.returncode == 0 or r['status'] != 'ACCEPTED',
                    'Nonzero process exit cannot be accepted as a successful stage')
            if r['status'] != 'ACCEPTED':
                row.update(state=r['status'], reason=r.get('reason', 'The scientific receiver did not accept this stage'))
                state.update(status=r['status'], scientific_status=r['status'])
                append_event(job, 'SCIENTIFIC_STOP', stage=stage['id'], status=r['status'])
                break
            row.update(state='SUCCEEDED', claims=r['claims'])
            verified.update(r['claims'])
            modes.update({claim: r['reexecution'] for claim in r['claims']})
            append_event(job, 'STAGE_ACCEPTED', stage=stage['id'], claims=r['claims'])
            update()
        else:
            targets = set(profile.get('target_claims', []))
            require(targets <= verified, 'The requested scientific target was not reached')
            if profile.get('full_chain_kind')=='infinite':
                full = set(INFINITE_CHAIN)<=verified and set(INFINITE_CHAIN)<=targets and profile['engine']=='qe'
                full = full and all(modes.get(c)=='fresh_compute' for c in INFINITE_CHAIN[:-1])
                full = full and modes.get(INFINITE_CHAIN[-1]) in ('fresh_compute','received_proof_composition')
            else:
                full = set(FULL_CHAIN) <= verified and set(FULL_CHAIN) <= targets
                full = full and profile['engine'] != 'control'
                full = full and all(modes.get(claim) == 'fresh_compute' for claim in FULL_CHAIN)
            recomputed=full and all(modes.get(c)=='fresh_compute' for c in targets)
            state.update(status='COMPLETED', scientific_status='CERTIFIED_REGISTERED_FULL_CHAIN' if full else 'COMPLETED_WITH_SCOPED_RESULTS',
                         full_chain_certified=full,full_chain_recomputed=recomputed)
        require(input_manifest(profile)[1] == fingerprint, 'Source inputs changed before finalization')
    except Exception as exc:
        failure = str(exc)
        for row in state['stages']:
            if row['state'] == 'RUNNING':
                row.update(state='FAILED', reason=failure)
        state.update(status='FAILED', scientific_status='NOT_CERTIFIED', full_chain_certified=False,
                     error=failure)
        append_event(job, 'EXECUTION_FAILED', reason=failure)
    finally:
        for row in state['stages']:
            if row['state'] == 'WAITING':
                row['state'] = 'NOT_RUN'
        state.update(finished_at=now())
        update()
        append_event(job, 'FINISHED', status=state['status'], full_chain_certified=state['full_chain_certified'])
    return state


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('action', choices=['execute'])
    parser.add_argument('job_id')
    args = parser.parse_args()
    try:
        result = execute(args.job_id)
        print(json.dumps({'id': result['id'], 'status': result['status'],
                          'full_chain_certified': result['full_chain_certified']}))
        return 0 if result['status'] == 'COMPLETED' else 2
    except Exception as exc:
        if ID.fullmatch(args.job_id or '') and (JOBS/args.job_id/'RUN.json').is_file():
            target = JOBS/args.job_id
            state = load(target/'RUN.json')
            if state.get('status') == 'QUEUED':
                state.update(status='FAILED', scientific_status='NOT_CERTIFIED',
                             full_chain_certified=False, error=str(exc), finished_at=now(), updated_at=now())
                for row in state['stages']:
                    row['state'] = 'NOT_RUN'
                save(target/'RUN.json', state)
                append_event(target, 'START_REJECTED', reason=str(exc))
        print(json.dumps({'status': 'RUNNER_REJECTED', 'reason': str(exc)}), file=sys.stderr)
        return 2


if __name__ == '__main__':
    raise SystemExit(main())
