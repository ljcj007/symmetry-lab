"""Actual receivers after an exact fresh72-to-preserved-operator bridge."""
from pathlib import Path
from fractions import Fraction as Q
import argparse
import json
import os
import subprocess
import sys
import time

import runner as R

TASK=R.PAPER/'work/qe_si_end_to_end_20261117'
FROZEN_SHA='e31bf5f774d4872bf24e98b99110b1eb95749546311f95258e5fd296a8554ac6'
BRIDGE_SHA='d35a4ae588ad17d1d759a4a0f9e62ed6b2ecd9b66a5a270329510115d6c5aca0'
NATIVE=Path(__file__).resolve().parent.parent/'native'
sys.path.insert(0,str(NATIVE))
import raw_dft as N


def actual_upstream(job,claim):
    state=R.load(job/'RUN.json')
    R.require(state['id']==os.environ['DFT_PORTAL_RUN_ID'],'Wrong job context')
    R.require(state['source_fingerprint']==os.environ['DFT_PORTAL_SOURCE_FINGERPRINT'],'Wrong job source')
    for row in state['stages']:
        if row['state']=='SUCCEEDED' and claim in row.get('claims',[]):
            output=job/'stages'/row['id']/'output'
            R.require(R.digest(output/'stage-receipt.json')==row['receipt_pin'],'Upstream stage receipt changed')
            return output,R.load(output/'RESULTS.json')
    raise ValueError('Required actual upstream result is absent: '+claim)


def source_bridge(job):
    output,result=actual_upstream(job,'operator_identity_bridge')
    bridge=result.get('exact_operator_bridge',{})
    if not bridge:
        bridge={'received':result.get('every_actual_operator_field_identical'), 'points':result.get('points',[])}
    rows=bridge.get('points',[])
    R.require(bridge.get('received') is True and len(rows)==72,'A complete actual 72-point operator bridge is required')
    R.require({x['ik'] for x in rows}==set(range(1,73)),'Incomplete exact source bridge')
    R.require(all(x['operator_source_identical'] and x['current_operator_identity']==x['reference_operator_identity']
                  and not x['changed_operator_fields'] and not x.get('changed_input_coordinate_or_quadrature_contract',[])
                  for x in rows),'A changed operator cannot inherit the reference proof')
    reference=TASK/'root/native72_v1'
    names=['pw.in']+sorted(p.name for p in reference.glob('ncs_native_k*.bin'))
    current=N.source_inventory('qe',reference,names)
    R.require(result['reference_source']==current,'The bridge does not refer to the preserved native72 proof source')
    if 'local_intakes' in result:
        fresh=output/'job/native72_fresh'
        fresh_names=[r['path'] for r in result['local_intakes']['native72_fresh']['source']['manifest']['files']]
        R.require(N.source_inventory('qe',fresh,fresh_names)==result['local_intakes']['native72_fresh']['source'],
                  'Actual downloaded native source changed after bridge reception')
    return {'upstream_receipt':R.digest(output/'stage-receipt.json'),
            'upstream_result':R.digest(output/'RESULTS.json'),'reference_source':current,
            'actual_operator_identity_bridge_received':True}


def run(program,args,out,label):
    command=[sys.executable,'-B',str(program),*map(str,args)]
    print(json.dumps({'phase':label,'status':'RUNNING'}),flush=True)
    with (out/(label+'.stdout')).open('xb') as stdout,(out/(label+'.stderr')).open('xb') as stderr:
        result=subprocess.run(command,cwd=TASK,stdout=stdout,stderr=stderr)
    R.require(result.returncode==0,'Scientific receiver failed: '+label)
    return {'program':R.digest(program),'arguments':list(map(str,args)),'returncode':result.returncode}


def construction(out,binding):
    program=TASK/'root/verify_native72_canonical_ideal_bridge.py'
    processes=[]
    for i in range(4):
        target=out/('shard'+str(i))
        stdout=(out/('shard'+str(i)+'.stdout')).open('xb')
        stderr=(out/('shard'+str(i)+'.stderr')).open('xb')
        command=[sys.executable,'-B',str(program),'--start',str(18*i),'--stop',str(18*(i+1)),'--out',str(target)]
        process=subprocess.Popen(command,cwd=TASK,stdout=stdout,stderr=stderr)
        processes.append((process,stdout,stderr,target))
        print(json.dumps({'construction_shard':i,'points':18,'status':'RUNNING'}),flush=True)
    receipts=[]
    try:
        for i,(process,stdout,stderr,target) in enumerate(processes):
            R.require(process.wait()==0,'Actual full-factor receiver failed in shard '+str(i))
            stdout.close();stderr.close()
            receipt=R.load(target/'RESULTS.json')
            R.require(receipt['schema']=='actual-native72-canonical-ideal-factor-formula-bridge-shard.v1'
                      and receipt['status']=='CERTIFIED_EXPORTED_FACTOR_FORMULA_SHARD',
                      'Unexpected construction receipt status')
            R.require(receipt['start']==18*i and receipt['stop']==18*(i+1) and receipt['points']==18,
                      'Construction shard coverage differs')
            R.require(len(receipt['rows'])==18 and all(Q(r['operator_norm_difference_upper_Ry'])<Q(1,1000000)
                                                     for r in receipt['rows']),'Construction error budget failed')
            receipts.append({'file':str((target/'RESULTS.json').relative_to(out)),**R.digest(target/'RESULTS.json')})
            print(json.dumps({'construction_shard':i,'status':'ACCEPTED'}),flush=True)
    finally:
        for process,stdout,stderr,_ in processes:
            if process.poll() is None:process.terminate();process.wait()
            stdout.close();stderr.close()
    return {'status':'ACCEPTED_ACTUAL72_CONSTRUCTION_ROUNDING','point_count':72,
            'source_binding':binding,'received_shards':receipts,
            'scope':'Fresh complete exported finite scalar-NC factor-to-canonical ideal literal-table operator bridges, transported to the new native source by exact complete-source identity. Not a proof of compiled QE floating evaluation or nonlinear SCF.'},['construction_rounding_enclosed'],'fresh_compute'


def finite(out,binding,job):
    actual_upstream(job,'construction_rounding_enclosed')
    program=TASK/'scf_validation/C1_center/finalize_reference_scf_v1.py'
    target=out/'finite_reference'
    executed=run(program,['--point-root',TASK/'root/strict72_received_v1/strict_points','--out',target],out,'complete72_scf')
    receipt=R.load(target/'finite_scf/RESULTS.json')
    R.require(receipt.get('finite_reference_symmetric_SCF_fixed_point_certified') is True,'Finite-reference SCF did not receive its radius inequality')
    return {'status':'ACCEPTED_REEXECUTED_FINITE_REFERENCE_SCF','source_binding':binding,'execution':executed,
            'finite_scf_receipt':{'file':'finite_reference/finite_scf/RESULTS.json',**R.digest(target/'finite_scf/RESULTS.json')},
            'actual_work':'Reexecuted 72-point response aggregation, full inverse verification and Banach composition. Received per-point response matrix packets; did not recompute those matrices.',
            'infinite_orbital_nonlinear_SCF_certified':False},['finite_reference_scf_root_enclosed'],'received_proof_composition'


def frozen(out,binding,job):
    source,_=actual_upstream(job,'finite_reference_scf_root_enclosed')
    scf=source/'finite_reference/finite_scf/RESULTS.json'
    frozen=TASK/'root/frozen_retarget_received_v2/symmetrized_ideal_all925/RESULTS.json'
    bridge=TASK/'root/refined_potential_transfer_v1/RESULTS.json'
    R.require(R.digest(frozen)['sha256']==FROZEN_SHA and R.digest(bridge)['sha256']==BRIDGE_SHA,'Frozen parent proof identity changed')
    target=out/'same_potential_spectrum'
    program=TASK/'root/compose_scf_frozen_global_gap.py'
    executed=run(program,['--scf-receipt',scf,'--scf-sha256',R.digest(scf)['sha256'],
                         '--frozen-receipt',frozen,'--frozen-sha256',FROZEN_SHA,
                         '--bridge-receipt',bridge,'--bridge-sha256',BRIDGE_SHA,
                         '--task-root',TASK,'--out',target],out,'same_potential')
    receipt=R.load(target/'RESULTS.json')
    R.require(receipt.get('all_BZ_infinite_frozen_spectrum_at_that_potential_certified') is True,'Same-potential full spectrum was not accepted')
    return {'status':receipt['status'],'source_binding':binding,'execution':executed,
            'spectrum_receipt':{'file':'same_potential_spectrum/RESULTS.json',**R.digest(target/'RESULTS.json')},
            'actual_work':'Recomputed same-potential spectral composition; received the pinned 925-domain infinite frozen-spectrum proof and continuous source bridge. No 925 matrix replay.',
            'infinite_orbital_nonlinear_SCF_certified':False},['infinite_basis_tail_enclosed','same_potential_infinite_global_gap'],'received_proof_composition'


def main():
    p=argparse.ArgumentParser()
    p.add_argument('stage',choices=['construction','finite-scf','frozen-spectrum'])
    p.add_argument('--out',type=Path,required=True)
    a=p.parse_args()
    R.require(not a.out.exists(),'Preserve previous stage outputs')
    a.out.mkdir(parents=True)
    job=Path(os.environ['DFT_PORTAL_JOB_ROOT']).resolve()
    try:
        binding=source_bridge(job)
        if a.stage=='construction':result,claims,mode=construction(a.out,binding)
        elif a.stage=='finite-scf':result,claims,mode=finite(a.out,binding,job)
        else:result,claims,mode=frozen(a.out,binding,job)
        R.save(a.out/'RESULTS.json',result)
        status='ACCEPTED';code=0
    except Exception as exc:
        R.save(a.out/'RESULTS.json',{'status':'UNRESOLVED_REFERENCE_CHAIN','reason':str(exc),'infinite_orbital_nonlinear_SCF_certified':False})
        claims=[];mode='received_proof_composition';status='UNRESOLVED';code=2
    artifacts=[{'path':f.relative_to(a.out).as_posix(),**R.digest(f)} for f in sorted(a.out.rglob('*')) if f.is_file()]
    R.save(a.out/'stage-receipt.json',{'schema':'dft-portal-stage-receipt.v1','run_id':os.environ['DFT_PORTAL_RUN_ID'],
          'source_fingerprint':os.environ['DFT_PORTAL_SOURCE_FINGERPRINT'],'status':status,'reexecution':mode,
          'claims':claims,'artifacts':artifacts,'infinite_orbital_nonlinear_SCF_certified':False})
    return code


if __name__=='__main__':
    raise SystemExit(main())
