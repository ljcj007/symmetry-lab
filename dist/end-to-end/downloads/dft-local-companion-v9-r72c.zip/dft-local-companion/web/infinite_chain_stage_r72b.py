"""Run the approved nonlinear proof checker against this actual QE source."""
from pathlib import Path
import argparse,json,os,subprocess,sys
import runner as R
sys.path.insert(0,str(R.HERE.parent/'native'))
import raw_dft as N

def native_inputs(output):
    result=R.load(output/'RESULTS.json')
    R.require(result.get('native_scf_executed') is True and result.get('native_process_execution_completed') is True,
              'An actual new QE SCF and native export are required')
    files={}
    for case in ('gamma_fresh','native72_fresh'):
        local=output/'job'/case;source=result['local_intakes'][case]['source']
        names=[row['path'] for row in source['manifest']['files']]
        R.require(N.source_inventory('qe',local,names)==source,'Actual native source changed')
        for name in names:
            if name=='pw.in' or name.startswith(('ncs_native_k','pseudo/')):
                files[case+'/'+name]=R.digest(local/name)
    diagnostic=result.get('unmixed_input_source',{}).get('execution',{})
    R.require(diagnostic.get('parent_sources_unchanged') is True and diagnostic.get('maximum_SCF_iterations')==1,
              'This run must include its bounded unmixed-state export')
    for name,pin in diagnostic['streams'].items():
        path=output/'unmixed_input'/name
        R.require(R.digest(path)==pin,'The executed native input-state stream changed')
        files['unmixed_input/'+name]=pin
    files['unmixed_input/pw.in']=R.digest(output/'unmixed_input/pw.in')
    return files

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--recipe',type=Path,required=True);parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args();out=args.out.resolve();R.require(not out.exists(),'Fresh proof-stage output required');out.mkdir(parents=True)
    job=Path(os.environ['DFT_PORTAL_JOB_ROOT']).resolve();state=R.load(job/'RUN.json')
    R.require(state['id']==os.environ['DFT_PORTAL_RUN_ID'] and state['source_fingerprint']==os.environ['DFT_PORTAL_SOURCE_FINGERPRINT'],'Wrong proof job context')
    accepted=False;claims=[];pins={};reason=None
    try:
        recipe=R.load(args.recipe);pins[str(args.recipe.resolve())]=R.digest(args.recipe)
        R.require(recipe.get('schema')=='registered-infinite-SCF-proof-recipe.r72b','Unsupported proof recipe')
        for key in ('native-dft','ionic-input'):
            row=next((s for s in state['stages'] if s['id']==key and s['state']=='SUCCEEDED'),None)
            R.require(row is not None,'Required actual source stage is absent: '+key)
            receipt=job/'stages'/key/'output/stage-receipt.json'
            R.require(R.digest(receipt)==row['receipt_pin'],'Actual upstream receipt changed')
            pins[str(receipt)]=R.digest(receipt)
        native=job/'stages/native-dft/output';actual=native_inputs(native)
        reference=R.inside(R.PAPER,recipe['mathematical_input_identity']['path'])
        R.require(R.digest(reference)==recipe['mathematical_input_identity']['pin'],'Registered source-identity reference changed')
        R.require(actual==R.load(reference)['files'],'The new QE mathematical inputs differ from the approved proof source')
        pins[str(reference)]=R.digest(reference)
        R.save(out/'ACTUAL_NATIVE_INPUT_IDENTITY.json',{'status':'IDENTICAL_COMPLETE_NATIVE_MATHEMATICAL_INPUTS','files':actual,'actual_run_id':state['id']})
        composer=R.inside(R.PAPER,recipe['composer']['path'])
        R.require(R.digest(composer)==recipe['composer']['pin'],'Approved nonlinear receiver changed')
        contract=R.inside(R.PAPER,recipe['contract']['path'])
        R.require(R.digest(contract)==recipe['contract']['pin'],'Frozen nonlinear target contract changed')
        pins.update({str(composer):R.digest(composer),str(contract):R.digest(contract)})
        command=[sys.executable,'-X','utf8','-B',str(composer),'--contract',str(contract),'--out',str(out/'nonlinear-proof')]
        for name,flag in [('all72_map','--all72-map'),('full_response','--full-response'),('whole_ball','--whole-ball'),('fresh_source_bridge','--fresh-source-bridge')]:
            record=recipe.get(name)
            if record is not None:
                path=R.inside(R.PAPER,record['path']);R.require(R.digest(path)==record['pin'],'Registered scientific receipt changed: '+name)
                pins[str(path)]=R.digest(path);command += [flag,str(path)]
        with (out/'receiver.stdout').open('xb') as fo,(out/'receiver.stderr').open('xb') as fe:
            run=subprocess.run(command,stdout=fo,stderr=fe,timeout=600)
        R.require(run.returncode==0,'The approved nonlinear checker failed')
        result=R.load(out/'nonlinear-proof/RESULTS.json')
        R.require(all(R.digest(Path(p))==h for p,h in pins.items()),'Source or proof inputs changed during reception')
        R.require(native_inputs(native)==actual,'Actual QE arrays changed during nonlinear reception')
        accepted=result.get('root_exists') is True and result.get('fresh_source_root_exists') is True
        reason=None if accepted else '; '.join(result.get('remaining_obligations',[]))
        if accepted:claims=['infinite_orbital_nonlinear_scf_root_enclosed']
        R.save(out/'RESULTS.json',{'status':'ACCEPTED_SOURCE_BOUND_INFINITE_SCF_EXISTS' if accepted else 'UNRESOLVED_INFINITE_SCF_EXISTS',
            'actual_run_id':state['id'],'root_exists':accepted,'source_and_program_pins':pins,'reason':reason,
            'mathematical_proof':{'path':'nonlinear-proof/RESULTS.json',**R.digest(out/'nonlinear-proof/RESULTS.json')},
            'infinite_root_uniqueness_claimed':False,'literal_unexported_QE_infinite_generator_certified':False})
    except (ValueError,KeyError,OSError,subprocess.TimeoutExpired) as exc:
        reason=str(exc);R.save(out/'RESULTS.json',{'status':'UNRESOLVED_INFINITE_SCF_EXISTS','root_exists':False,'reason':reason,'source_and_program_pins':pins})
    artifacts=[{'path':p.relative_to(out).as_posix(),**R.digest(p)} for p in sorted(out.rglob('*')) if p.is_file()]
    R.save(out/'stage-receipt.json',{'schema':'dft-portal-stage-receipt.v1','run_id':state['id'],'source_fingerprint':state['source_fingerprint'],
        'status':'ACCEPTED' if accepted else 'UNRESOLVED','reason':reason,'reexecution':'received_proof_composition','claims':claims,'artifacts':artifacts})

if __name__=='__main__':main()
