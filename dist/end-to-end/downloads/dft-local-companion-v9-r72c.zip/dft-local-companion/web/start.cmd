@echo off
set PYTHONDONTWRITEBYTECODE=1
set PYTHONUTF8=1
python -B "%~dp0portal.py" --open %*
pause
