"""Independently receive this run's actual native unmixed ionic source."""
from pathlib import Path
import argparse,json,os,subprocess,sys
import runner as R

SCIENCE=R.PAPER/'work/infinite_scf_20261121'
TASK=R.PAPER/'work/qe_si_end_to_end_20261117'

def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--out',type=Path,required=True)
    args=parser.parse_args()
    out=args.out.resolve()
    R.require(not out.exists(),'Preserve previous stage outputs')
    out.mkdir(parents=True)
    job=Path(os.environ['DFT_PORTAL_JOB_ROOT']).resolve()
    run=R.load(job/'RUN.json')
    R.require(run['id']==os.environ['DFT_PORTAL_RUN_ID'] and run['source_fingerprint']==os.environ['DFT_PORTAL_SOURCE_FINGERPRINT'],'Wrong actual job')
    upstream=next((row for row in run['stages'] if row['state']=='SUCCEEDED' and 'raw_source_intake' in row.get('claims',[])),None)
    R.require(upstream is not None,'Actual complete native source intake is required')
    native=job/'stages'/upstream['id']/'output'
    R.require(R.digest(native/'stage-receipt.json')==upstream['receipt_pin'],'Upstream source receipt changed')
    upstream_result=R.load(native/'RESULTS.json')
    R.require(upstream_result.get('unmixed_input_source') is not None,'Native run did not export its unmixed input state')
    source_before={str(path):R.digest(path) for path in [job/'SOURCE.json',native/'RESULTS.json',native/'stage-receipt.json']}
    input_root=native/'unmixed_input'
    stream=input_root/'ncs_scf_iter00001_call00001.bin'
    decoder=TASK/'scf_validation/decode_scf_stream.py'
    receiver=SCIENCE/'math/proof_closure_20261122/receive_ionic_input_bridge_v2.py'
    code_before={str(path):R.digest(path) for path in [Path(__file__),decoder,receiver]}
    commands=[('decode',[sys.executable,'-X','utf8','-B',str(decoder),str(stream),'--out',str(out/'decoded')]),
              ('ionic',[sys.executable,'-X','utf8','-B',str(receiver),'--new-manifest',str(out/'decoded/MANIFEST.json'),
                        '--new-stream',str(stream),'--new-execution',str(input_root/'RESULTS.json'),
                        '--native-source-root',str(native/'job/native72_fresh'),'--out',str(out/'ionic')])]
    execution=[]
    for name,command in commands:
        with (out/(name+'.stdout')).open('xb') as fo,(out/(name+'.stderr')).open('xb') as fe:
            process=subprocess.run(command,stdout=fo,stderr=fe,timeout=300)
        R.require(process.returncode==0,'Independent input-state receiver failed: '+name)
        execution.append({'program':R.digest(Path(command[4])),'returncode':process.returncode})
    result=R.load(out/'ionic/RESULTS.json')
    R.require(result.get('status')=='CERTIFIED_PROJECTED_IONIC_INPUT_SOURCE_DIFFERENCE_AT_MATCHED_NATIVE_QE_SOURCE','Ionic source was not received')
    R.require(all(R.digest(Path(path))==expected for path,expected in {**source_before,**code_before}.items()),'Actual source or receiver changed during reception')
    R.save(out/'RESULTS.json',{'status':'ACCEPTED_ACTUAL_UNMIXED_IONIC_SOURCE_BRIDGE',
        'actual_run_id':run['id'],'source_fingerprint':run['source_fingerprint'],
        'native_source_result_pin':source_before[str(native/'RESULTS.json')],
        'source_and_program_pins':{**source_before,**code_before},'executed_receivers':execution,
        'ionic_source_receipt':{'path':'ionic/RESULTS.json',**R.digest(out/'ionic/RESULTS.json')},
        'infinite_orbital_nonlinear_scf_certified':False,
        'scope':'This run native actualV minus input-state Hxc, exact projected ionic difference only. Kinetic/nonlocal source-family and nonlinear-root acceptance are separate.'})
    artifacts=[{'path':path.relative_to(out).as_posix(),**R.digest(path)} for path in sorted(out.rglob('*')) if path.is_file()]
    R.save(out/'stage-receipt.json',{'schema':'dft-portal-stage-receipt.v1','run_id':run['id'],
        'source_fingerprint':run['source_fingerprint'],'status':'ACCEPTED','reexecution':'fresh_compute',
        'claims':['ionic_input_source_bridge_enclosed'],'artifacts':artifacts})

if __name__=='__main__': main()
