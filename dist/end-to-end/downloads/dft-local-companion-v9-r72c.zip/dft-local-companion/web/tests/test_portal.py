"""Actual subprocess and HTTP controls; these are not material proofs."""
from pathlib import Path
import datetime
import json
import sys
import threading
import time
import unittest
import urllib.request
import urllib.error
import uuid

HERE=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(HERE))
import runner
import portal

QA=HERE/'qa'/('q'+datetime.datetime.now(datetime.timezone.utc).strftime('%y%m%d%H%M%S')+uuid.uuid4().hex[:4])
QA.mkdir(parents=True)
DEFAULT_JOBS,DEFAULT_PROFILES=runner.JOBS,runner.PROFILES
DRIVER=HERE/'tests/control_driver.py'


def profile(mode,source,all_claims=False):
    source.mkdir(exist_ok=True)
    (source/'input.txt').write_text('manufactured source for protocol controls\n',encoding='utf8')
    return {'schema':'dft-portal-profile.v1','id':'control-'+uuid.uuid4().hex[:12],
            'label':'协议控制（不是材料科学结果）','engine':'control','hidden':True,
            'source_root':source.relative_to(runner.PAPER).as_posix(),'inputs':['input.txt'],
            'target_claims':runner.FULL_CHAIN if all_claims else ['raw_source_intake'],
            'scope':'Manufactured controls only; no DFT or mathematical proof.',
            'stages':[{'id':'control','label':'协议控制','program':DRIVER.relative_to(runner.PAPER).as_posix(),
                       'program_pin':runner.digest(DRIVER),'arguments':['--mode',mode,'--out','{stage_output}','--source',str(source/'input.txt')],
                       'timeout_seconds':15,'receipt':'stage-receipt.json',
                       'claims':runner.FULL_CHAIN if all_claims else ['raw_source_intake']}]}


class RunnerControls(unittest.TestCase):
    def setUp(self):
        self.folder=QA/uuid.uuid4().hex[:8];self.folder.mkdir()
        runner.JOBS=self.folder/'jobs';runner.PROFILES=self.folder/'profiles';runner.PROFILES.mkdir()

    def tearDown(self):
        runner.JOBS,runner.PROFILES=DEFAULT_JOBS,DEFAULT_PROFILES

    def execute(self,mode,**kwargs):
        p=profile(mode,self.folder/'source',**kwargs)
        runner.save(runner.profile_path(p['id']),p)
        job=runner.create_job(p['id'])
        return runner.execute(job),job

    def test_actual_process_and_scoped_receipt(self):
        result,job=self.execute('normal')
        self.assertEqual(result['status'],'COMPLETED')
        self.assertFalse(result['full_chain_certified'])
        self.assertEqual(result['scientific_status'],'COMPLETED_WITH_SCOPED_RESULTS')
        self.assertIn('Manufactured protocol',(runner.JOBS/job/'stages/control/stdout.log').read_text())
        before=runner.digest(runner.JOBS/job/'RUN.json')
        with self.assertRaises(ValueError):runner.execute(job)
        self.assertEqual(before,runner.digest(runner.JOBS/job/'RUN.json'))

    def test_unresolved_is_preserved(self):
        result,_=self.execute('unresolved')
        self.assertEqual(result['status'],'UNRESOLVED')
        self.assertFalse(result['verified_claims'])

    def test_missing_stage_stops(self):
        p=profile('normal',self.folder/'source')
        p['stages'].append({'id':'missing','label':'尚未实现的证明','program':None,'claims':['infinite_orbital_nonlinear_scf_root_enclosed'],'unavailable_reason':'No actual receiver'})
        runner.save(runner.profile_path(p['id']),p)
        result=runner.execute(runner.create_job(p['id']))
        self.assertEqual(result['status'],'UNRESOLVED')
        self.assertFalse(result['full_chain_certified'])
        self.assertEqual(result['stages'][-1]['reason'],'No actual receiver')

    def test_invalid_receipts_and_changed_source_are_rejected(self):
        for mode in ['stale','wrong-source','inflated','tamper','nonzero','bad-mode','changed-input']:
            with self.subTest(mode=mode):
                result,_=self.execute(mode)
                self.assertEqual(result['status'],'FAILED',result)
                self.assertFalse(result['full_chain_certified'])

    def test_controls_cannot_be_full_scientific_certificates(self):
        for mode in ['all-claims','received-full']:
            result,_=self.execute(mode,all_claims=True)
            self.assertEqual(result['status'],'COMPLETED')
            self.assertFalse(result['full_chain_certified'])

    def test_paths_and_changed_dependencies(self):
        p=profile('normal',self.folder/'source')
        p['inputs']=['../input.txt']
        with self.assertRaises(ValueError):runner.validate_profile(p)
        p=profile('normal',self.folder/'source')
        dependency=self.folder/'dependency.py';dependency.write_text('x=1',encoding='utf8')
        p['stages'][0]['dependencies']=[{'path':dependency.relative_to(runner.PAPER).as_posix(),**runner.digest(dependency)}]
        dependency.write_text('x=2',encoding='utf8')
        with self.assertRaises(ValueError):runner.validate_profile(p)


class HTTPControls(unittest.TestCase):
    def test_loopback_guards_and_real_dispatch(self):
        p=profile('normal',QA/'http-source')
        runner.PROFILES.mkdir(exist_ok=True);runner.JOBS.mkdir(exist_ok=True)
        runner.save(runner.profile_path(p['id']),p)
        server=portal.Portal(('127.0.0.1',0))
        thread=threading.Thread(target=server.serve_forever,daemon=True);thread.start()
        base='http://127.0.0.1:'+str(server.server_address[1])
        cap={'X-DFT-Portal-Capability':server.capability}
        def request(path,body=None,headers=None):
            data=None if body is None else json.dumps(body).encode()
            h={**(headers or {})}
            if body is not None:h['Content-Type']='application/json'
            return urllib.request.urlopen(urllib.request.Request(base+path,data=data,headers=h),timeout=10)
        try:
            self.assertEqual(request('/').status,200)
            with self.assertRaises(urllib.error.HTTPError) as cm:request('/api/jobs')
            self.assertEqual(cm.exception.code,403)
            with self.assertRaises(urllib.error.HTTPError) as cm:request('/api/jobs',headers={**cap,'Origin':'https://unrelated.invalid'})
            self.assertEqual(cm.exception.code,403)
            with self.assertRaises(urllib.error.HTTPError):request('/api/jobs',{'profile_id':p['id'],'command':['arbitrary']},cap)
            with request('/api/jobs',{'profile_id':p['id']},cap) as r:job_id=json.load(r)['id']
            for _ in range(60):
                with request('/api/jobs/'+job_id,headers=cap) as r:state=json.load(r)
                if state['status'] not in ('QUEUED','RUNNING'):break
                time.sleep(.1)
            self.assertEqual(state['status'],'COMPLETED')
            self.assertFalse(state['full_chain_certified'])
            with request('/api/jobs/'+job_id+'/report',headers=cap) as r:
                self.assertEqual(json.load(r)['id'],job_id)
                self.assertIn('attachment',r.headers['Content-Disposition'])
            with request('/api/jobs/'+job_id+'/log?stage=control&stream=stdout&offset=0',headers=cap) as r:
                self.assertIn('Manufactured protocol',json.load(r)['text'])
            with self.assertRaises(urllib.error.HTTPError):request('/api/jobs/'+job_id+'/log?stage=../../wrong',headers=cap)
        finally:
            server.shutdown();server.server_close();thread.join(timeout=5)


if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromModule(sys.modules[__name__])
    result=unittest.TextTestRunner(verbosity=2).run(suite)
    runner.save(QA/'RESULTS.json',{'schema':'dft-portal-protocol-controls.v1','status':'PASS' if result.wasSuccessful() else 'FAIL','tests':result.testsRun,'manufactured_controls_only':True,'no_material_certificate':True})
    print(json.dumps({'status':'PASS' if result.wasSuccessful() else 'FAIL','qa':str(QA),'tests':result.testsRun}))
    raise SystemExit(0 if result.wasSuccessful() else 1)
