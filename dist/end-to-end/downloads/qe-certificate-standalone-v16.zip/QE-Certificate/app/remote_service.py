"""SSH transport for the separately installed, source-bound QE certificate service.

Passwords are carried in memory and an SSH stdin stream only. This module never
constructs shell commands containing credentials and never logs exception text.
SPDX-License-Identifier: GPL-3.0-or-later
"""
from __future__ import annotations

import datetime
import hashlib
import io
import json
import os
from pathlib import Path, PurePosixPath
import shlex
import stat
import time
import uuid
import zipfile


class ServiceError(RuntimeError):
    def __init__(self, code, message):
        self.code = code
        super().__init__(message)


def load_json(sftp, path):
    with sftp.open(str(path), 'rb') as stream:
        data = stream.read(16 * 1024 * 1024 + 1)
    if len(data) > 16 * 1024 * 1024:
        raise ServiceError('INVALID_SERVICE', '服务器返回的运行记录过大。')
    return json.loads(data.decode('utf-8-sig'))


def write_request(sftp, path, value):
    # Paramiko's 'x' sets CREATE|EXCL but does not imply WRITE. 'wx' is both
    # writable and exclusive. Read back the closed file before starting QE.
    with sftp.open(str(path), 'wx') as stream:
        stream.write(json.dumps(value, ensure_ascii=False))
    if load_json(sftp, path) != value:
        raise ServiceError('REQUEST_UPLOAD', '服务器没有完整接收本次运行请求。')


def upload_import(sftp, root, prepared, on_event=lambda event: None):
    """Upload only explicitly selected, immutable-in-transit scientific inputs."""
    from input_import import public_file
    sftp.mkdir(str(root/'upload'))
    sftp.mkdir(str(root/'upload/pseudo'))
    manifest = []
    for index, row in enumerate(prepared['files'], 1):
        relative = PurePosixPath(row['path'])
        if relative.is_absolute() or '..' in relative.parts or relative.parts[0] != 'upload':
            raise ServiceError('IMPORT_PATH', '导入文件的目标位置无效。')
        remote = root/relative
        on_event({'event': 'progress', 'message': f"正在上传输入与赝势（{index}/{len(prepared['files'])}）…"})
        count, digest = 0, hashlib.sha256()
        with row['local_path'].open('rb') as source, sftp.open(str(remote), 'wx') as target:
            if hasattr(target, 'set_pipelined'):
                target.set_pipelined(True)
            while block := source.read(1024**2):
                count += len(block)
                if count > row['bytes']:
                    raise ServiceError('IMPORT_CHANGED', '导入文件在上传时发生变化，请重新选择。')
                digest.update(block)
                target.write(block)
        if count != row['bytes'] or digest.hexdigest() != row['sha256']:
            raise ServiceError('IMPORT_CHANGED', '导入文件在上传时发生变化，请重新选择。')
        count, digest = 0, hashlib.sha256()
        with sftp.open(str(remote), 'rb') as source:
            while block := source.read(1024**2):
                count += len(block)
                if count > row['bytes']:
                    raise ServiceError('IMPORT_TRANSFER', '服务器收到的输入与上传文件不同。')
                digest.update(block)
        if count != row['bytes'] or digest.hexdigest() != row['sha256']:
            raise ServiceError('IMPORT_TRANSFER', '服务器收到的输入与上传文件不同。')
        manifest.append(public_file(row))
    return manifest


def absolute_remote(value):
    if not isinstance(value, str) or not value.startswith('/') or '\n' in value or '\r' in value:
        raise ServiceError('INVALID_SERVICE', '服务器的运行服务设置不完整。')
    path = PurePosixPath(value)
    if '..' in path.parts:
        raise ServiceError('INVALID_SERVICE', '服务器的运行服务设置不完整。')
    return path


def inside_remote(root, value):
    path = absolute_remote(value)
    if not path.is_relative_to(root):
        raise ServiceError('INVALID_SERVICE', '服务器返回了运行目录以外的文件。')
    return path


def safe_extract(archive, destination):
    """Extract only regular files under a fresh result directory."""
    destination = Path(destination).resolve()
    with zipfile.ZipFile(archive) as z:
        if len(z.infolist()) > 100000 or sum(row.file_size for row in z.infolist()) > 12 * 1024**3:
            raise ServiceError('INVALID_RESULTS', '服务器结果包超出支持的大小。')
        seen = set()
        for info in z.infolist():
            name = PurePosixPath(info.filename)
            mode = (info.external_attr >> 16) & 0o170000
            normalized = name.as_posix().rstrip('/').casefold()
            if (name.is_absolute() or '..' in name.parts or ':' in info.filename
                    or '\\' in info.filename or mode not in (0, stat.S_IFREG, stat.S_IFDIR)
                    or normalized in seen):
                raise ServiceError('INVALID_RESULTS', '服务器结果包包含无效路径。')
            seen.add(normalized)
        z.extractall(destination)


def connect(request, known_hosts):
    import paramiko

    host = str(request.get('host', '')).strip()
    user = str(request.get('user', '')).strip()
    password = request.get('password', '')
    try:
        port = int(request.get('port', 22))
    except (TypeError, ValueError):
        raise ServiceError('CONNECTION_FIELDS', '请填写有效的服务器端口。')
    if not host or not user or not 1 <= port <= 65535 or not password:
        raise ServiceError('CONNECTION_FIELDS', '请填写服务器地址、用户名和密码。')
    known_hosts = Path(known_hosts)
    known_hosts.parent.mkdir(parents=True, exist_ok=True)
    client = paramiko.SSHClient()
    if known_hosts.is_file():
        client.load_host_keys(str(known_hosts))
    # First connection records the server key automatically. Changed keys fail.
    client.set_missing_host_key_policy(paramiko.AutoAddPolicy())
    try:
        client.connect(hostname=host, username=user, port=port, password=password,
                       allow_agent=False, look_for_keys=False, timeout=20,
                       auth_timeout=30, banner_timeout=30)
        client.save_host_keys(str(known_hosts))
        client.get_transport().set_keepalive(15)
        return client
    except paramiko.BadHostKeyException:
        client.close()
        raise ServiceError('SERVER_CHANGED', '服务器身份与上次连接不同，连接已停止。') from None
    except paramiko.AuthenticationException:
        client.close()
        raise ServiceError('AUTH_FAILED', '服务器登录失败，请检查用户名和密码。') from None
    except Exception:
        client.close()
        raise ServiceError('CONNECTION_FAILED', '暂时无法连接服务器，请检查地址和网络。') from None


def result_identity(service, state, request):
    """Describe older Si receipts without inventing custom-material proofs."""
    mode = service.get('mode') or request.get('mode', 'si-reference')
    material = service.get('material_name') or request.get('material_name')
    if not material and mode == 'si-reference':
        material = 'Si'
    native_received = service.get('native_operator_received') is True
    if mode == 'si-reference':
        # The v15 service omits the newer flat native flag. Its registered run
        # instead records the actual source claim on the successful stage.
        record = state or {}
        native = next((row for row in record.get('stages', []) if row.get('id') == 'native-dft'), {})
        verified = set(record.get('verified_claims', [])) | set(native.get('claims', []))
        accepted_source = 'raw_source_intake' in verified or service.get('full_chain_certified') is True
        native_received = native_received or (native.get('state') == 'SUCCEEDED' and accepted_source)
    return dict(mode=mode, material_name=material, native_operator_received=native_received)


def run(request, result_directory, state_directory, on_event=lambda event: None,
        poll_seconds=3, max_seconds=10800):
    """Run one fresh server job and download the resulting certificate bundle."""
    request.setdefault('port', 22)
    result_directory = Path(result_directory).resolve()
    result_directory.mkdir(parents=True, exist_ok=False)
    client = None
    sftp = None
    password = request.pop('password', '')
    started = time.monotonic()
    try:
        mode = request.get('mode', 'si-reference')
        if mode not in ('si-reference', 'custom-qe'):
            raise ServiceError('IMPORT_MODE', '请选择内置示例或导入自定义 QE 输入。')
        prepared = None
        if mode == 'custom-qe' and not request.get('resume_output'):
            from input_import import ImportErrorDetail, prepare_import
            on_event({'event': 'progress', 'message': '正在检查导入的 QE 输入与赝势…'})
            try:
                prepared = prepare_import(request)
            except (ImportErrorDetail, OSError) as exc:
                raise ServiceError('IMPORT_INVALID', str(exc)) from None
        on_event({'event': 'progress', 'message': '正在连接计算服务器…'})
        client = connect(dict(request, password=password), Path(state_directory)/'known_hosts')
        sftp = client.open_sftp()
        home = absolute_remote(sftp.normalize('.'))
        manifest = load_json(sftp, home/'.local/share/qe-certificate/server.json')
        if manifest.get('schema') not in ('qe-certificate-server.v1', 'qe-certificate-server.v2'):
            raise ServiceError('SERVICE_NOT_INSTALLED', '这台服务器尚未安装完整的 QE 证书运行服务。')
        root = absolute_remote(manifest.get('root'))
        python = absolute_remote(manifest.get('python'))
        entry = inside_remote(root, manifest.get('custom_entry', manifest.get('entry'))
                              if mode == 'custom-qe' else manifest.get('entry'))
        safe_request = {
            'schema': 'qe-certificate-request.v2' if mode == 'custom-qe' else 'qe-certificate-request.v1',
            'connection': {key: request[key] for key in ('host', 'user', 'port')},
        }
        if request.get('resume_output'):
            output = inside_remote(root/'runs', request['resume_output'])
            if output.name != 'output':
                raise ServiceError('INVALID_SERVICE', '上次任务的连接记录无效。')
            sftp.stat(str(output))
            run_id = output.parent.name
            on_event({'event': 'progress', 'message': '正在重新连接上次任务；不会重新提交 QE 计算。'})
        else:
            capabilities = manifest.get('capabilities', {})
            supports_custom = (manifest.get('custom_qe') is True
                               or isinstance(capabilities, dict) and capabilities.get('custom_qe') is True
                               or isinstance(capabilities, list) and 'custom-qe' in capabilities)
            if mode == 'custom-qe' and not supports_custom:
                raise ServiceError('CUSTOM_NOT_AVAILABLE', '这台服务器的运行服务尚未启用自定义材料，请更新服务器服务。')
            run_id = datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dt%H%M%S-') + uuid.uuid4().hex[:12]
            run_root = root/'runs'/run_id
            sftp.mkdir(str(run_root))
            request_path = run_root/'REQUEST.json'
            output = run_root/'output'
            safe_request['id'] = run_id
            if prepared is not None:
                safe_request.update(mode='custom-qe', material_name=prepared['material_name'],
                                    input_files=upload_import(sftp, run_root, prepared, on_event),
                                    preview=prepared['preview'])
            write_request(sftp, request_path, safe_request)
            command = ' '.join(shlex.quote(str(x)) for x in
                               (python, entry, 'start', '--request', request_path, '--out', output))
            stdin, stdout, stderr = client.exec_command(command, timeout=60)
            stdin.write(json.dumps({'password': password})+'\n')
            stdin.flush()
            stdin.channel.shutdown_write()
            # Server start returns after a detached worker has accepted its stdin.
            stdout.channel.settimeout(60)
            response = stdout.read(65537)
            error = stderr.read(65537)
            code = stdout.channel.recv_exit_status()
            stdin.close(); stdout.close(); stderr.close()
            if code != 0:
                raise ServiceError('START_FAILED', '服务器未能启动新任务，请查看服务器运行服务。')
            del response, error
        password = None
        safe_request['id'] = run_id
        on_event({'event': 'started', 'run_id': run_id, 'remote_output': str(output),
                  'result_directory': str(result_directory)})
        local_status = result_directory/'connection.json'
        local_status.write_text(json.dumps(dict(safe_request, remote_output=str(output)),
                                          ensure_ascii=False, indent=2)+'\n', encoding='utf8')
        last = None
        while True:
            if time.monotonic()-started > max_seconds:
                raise ServiceError('WAIT_TIMEOUT', '等待已结束；服务器任务会继续，连接记录已保存在结果目录。')
            try:
                service = load_json(sftp, output/'service.json')
            except FileNotFoundError:
                time.sleep(poll_seconds)
                continue
            status = service.get('status')
            state = None
            if service.get('run_json'):
                run_json = inside_remote(root, service['run_json'])
                try:
                    state = load_json(sftp, run_json)
                except FileNotFoundError:
                    pass
            progress = {'event': 'progress', 'status': status,
                        'stages': [{key: row.get(key) for key in ('id', 'label', 'state')}
                                   for row in (state or {}).get('stages', [])]}
            if progress != last:
                on_event(progress)
                last = progress
            if status in ('SUCCEEDED', 'PARTIAL', 'FAILED', 'ERROR', 'UNRESOLVED'):
                certified = service.get('full_chain_certified') is True
                calculation_completed = service.get('calculation_completed') is True or certified
                finite_certified = (service.get('finite_point_spectrum_certified') is True
                                    or service.get('finite_spectrum_certified') is True)
                archive_path = service.get('result_zip')
                if status == 'SUCCEEDED' and not archive_path:
                    raise ServiceError('RESULTS_MISSING', '服务器还没有生成可取回的运行结果。')
                if archive_path:
                    remote_archive = inside_remote(output, archive_path)
                    on_event({'event': 'progress', 'message': '计算已结束，正在取回证书和运行记录…'})
                    local_archive = result_directory/'QE-certificate-results.zip'
                    sftp.get(str(remote_archive), str(local_archive))
                    safe_extract(local_archive, result_directory/'results')
                public_result = dict(schema='qe-certificate-client-result.v1', run_id=run_id,
                                     status=status, full_chain_certified=certified,
                                     full_chain_recomputed=service.get('full_chain_recomputed') is True,
                                     **result_identity(service, state, request),
                                     calculation_completed=calculation_completed,
                                     finite_point_spectrum_certified=finite_certified,
                                     infinite_scf_certified=service.get('infinite_scf_certified') is True or certified,
                                     verification_level=service.get('verification_level', 'infinite-scf' if certified else 'unresolved'),
                                     message_safe=service.get('message_safe'),
                                     elapsed_seconds=round(time.monotonic()-started, 3),
                                     result_directory=str(result_directory))
                (result_directory/'RESULT.json').write_text(json.dumps(public_result, ensure_ascii=False,
                                                                       indent=2)+'\n', encoding='utf8')
                on_event(dict(public_result, event='finished'))
                return 0 if status == 'SUCCEEDED' and (certified or calculation_completed) else 2
            time.sleep(poll_seconds)
    except ServiceError:
        raise
    except (FileNotFoundError, OSError):
        raise ServiceError('SERVICE_IO', '无法读取服务器运行服务或取回结果，请检查服务器配置。') from None
    except Exception:
        raise ServiceError('SERVICE_FAILED', '服务器任务未完成，已有连接记录保存在结果目录。') from None
    finally:
        password = None
        request.pop('password', None)
        if sftp:
            sftp.close()
        if client:
            client.close()
