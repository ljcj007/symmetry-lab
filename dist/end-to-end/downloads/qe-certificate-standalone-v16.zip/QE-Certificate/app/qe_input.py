"""Shared, dependency-free QE SCF import parser and owned-path normalizer.

This parses input data, never evaluates Fortran or shell code. The original
input is retained separately; server-side copies replace only run-owned I/O
settings and fresh-SCF startup choices. SPDX-License-Identifier: GPL-3.0-or-later
"""
from __future__ import annotations
import math,re,xml.etree.ElementTree as ET
from pathlib import PurePosixPath

MAX_INPUT=2*1024*1024
SAFE_NAME=re.compile(r'^[A-Za-z0-9][A-Za-z0-9._+\-]{0,127}$')
CARDS={'ATOMIC_SPECIES','ATOMIC_POSITIONS','CELL_PARAMETERS','K_POINTS','OCCUPATIONS','CONSTRAINTS','ATOMIC_FORCES','ADDITIONAL_K_POINTS','HUBBARD','SOLVENTS'}
ASSIGN=re.compile(r'([A-Za-z][A-Za-z0-9_]*(?:\(\s*\d+\s*(?:,\s*\d+\s*)?\))?)\s*=')

class InputError(ValueError):pass
def need(v,s):
    if not v:raise InputError(s)

def uncomment(text):
    out=[];quote=None;i=0
    while i<len(text):
        c=text[i]
        if quote:
            out.append(c)
            if c==quote:
                if i+1<len(text)and text[i+1]==quote:out.append(text[i+1]);i+=1
                else:quote=None
        elif c in "'\"":quote=c;out.append(c)
        elif c=='!':
            while i<len(text)and text[i]!='\n':i+=1
            out.append('\n')
        else:out.append(c)
        i+=1
    need(quote is None,'输入文件含未闭合的引号。')
    return ''.join(out)

def unquoted_mask(text):
    out=list(text);quote=None;i=0
    while i<len(text):
        c=text[i]
        if quote:
            out[i]=' '
            if c==quote:
                if i+1<len(text)and text[i+1]==quote:out[i+1]=' ';i+=1
                else:quote=None
        elif c in "'\"":quote=c;out[i]=' '
        i+=1
    return ''.join(out)

def scalar(raw):
    raw=raw.strip().rstrip(',').strip()
    need(bool(raw),'QE 参数缺少数值。')
    if raw[0:1]in("'",'"'):
        q=raw[0];need(raw[-1:]==q and len(raw)>=2,'QE 字符串格式错误。')
        inner=raw[1:-1];need(q not in inner.replace(q+q,''),'QE 字符串含未配对引号。')
        return inner.replace(q+q,q)
    if raw.lower()in('.true.','.false.'):return raw.lower()=='.true.'
    need(re.fullmatch(r'[+\-]?(?:\d+(?:\.\d*)?|\.\d+)(?:[dDeE][+\-]?\d+)?',raw) is not None,'仅支持明确的数值、布尔值或带引号字符串。')
    if re.fullmatch(r'[+\-]?\d+',raw):return int(raw)
    v=float(re.sub('[dD]','e',raw));need(math.isfinite(v),'QE 参数必须为有限数值。');return v

def parse_namelists(clean):
    mask=unquoted_mask(clean);blocks={};rest=list(clean);i=0
    while i<len(mask):
        if mask[i]!='&':i+=1;continue
        match=re.match(r'&([A-Za-z][A-Za-z0-9_]*)',mask[i:]);need(match is not None,'QE namelist 标题无效。')
        name=match[1].lower();need(name in('control','system','electrons'),'目前只导入静态 pw.x SCF 的 CONTROL、SYSTEM、ELECTRONS 段。')
        need(name not in blocks,'QE namelist 重复：'+name)
        begin=i+match.end();end=mask.find('/',begin);need(end>=0,'QE namelist 缺少 / 结束符。')
        need('&'not in mask[begin:end],'QE namelist 缺少 / 结束符。')
        body=clean[begin:end];bm=mask[begin:end];matches=list(ASSIGN.finditer(bm));values={}
        need(not bm[:matches[0].start()].strip(' ,\r\n\t')if matches else not bm.strip(),'QE namelist 头部含未识别文本。')
        for j,m in enumerate(matches):
            key=re.sub(r'\s+','',m[1]).lower();need(key not in values,'QE 参数重复：'+key)
            raw=body[m.end():matches[j+1].start()if j+1<len(matches)else len(body)]
            values[key]=scalar(raw)
        blocks[name]=values
        for k in range(i,end+1):
            if rest[k]!='\n':rest[k]=' '
        i=end+1
    need('system'in blocks,'缺少 &SYSTEM。')
    return blocks,''.join(rest)

def _num(s):
    x=scalar(s);need(type(x)in(int,float),'结构坐标必须为数值。');return x

def inspect_qe_input(text,pseudo_names=None):
    need(isinstance(text,str)and len(text.encode('utf8'))<=MAX_INPUT,'QE 输入文件过大。')
    need('\x00'not in text,'QE 输入文件含无效空字节。')
    clean=uncomment(text.lstrip('\ufeff'));blocks,remaining=parse_namelists(clean)
    system=blocks['system'];control=blocks.setdefault('control',{});blocks.setdefault('electrons',{})
    calc=str(control.get('calculation','scf')).lower()
    need(calc in('scf','nscf'),'当前导入支持 scf / nscf 静态输入；程序会先从原子初猜执行新的 SCF。')
    nat=system.get('nat');ntyp=system.get('ntyp');ibrav=system.get('ibrav',0)
    need(type(nat)is int and 1<=nat<=256,'nat 必须为 1 至 256 的整数。')
    need(type(ntyp)is int and 1<=ntyp<=32,'ntyp 必须为 1 至 32 的整数。')
    need(type(ibrav)is int,'ibrav 必须为整数。')
    ecut=system.get('ecutwfc');need(type(ecut)in(int,float)and 0<ecut<=1000,'ecutwfc 必须为 0 至 1000 Ry 的正值。')
    rho=system.get('ecutrho',4*ecut);need(type(rho)in(int,float)and ecut<=rho<=16000,'ecutrho 必须大于等于 ecutwfc 且不超过 16000 Ry。')
    lines=[s.strip()for s in remaining.splitlines()if s.strip()];cards={};i=0
    while i<len(lines):
        title=lines[i];name=title.split()[0].upper();need(name in CARDS,'未识别或不支持的 QE 输入卡片：'+title[:80])
        need(name not in cards,'QE 输入卡片重复：'+name);i+=1;rows=[]
        while i<len(lines)and lines[i].split()[0].upper()not in CARDS:
            rows.append(lines[i]);i+=1
        cards[name]={'header':title,'rows':rows}
    need(not(set(cards)-{'ATOMIC_SPECIES','ATOMIC_POSITIONS','CELL_PARAMETERS','K_POINTS'}),'当前静态导入不支持约束、外加力、HUBBARD 或自定义占据卡片。')
    need('ATOMIC_SPECIES'in cards and len(cards['ATOMIC_SPECIES']['rows'])==ntyp,'ATOMIC_SPECIES 行数必须等于 ntyp。')
    species=[]
    for row in cards['ATOMIC_SPECIES']['rows']:
        cols=row.split();need(len(cols)==3,'ATOMIC_SPECIES 每行需要元素标签、质量和 UPF 文件名。')
        label,mass,pseudo=cols;need(SAFE_NAME.fullmatch(label)and len(label)<=16,'原子种类标签无效。')
        need(SAFE_NAME.fullmatch(pseudo)and pseudo.lower().endswith('.upf'),'UPF 卡片必须使用不含目录的 .UPF 文件名。')
        mass=_num(mass);need(mass>0,'原子质量必须为正值。')
        species.append({'label':label,'mass':mass,'pseudo':pseudo})
    need(len({s['label']for s in species})==ntyp,'原子种类标签重复。')
    if pseudo_names is not None:
        available=set(pseudo_names);missing=sorted({s['pseudo']for s in species}-available)
        need(not missing,'缺少赝势文件：'+', '.join(missing))
    need('ATOMIC_POSITIONS'in cards and len(cards['ATOMIC_POSITIONS']['rows'])==nat,'ATOMIC_POSITIONS 行数必须等于 nat。')
    unit=cards['ATOMIC_POSITIONS']['header'].split(maxsplit=1)[1].strip('{}() ').lower()if len(cards['ATOMIC_POSITIONS']['header'].split(maxsplit=1))>1 else'alat'
    need(unit in('crystal','angstrom','bohr','alat'),'不支持的 ATOMIC_POSITIONS 单位。')
    labels={s['label']for s in species};positions=[]
    for row in cards['ATOMIC_POSITIONS']['rows']:
        cols=row.split();need(len(cols)in(4,7)and cols[0]in labels,'ATOMIC_POSITIONS 标签或坐标数量无效。')
        pos=[_num(v)for v in cols[1:4]]
        if len(cols)==7:need(all(v in('0','1')for v in cols[4:]),'位置约束只能为 0 或 1。')
        positions.append({'label':cols[0],'coordinates':pos,'unit':unit})
    if ibrav==0:
        need('CELL_PARAMETERS'in cards and len(cards['CELL_PARAMETERS']['rows'])==3,'ibrav=0 需要三行 CELL_PARAMETERS。')
        lattice=[[_num(v)for v in row.split()]for row in cards['CELL_PARAMETERS']['rows']]
        need(all(len(v)==3 for v in lattice),'CELL_PARAMETERS 每行需要三个数值。')
        a,b,c=lattice;det=a[0]*(b[1]*c[2]-b[2]*c[1])-a[1]*(b[0]*c[2]-b[2]*c[0])+a[2]*(b[0]*c[1]-b[1]*c[0])
        need(abs(det)>1e-16,'晶格向量必须线性独立。')
    else:need('CELL_PARAMETERS'not in cards,'ibrav 非零时请用对应晶格参数，不同时给 CELL_PARAMETERS。')
    need('K_POINTS'in cards,'缺少 K_POINTS 卡片。')
    kp=cards['K_POINTS'];parts=kp['header'].split(maxsplit=1);kind=parts[1].strip('{}() ').lower()if len(parts)>1 else'tpiba'
    if kind=='automatic':
        need(len(kp['rows'])==1,'K_POINTS automatic 需要一行网格参数。');q=kp['rows'][0].split();need(len(q)==6 and all(re.fullmatch(r'\d+',v)for v in q),'k 网格必须为六个整数。');q=list(map(int,q));need(all(1<=v<=64 for v in q[:3])and all(v in(0,1)for v in q[3:]),'k 网格或位移参数无效。');need(math.prod(q[:3])<=4096,'导入 k 网格最多 4096 个完整网格点。');kpoints={'kind':kind,'mesh':q[:3],'shifts':q[3:],'maximum_points':math.prod(q[:3])}
    elif kind=='gamma':need(not kp['rows'],'K_POINTS gamma 不应再给点列表。');kpoints={'kind':'gamma','count':1,'maximum_points':1}
    elif kind in('crystal','tpiba'):
        need(kp['rows']and re.fullmatch(r'\d+',kp['rows'][0]),'显式 k 点列表需要点数。');count=int(kp['rows'][0]);need(1<=count<=256 and len(kp['rows'])==count+1,'显式 k 点行数错误或超过 256 点。');points=[]
        for row in kp['rows'][1:]:
            v=[_num(x)for x in row.split()];need(len(v)==4 and v[3]>0,'显式 k 点需要三个坐标与正权重。');points.append(v)
        kpoints={'kind':kind,'count':count,'maximum_points':count,'points':points}
    else:raise InputError('仅支持 gamma、automatic、crystal 或 tpiba k 点；能带路径请先作为静态 SCF 点集导入。')
    nbnd=system.get('nbnd');need(nbnd is None or type(nbnd)is int and 1<=nbnd<=256,'nbnd 必须为 1 至 256 的整数。')
    nspin=system.get('nspin',1);noncolin=system.get('noncolin',False);soc=system.get('lspinorb',False)
    unsupported=[]
    if nspin!=1 or noncolin or soc:unsupported.append('spin-orbit-or-spin-polarized')
    if any(k.startswith(('hubbard_','lda_plus_u'))and v not in(False,0)for k,v in system.items()):unsupported.append('hubbard-u')
    for k in('lelfield','tefield','dipfield','lfcp','trism'):
        if control.get(k)or system.get(k):unsupported.append(k)
    if str(system.get('input_dft','')).lower()in('hse','hse06','pbe0','b3lyp','scan','tpss','r2scan'):unsupported.append('hybrid-or-meta-gga')
    occupations=str(system.get('occupations','fixed')).lower();need(occupations in('fixed','smearing','tetrahedra','tetrahedra_opt','tetrahedra_lin'),'不支持该 occupations 方式。')
    summary={'species':species,'positions':positions,'nat':nat,'ntyp':ntyp,'ibrav':ibrav,'ecutwfc':ecut,'ecutrho':rho,'nbnd':nbnd,'k_points':kpoints,'occupations':occupations,'nspin':nspin,'noncolin':noncolin,'lspinorb':soc,'calculation':calc,'pseudo_dir':control.get('pseudo_dir','.'),'input_dft':system.get('input_dft'),'scalar_nc_export_model_candidate':not unsupported,'unsupported_native_models':sorted(set(unsupported))}
    for name,params in blocks.items():
        for key,value in params.items():
            if isinstance(value,str)and('/'in value or'\\'in value):
                need(name=='control'and key in('outdir','pseudo_dir','wfcdir','prefix'),'只允许由程序接管的运行目录参数包含路径。')
    return summary

def inspect_upf(text):
    need(isinstance(text,str)and len(text.encode('utf8'))<=64*1024*1024,'UPF 文件过大。')
    match=re.search(r'<PP_HEADER\b([^>]*?)(?:/>|>(.*?)</PP_HEADER\s*>)',text,re.I|re.S)
    need(match is not None,'未找到 UPF 的 PP_HEADER。')
    attributes=match[1]
    if '='in attributes:
        h=ET.fromstring('<PP_HEADER '+attributes+'/>').attrib
        kind=h.get('pseudo_type','').upper();element=h.get('element','').strip();valence=_num(h.get('z_valence','nan'))
        if h.get('is_paw','F').upper()in('T','TRUE','.TRUE.'):kind='PAW'
        elif h.get('is_ultrasoft','F').upper()in('T','TRUE','.TRUE.'):kind='US'
        functional=h.get('functional','').strip();has_so=h.get('has_so','F').upper()in('T','TRUE','.TRUE.')
    else:
        rows=[s.strip()for s in(match[2]or'').splitlines()if s.strip()]
        need(len(rows)>=6,'旧版 UPF 头部不完整。');element=rows[1].split()[0];kind=rows[2].split()[0].upper();functional=rows[4];valence=_num(rows[5].split()[0]);has_so=False
    need(0<valence<=128,'UPF 价电子数无效。')
    return {'element':element,'pseudo_type':kind,'z_valence':valence,'functional':functional,'has_so':has_so,'norm_conserving':kind=='NC'}

def normalize_qe_input(text,calculation='scf',prefix='custom',nbnd=None):
    """Preserve physical input, give every run its own paths and fresh startup."""
    summary=inspect_qe_input(text);blocks,remaining=parse_namelists(uncomment(text.lstrip('\ufeff')))
    need(calculation in('scf','nscf'),'执行步骤必须为 scf 或 nscf。')
    control=blocks.setdefault('control',{});control.update(calculation=calculation,prefix=prefix,outdir='./out',pseudo_dir='./pseudo',restart_mode='from_scratch',verbosity='high',disk_io='low',max_seconds=3600)
    control.pop('wfcdir',None)
    electrons=blocks.setdefault('electrons',{});electrons.update(startingpot='atomic'if calculation=='scf'else'file',startingwfc='atomic+random')
    # The exporter needs at least one unoccupied state; callers determine nbnd
    # from this run's electron count, never assume rank4 from the Si example.
    if nbnd is not None:blocks['system']['nbnd']=nbnd
    if summary['k_points']['kind']=='gamma':
        remaining=re.sub(r'(?im)^\s*K_POINTS\s*[({]?gamma[)}]?\s*$', 'K_POINTS crystal\n1\n0 0 0 1',remaining)
    def fmt(v):
        if type(v)is bool:return'.true.'if v else'.false.'
        if isinstance(v,str):return"'"+v.replace("'","''")+"'"
        return repr(v)
    result=''
    for name in('control','system','electrons'):
        result+='&'+name.upper()+'\n'+''.join(' '+k+'='+fmt(v)+',\n'for k,v in blocks[name].items())+'/\n'
    return result+remaining.strip()+'\n'
