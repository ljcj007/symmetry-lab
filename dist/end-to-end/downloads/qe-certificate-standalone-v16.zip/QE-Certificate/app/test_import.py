"""Real input parsing and selected-file controls, using a small carbon input."""
from pathlib import Path
import tempfile,unittest
import input_import as importer

INPUT="""&CONTROL
 calculation='scf', prefix='carbon', pseudo_dir='./pseudo', outdir='./out',
/
&SYSTEM
 ibrav=2, celldm(1)=6.7, nat=2, ntyp=1, ecutwfc=12,
 occupations='fixed',
/
&ELECTRONS
 conv_thr=1.d-9,
/
ATOMIC_SPECIES
C 12.011 C.UPF
ATOMIC_POSITIONS crystal
C 0 0 0
C 0.25 0.25 0.25
K_POINTS gamma
"""

class ImportControls(unittest.TestCase):
    def fixture(self,root,text=INPUT):
        (root/'carbon.in').write_text(text,encoding='utf8')
        return root/'carbon.in'
    def test_real_parser_explains_structure_and_required_upf(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root)
            _,summary=importer.load_input(path)
            self.assertEqual(summary['nat'],2);self.assertEqual(summary['ntyp'],1)
            self.assertEqual(importer.required_pseudos(summary),['C.UPF'])
            self.assertIn('12 Ry',importer.preview_text(summary));self.assertIn('gamma',importer.preview_text(summary))
    def test_missing_upf_has_clear_error(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root)
            with self.assertRaises(importer.ImportErrorDetail)as error:importer.prepare_import(dict(qe_input_path=str(path)))
            self.assertIn('C.UPF',str(error.exception))
    def test_selected_folder_and_case_alias_upload_only_exact_needed_sources(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root);folder=root/'selected';folder.mkdir()
            (folder/'c.upf').write_bytes(b'actual-upf');(folder/'other.UPF').write_bytes(b'unrelated')
            value=importer.prepare_import(dict(qe_input_path=str(path),pseudo_directory=str(folder)))
            self.assertEqual(len(value['files']),2)
            self.assertEqual(value['files'][1]['path'],'upload/pseudo/C.UPF')
            public=importer.public_file(value['files'][1]);self.assertNotIn('local_path',public)
            self.assertEqual(public['bytes'],10)
    def test_file_path_in_upf_card_is_rejected(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root,INPUT.replace('C.UPF','../C.UPF'))
            with self.assertRaises(importer.ImportErrorDetail):importer.load_input(path)
    def test_spin_model_stays_importable_without_claiming_nc_export_support(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root,INPUT.replace('occupations=','nspin=2, occupations='))
            _,summary=importer.load_input(path)
            self.assertFalse(summary['scalar_nc_export_model_candidate']);self.assertEqual(summary['nspin'],2)
    def test_control_character_material_name_is_rejected(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root);(root/'C.UPF').write_bytes(b'upf')
            with self.assertRaises(importer.ImportErrorDetail):
                importer.prepare_import(dict(qe_input_path=str(path),material_name='bad\nname'))

if __name__=='__main__':unittest.main()
