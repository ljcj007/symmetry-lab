"""Portable desktop entry for QE to infinite-orbital SCF certificates.
SPDX-License-Identifier: GPL-3.0-or-later
"""
from __future__ import annotations

import argparse
import datetime
import json
import os
from pathlib import Path
import queue
import subprocess
import sys
import threading
import uuid

# GUI workers use an explicitly UTF-8 JSON pipe even on a Windows host whose
# default console code page is cp936. pythonw may not have standard streams.
for _stream in (sys.stdin, sys.stdout, sys.stderr):
    if _stream is not None and hasattr(_stream, 'reconfigure'):
        _stream.reconfigure(encoding='utf-8')

HERE = Path(__file__).resolve().parent
ROOT = HERE.parent
STATE = ROOT/'Settings'
RESULTS = ROOT/'Results'
os.environ['TCL_LIBRARY'] = str(ROOT/'runtime/tcl/tcl8.6')
os.environ['TK_LIBRARY'] = str(ROOT/'runtime/tcl/tk8.6')
os.environ['PYTHONDONTWRITEBYTECODE'] = '1'
if hasattr(sys, 'set_int_max_str_digits'):
    sys.set_int_max_str_digits(0)


def emit(event):
    if sys.stdout is not None:
        print(json.dumps(event, ensure_ascii=False), flush=True)


def load_settings():
    try:
        value = json.loads((STATE/'connection.json').read_text(encoding='utf8'))
        return {key: value[key] for key in ('host', 'user', 'port') if key in value}
    except (OSError, ValueError, TypeError):
        return {}


def save_settings(request):
    STATE.mkdir(parents=True, exist_ok=True)
    (STATE/'connection.json').write_text(json.dumps({key: request[key] for key in ('host', 'user', 'port')},
                                                   ensure_ascii=False, indent=2)+'\n', encoding='utf8')


def load_last_job():
    try:
        value = json.loads((STATE/'last-job.json').read_text(encoding='utf8'))
        return {key: value[key] for key in ('host', 'user', 'port', 'remote_output')} | {'mode': value.get('mode', 'si-reference')}
    except (OSError, ValueError, KeyError, TypeError):
        return None


def diagnose(smoke_tk=False):
    import importlib
    modules = ('ssl', 'tkinter', 'paramiko', 'cryptography', 'bcrypt', 'nacl', 'cffi', 'invoke')
    origins = {name: str(Path(importlib.import_module(name).__file__).resolve()) for name in modules}
    result = dict(schema='qe-certificate-portable-diagnostics.v1', python=sys.version.split()[0],
                  executable=str(Path(sys.executable).resolve()), modules=origins,
                  all_modules_inside_bundle=all(Path(path).is_relative_to(ROOT) for path in origins.values()),
                  sys_path=list(sys.path), local_project_required=False,
                  external_python_required=False)
    import tkinter
    tcl = tkinter.Tcl()
    result['tcl_library'] = tcl.eval('info library')
    result['tcl_version'] = tcl.eval('info patchlevel')
    if smoke_tk:
        window = tkinter.Tk()
        window.withdraw()
        window.title('QE 独立运行')
        window.update_idletasks()
        result['tk_version'] = window.tk.eval('package present Tk')
        window.destroy()
        from material_gui import launch
        result['material_import_gui'] = launch(sys.modules[__name__], smoke=True)
    return result


def worker(out):
    from remote_service import ServiceError, run
    request = None
    try:
        request = json.loads(sys.stdin.readline())
        return run(request, out, STATE, on_event=emit)
    except ServiceError as exc:
        emit(dict(event='error', code=exc.code, message=str(exc)))
        return 2
    except Exception:
        emit(dict(event='error', code='REQUEST_FAILED', message='无法启动本次任务，请检查连接信息。'))
        return 2
    finally:
        if isinstance(request, dict):
            request.pop('password', None)


def execute(request, out, callback):
    environment = os.environ.copy()
    for key in ('DFT_SSH_PASSWORD', 'PYTHONPATH', 'PYTHONHOME'):
        environment.pop(key, None)
    command = [str(ROOT/'runtime/python.exe'), '-I', '-X', 'utf8', '-B', str(HERE/'main.py'),
               '--headless-run', '--result-directory', str(out)]
    flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
    try:
        child = subprocess.Popen(command, stdin=subprocess.PIPE, stdout=subprocess.PIPE,
                                 stderr=subprocess.DEVNULL, text=True, encoding='utf8',
                                 env=environment, creationflags=flags)
    except Exception:
        request.pop('password', None)
        callback(dict(event='error', code='START_FAILED', message='程序的运行环境不完整，请重新解压完整下载包。'))
        return 2
    child.stdin.write(json.dumps(request, ensure_ascii=False)+'\n')
    child.stdin.close()
    request.pop('password', None)
    terminal = False
    for line in child.stdout:
        try:
            event = json.loads(line)
            if event.get('event') in ('progress', 'started', 'finished', 'error'):
                terminal = terminal or event['event'] in ('finished', 'error')
                callback(event)
        except (ValueError, AttributeError):
            continue
    child.stdout.close()
    code = child.wait()
    if not terminal:
        callback(dict(event='error', code='STOPPED', message='程序已停止，已有记录保存在结果目录。'))
    return code


def gui():
    from material_gui import launch
    launch(sys.modules[__name__])


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--headless-run', action='store_true')
    parser.add_argument('--result-directory', type=Path)
    parser.add_argument('--diagnose', action='store_true')
    parser.add_argument('--smoke-tk', action='store_true')
    parser.add_argument('--report', type=Path)
    args = parser.parse_args()
    if args.diagnose:
        result = diagnose(args.smoke_tk)
        if args.report:
            args.report.write_text(json.dumps(result, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
        emit(result)
        return 0
    if args.headless_run:
        if args.result_directory is None:
            parser.error('--result-directory is required')
        return worker(args.result_directory)
    gui()
    return 0


if __name__ == '__main__':
    raise SystemExit(main())
