"""Import only the selected QE input and its explicitly required UPF files.

The server parses the original input independently. Local paths are never
part of the server request or certificate metadata.
SPDX-License-Identifier: GPL-3.0-or-later
"""
from pathlib import Path, PurePosixPath
import hashlib
import stat

MAX_INPUT = 2 * 1024**2
MAX_UPF = 64 * 1024**2
MAX_TOTAL = 1024**3


class ImportErrorDetail(ValueError):
    pass


def safe_name(value):
    if (not isinstance(value, str) or not value or value in ('.', '..')
            or PurePosixPath(value).name != value or '\\' in value or ':' in value
            or any(ord(c) < 32 for c in value) or len(value) > 200):
        raise ImportErrorDetail('赝势文件名无效，请使用输入中指定的单个 UPF 文件名。')
    return value


def load_input(path):
    from qe_input import inspect_qe_input
    path = Path(path).resolve()
    if not path.is_file() or path.stat().st_size > MAX_INPUT:
        raise ImportErrorDetail('请选择小于 2 MB 的 QE 输入文件。')
    raw = path.read_bytes()
    try:
        text = raw.decode('utf-8-sig')
    except UnicodeError:
        raise ImportErrorDetail('输入文件应使用 UTF-8 或 ASCII 编码。') from None
    try:
        summary = inspect_qe_input(text)
    except ValueError as exc:
        raise ImportErrorDetail(str(exc)) from None
    return raw, summary


def required_pseudos(summary):
    rows = summary.get('species', [])
    names = [safe_name(row.get('pseudo', row.get('pseudopotential', row.get('file'))))
             for row in rows]
    if not names:
        raise ImportErrorDetail('输入文件中没有可识别的 ATOMIC_SPECIES 赝势清单。')
    unique = list(dict.fromkeys(names))
    if len({n.casefold() for n in unique}) != len(unique):
        raise ImportErrorDetail('赝势文件名只在大小写上不同，请使用不同名称。')
    return unique


def find_pseudos(input_path, summary, selected=(), folder=None):
    input_path = Path(input_path).resolve()
    candidates = {}
    for p in selected or ():
        p = Path(p).resolve()
        if not p.is_file():
            raise ImportErrorDetail('选中的赝势文件不存在。')
        key = p.name.casefold()
        if key in candidates and candidates[key] != p:
            raise ImportErrorDetail('选中了同名赝势文件，请只保留本次使用的一份。')
        candidates[key] = p
    directories = []
    if folder:
        directories.append(Path(folder).resolve())
    directories.extend((input_path.parent, input_path.parent/'pseudo'))
    pseudo_dir = summary.get('pseudo_dir')
    if pseudo_dir and isinstance(pseudo_dir, str):
        p = Path(pseudo_dir)
        if not p.is_absolute() and '..' not in p.parts:
            directories.append(input_path.parent/p)
    for directory in dict.fromkeys(directories):
        if directory.is_dir():
            for p in directory.iterdir():
                if p.is_file() and p.suffix.lower() == '.upf':
                    candidates.setdefault(p.name.casefold(), p.resolve())
    names = required_pseudos(summary)
    missing = [n for n in names if n.casefold() not in candidates]
    if missing:
        raise ImportErrorDetail('缺少赝势文件：'+'、'.join(missing)+'。请选择对应 UPF 文件或所在文件夹。')
    return [(name, candidates[name.casefold()]) for name in names]


def source_row(path, role, relative, original_name, limit):
    path = Path(path).resolve()
    meta = path.stat()
    if not stat.S_ISREG(meta.st_mode) or not 0 < meta.st_size <= limit:
        raise ImportErrorDetail('输入或赝势文件超出支持的大小，或不是普通文件。')
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    if path.stat().st_size != meta.st_size:
        raise ImportErrorDetail('导入文件在读取时发生变化，请重新选择。')
    return dict(local_path=path, role=role, path=relative,
                original_name=original_name, bytes=meta.st_size, sha256=digest)


def prepare_import(request):
    path = Path(request.get('qe_input_path', '')).resolve()
    _, summary = load_input(path)
    selected = find_pseudos(path, summary, request.get('upf_paths', ()), request.get('pseudo_directory'))
    files = [source_row(path, 'qe-input', 'upload/pw.in', path.name, MAX_INPUT)]
    files += [source_row(p, 'pseudopotential', 'upload/pseudo/'+name, p.name, MAX_UPF)
              for name, p in selected]
    if sum(r['bytes'] for r in files) > MAX_TOTAL:
        raise ImportErrorDetail('本次导入文件合计超过 1 GB。')
    brief = {k: summary.get(k) for k in
             ('nat', 'ntyp', 'ibrav', 'ecutwfc', 'ecutrho', 'occupations', 'nspin',
              'noncolin', 'lspinorb', 'calculation', 'k_points') if k in summary}
    brief['species'] = summary.get('species', [])
    name = str(request.get('material_name') or path.stem).strip()
    if not name or len(name) > 160 or any(ord(c) < 32 for c in name):
        raise ImportErrorDetail('材料名称应为 1 至 160 个字符。')
    return dict(material_name=name, files=files, preview=brief, summary=summary)


def public_file(row):
    return {k: row[k] for k in ('role', 'path', 'original_name', 'bytes', 'sha256')}


def preview_text(summary):
    elements = ', '.join(str(r.get('label', r.get('symbol', '?'))) for r in summary.get('species', []))
    kp = summary.get('k_points', {})
    if isinstance(kp, dict):
        k_text = str(kp.get('mode', kp.get('kind', '')))
        mesh = kp.get('mesh', kp.get('grid'))
        if mesh:
            k_text += '  '+' × '.join(map(str, mesh[:3]))
        elif kp.get('count'):
            k_text += '  '+str(kp['count'])+' 点'
    else:
        k_text = str(kp)
    spin = '自旋轨道/非共线' if summary.get('noncolin') or summary.get('lspinorb') else \
           '自旋极化' if summary.get('nspin') == 2 else '标量/非磁性'
    return (f"元素：{elements}　原子：{summary.get('nat', '?')}　晶格类型：{summary.get('ibrav', '?')}\n"
            f"平面波截断：{summary.get('ecutwfc', '?')} Ry　电荷截断：{summary.get('ecutrho', '默认')} Ry\n"
            f"k 点：{k_text}　模型：{spin}　占据：{summary.get('occupations', 'fixed')}")


def pseudo_preview(selected):
    """Read only bounded UPF headers for display, never use this as a proof."""
    from qe_input import inspect_upf
    models = []
    for name, path in selected:
        try:
            with Path(path).open('rb') as stream:
                header = stream.read(512 * 1024).decode('utf8', 'replace')
            value = inspect_upf(header)
            models.append(value['pseudo_type'])
        except (OSError, ValueError, KeyError):
            models.append('待服务器识别')
    return 'UPF 模型：'+'、'.join(dict.fromkeys(models)) if models else ''
