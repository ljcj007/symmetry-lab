"""Test the extracted Windows client from an unrelated temporary directory."""
import argparse
import json
import os
import re
from pathlib import Path
import subprocess
import tempfile
import zipfile


def verify(archive):
    with tempfile.TemporaryDirectory(prefix='QE portable 无Python ') as temp:
        root = Path(temp)
        with zipfile.ZipFile(archive) as z:
            z.extractall(root)
        bundle = root/'QE-Certificate'
        env = os.environ.copy()
        env['PATH'] = ''
        env['PYTHONPATH'] = str(root/'nonexistent-external-modules')
        env['PYTHONHOME'] = str(root/'nonexistent-external-python')
        env['TCL_LIBRARY'] = str(root/'nonexistent-external-tcl')
        env['TK_LIBRARY'] = str(root/'nonexistent-external-tk')
        cwd = root/'unrelated working directory'
        cwd.mkdir()
        python = bundle/'runtime/python.exe'
        report = root/'native-diagnostics.json'
        command = [str(bundle/'一键运行.exe'), '--diagnose', '--smoke-tk', '--report', str(report)]
        run = subprocess.run(command, env=env, cwd=cwd, capture_output=True, timeout=60)
        assert run.returncode == 0, 'Native executable failed to launch the included runtime.'
        data = json.loads(report.read_text(encoding='utf8'))
        assert data['all_modules_inside_bundle']
        assert all(Path(path).is_relative_to(bundle) for path in data['sys_path'])
        assert Path(data['tcl_library']).is_relative_to(bundle)
        assert data['tk_version'] == '8.6.15'
        assert all(data['material_import_gui'].values())
        tests = subprocess.run([str(python), '-I', '-B', str(bundle/'app/test_client.py')],
                               cwd=cwd, env=env, capture_output=True, text=True,
                               encoding='utf8', timeout=60)
        assert tests.returncode == 0, tests.stderr
        imports = subprocess.run([str(python), '-I', '-B', str(bundle/'app/test_import.py')],
                               cwd=cwd, env=env, capture_output=True, text=True,
                               encoding='utf8', timeout=60)
        assert imports.returncode == 0, imports.stderr
        protocol_count=int(re.search(r'Ran (\d+) tests',tests.stderr)[1])
        import_count=int(re.search(r'Ran (\d+) tests',imports.stderr)[1])
        # Exercise real Chinese JSON bytes from a child, rather than merely
        # reading an ASCII-only report file. Force the legacy code page mode.
        utf8_report = []
        for arguments in (['-I', '-B'], ['-I', '-X', 'utf8', '-B']):
            out = root/('utf8-worker-'+str(len(utf8_report)))
            child_env = env.copy()
            child_env['PYTHONUTF8'] = '0'
            worker = subprocess.run([str(python), *arguments, str(bundle/'app/main.py'),
                                     '--headless-run', '--result-directory', str(out)],
                                    input=b'invalid JSON request\n', cwd=cwd, env=child_env,
                                    capture_output=True, timeout=60)
            event = json.loads(worker.stdout.decode('utf-8'))
            assert worker.returncode == 2 and event['event'] == 'error'
            assert event['message'] == '无法启动本次任务，请检查连接信息。'
            assert event['message'].encode('utf-8') in worker.stdout
            utf8_report.append(dict(arguments=arguments, chinese_json_utf8=True))
        english_report = root/'english-diagnostics.json'
        run = subprocess.run([str(bundle/'Run.exe'), '--diagnose', '--report', str(english_report)],
                             cwd=cwd, env=env, capture_output=True, timeout=60)
        assert run.returncode == 0 and english_report.is_file()
        assert (bundle/'Run.exe').read_bytes() == (bundle/'一键运行.exe').read_bytes()
        assert not (bundle/'runtime/Lib/site-packages/sitecustomize.py').exists()
        for name in ('Run.cmd', '一键运行.cmd'):
            content = (bundle/name).read_bytes()
            content.decode('ascii')
            assert b'\r\n' in content and b'\n' not in content.replace(b'\r\n', b'')
        assert not (bundle/'paper').exists()
        return dict(schema='qe-certificate-windows-portability-controls.v1', status='PASS',
                    archive=str(archive.resolve()), tests=protocol_count+import_count,
                    protocol_tests=protocol_count,import_tests=import_count,native_executable=True,
                    empty_path=True, poisoned_external_python_ignored=True,
                    non_ascii_and_space_paths=True, all_imports_inside_bundle=True,
                    gui_runtime_initialized=True, local_project_present=False,
                    native_english_alias=True, cmd_ascii_crlf=True,
                    real_child_chinese_utf8_pipe=utf8_report,
                    protocol_controls_output=tests.stderr.strip(),
                    import_controls_output=imports.stderr.strip(),
                    material_import_gui_built=True,
                    note='This is an extracted-directory test on the current Windows host, not a separate physical machine.')


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    report = verify(args.archive)
    args.report.write_text(json.dumps(report, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
    print(json.dumps(report, ensure_ascii=False, indent=2))
