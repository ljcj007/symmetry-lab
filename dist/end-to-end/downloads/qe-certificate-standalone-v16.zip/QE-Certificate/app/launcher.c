/* Native Windows launcher. No .NET, installed Python, PATH or shell required.
 * SPDX-License-Identifier: GPL-3.0-or-later */
#define UNICODE
#define _UNICODE
#include <windows.h>
#include <wchar.h>

int WINAPI WinMain(HINSTANCE instance, HINSTANCE previous, LPSTR ignored, int show) {
    WCHAR self[32768], root[32768], command[65535], python[32768], script[32768];
    WCHAR *tail, *end;
    STARTUPINFOW startup;
    PROCESS_INFORMATION process;
    DWORD code = 1;
    (void)instance; (void)previous; (void)ignored; (void)show;
    if (!GetModuleFileNameW(NULL, self, 32768)) return 1;
    wcscpy(root, self);
    end = wcsrchr(root, L'\\');
    if (!end) return 1;
    *end = 0;
    if (wcslen(root) > 31000) return 1;
    wcscpy(python, root); wcscat(python, L"\\runtime\\pythonw.exe");
    wcscpy(script, root); wcscat(script, L"\\app\\main.py");
    if (GetFileAttributesW(python) == INVALID_FILE_ATTRIBUTES ||
        GetFileAttributesW(script) == INVALID_FILE_ATTRIBUTES) {
        MessageBoxW(NULL, L"Please extract the complete ZIP before starting this program.",
                    L"QE Certificate", MB_OK | MB_ICONERROR);
        return 1;
    }
    tail = GetCommandLineW();
    if (*tail == L'\"') {
        ++tail;
        while (*tail && *tail != L'\"') ++tail;
        if (*tail) ++tail;
    } else {
        while (*tail && *tail != L' ' && *tail != L'\t') ++tail;
    }
    while (*tail == L' ' || *tail == L'\t') ++tail;
    if (wcslen(python) + wcslen(script) + wcslen(tail) + 32 >= 65535) return 1;
    wcscpy(command, L"\""); wcscat(command, python);
    wcscat(command, L"\" -I -X utf8 -B \""); wcscat(command, script);
    wcscat(command, L"\" "); wcscat(command, tail);
    ZeroMemory(&startup, sizeof(startup));
    startup.cb = sizeof(startup);
    ZeroMemory(&process, sizeof(process));
    if (!CreateProcessW(python, command, NULL, NULL, FALSE, CREATE_NO_WINDOW,
                        NULL, root, &startup, &process)) {
        MessageBoxW(NULL, L"The included runtime could not start. Please extract the complete ZIP again.",
                    L"QE Certificate", MB_OK | MB_ICONERROR);
        return 1;
    }
    CloseHandle(process.hThread);
    WaitForSingleObject(process.hProcess, INFINITE);
    GetExitCodeProcess(process.hProcess, &code);
    CloseHandle(process.hProcess);
    return (int)code;
}
