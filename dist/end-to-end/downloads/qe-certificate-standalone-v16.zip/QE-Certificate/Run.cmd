@echo off
setlocal
start "" "%~dp0Run.exe" %*
