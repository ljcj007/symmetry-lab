"""Offline client protocol controls; no installed SSH package or server needed."""
import io
import json
from pathlib import Path
import stat
import tempfile
import unittest
from unittest.mock import patch
import zipfile

import remote_service as client
import input_import
from material_gui import finished_message,stage_summary,verification_details


class WriteFile(io.StringIO):
    def __init__(self, owner, path):
        super().__init__()
        self.owner, self.path = owner, path

    def close(self):
        if not self.closed:
            self.owner.saved[self.path] = self.getvalue()
        super().close()


class ReadOnlyCreate(WriteFile):
    def write(self, value):
        raise PermissionError('Paramiko x mode has no WRITE flag')


class BinaryWriteFile(io.BytesIO):
    def __init__(self, owner, path):
        super().__init__();self.owner, self.path = owner, path
    def close(self):
        if not self.closed:self.owner.saved[self.path] = self.getvalue()
        super().close()


class FakeSFTP:
    def __init__(self, custom=False):
        self.saved = {}
        self.run_root = '/srv/cert/runs/existing'
        self.closed = False
        self.modes = []
        self.custom = custom

    def normalize(self, path):
        return '/home/test'

    def mkdir(self, path):
        if '/upload' not in path:self.run_root = path

    def stat(self, path):
        return object()

    def open(self, path, mode):
        self.modes.append((path, mode))
        if mode == 'wx':
            return BinaryWriteFile(self, path) if '/upload/' in path else WriteFile(self, path)
        if mode == 'x':
            return ReadOnlyCreate(self, path)
        if path in self.saved:
            value=self.saved[path]
            return io.BytesIO(value if isinstance(value, bytes) else value.encode('utf8'))
        if path.endswith('/server.json'):
            value = dict(schema='qe-certificate-server.v1', root='/srv/cert',
                         python='/opt/python/bin/python', entry='/srv/cert/service.py',
                         capabilities={'custom_qe':self.custom,'protocol':2})
        elif path.endswith('/service.json'):
            value = dict(status='SUCCEEDED', full_chain_certified=True, full_chain_recomputed=False,
                         run_json='/srv/cert/science/web/jobs/one/RUN.json',
                         result_zip=self.run_root+'/output/results.zip')
            if self.custom:
                value.update(mode='custom-qe', material_name='Carbon', full_chain_certified=False,
                    calculation_completed=True, numerical_scf_completed=True, native_operator_received=True,
                    finite_point_spectrum_certified=True, infinite_scf_certified=False,
                    verification_level='finite-point-spectrum')
        elif path.endswith('/RUN.json'):
            value = dict(stages=[dict(id='native-dft', label='QE', state='SUCCEEDED')])
        else:
            raise FileNotFoundError(path)
        return io.BytesIO(json.dumps(value).encode())

    def get(self, remote, local):
        with zipfile.ZipFile(local, 'w') as z:
            z.writestr('certificate/RESULTS.json', '{"root_exists":true}')

    def close(self):
        self.closed = True


class FakeChannel:
    def shutdown_write(self): pass
    def settimeout(self, value): pass
    def recv_exit_status(self): return 0


class FakeStream(io.BytesIO):
    def __init__(self):
        super().__init__(b'{}')
        self.channel = FakeChannel()


class FakeInput(io.StringIO):
    def __init__(self, owner):
        super().__init__()
        self.owner = owner
        self.channel = FakeChannel()

    def close(self):
        if not self.closed:
            self.owner.stdin_data = self.getvalue()
        super().close()


class FakeSSH:
    def __init__(self, custom=False):
        self.sftp = FakeSFTP(custom)
        self.commands = []
        self.stdin_data = None

    def open_sftp(self): return self.sftp
    def exec_command(self, command, timeout):
        self.commands.append(command)
        return FakeInput(self), FakeStream(), FakeStream()
    def close(self): pass


class ClientControls(unittest.TestCase):
    def test_fresh_chain_uses_stdin_and_downloads_without_changing_scientific_claims(self):
        ssh = FakeSSH()
        request = dict(host='example.invalid', user='test', port=22, password='one-time-secret-TEST')
        events = []
        with tempfile.TemporaryDirectory() as temp, patch.object(client, 'connect', return_value=ssh):
            out = Path(temp)/'fresh'
            code = client.run(request, out, Path(temp)/'state', events.append, poll_seconds=0)
            self.assertEqual(code, 0)
            self.assertEqual(len(ssh.commands), 1)
            self.assertTrue(any(path.endswith('/REQUEST.json') and mode == 'wx' for path, mode in ssh.sftp.modes))
            self.assertNotIn('one-time-secret', ssh.commands[0])
            self.assertEqual(json.loads(ssh.stdin_data), {'password':'one-time-secret-TEST'})
            self.assertNotIn('password', request)
            self.assertTrue((out/'results/certificate/RESULTS.json').is_file())
            result = json.loads((out/'RESULT.json').read_text())
            self.assertTrue(result['full_chain_certified'])
            self.assertFalse(result['full_chain_recomputed'])
            for path in out.rglob('*'):
                if path.is_file():
                    self.assertNotIn(b'one-time-secret-TEST', path.read_bytes())
            self.assertTrue(events[-1]['full_chain_certified'])

    def test_resume_does_not_start_another_qe_run(self):
        ssh = FakeSSH()
        request = dict(host='example.invalid', user='test', port=22, password='resume-secret',
                       resume_output='/srv/cert/runs/existing/output')
        with tempfile.TemporaryDirectory() as temp, patch.object(client, 'connect', return_value=ssh):
            self.assertEqual(client.run(request, Path(temp)/'resumed', Path(temp)/'state', poll_seconds=0), 0)
            self.assertEqual(ssh.commands, [])
            self.assertEqual(ssh.sftp.saved, {})
            self.assertIsNone(ssh.stdin_data)

    def test_failed_authentication_never_echoes_secret(self):
        request = dict(host='example.invalid', user='test', port=22, password='auth-secret')
        error = client.ServiceError('AUTH_FAILED', '服务器登录失败，请检查用户名和密码。')
        with tempfile.TemporaryDirectory() as temp, patch.object(client, 'connect', side_effect=error):
            with self.assertRaises(client.ServiceError) as caught:
                client.run(request, Path(temp)/'failed', Path(temp)/'state', poll_seconds=0)
            self.assertNotIn('auth-secret', str(caught.exception))
            self.assertNotIn('password', request)

    def test_resume_outside_service_root_is_rejected(self):
        ssh = FakeSSH()
        request = dict(host='example.invalid', user='test', port=22, password='x', resume_output='/tmp/foreign/output')
        with tempfile.TemporaryDirectory() as temp, patch.object(client, 'connect', return_value=ssh):
            with self.assertRaises(client.ServiceError):
                client.run(request, Path(temp)/'failed', Path(temp)/'state')
            self.assertEqual(ssh.commands, [])

    def test_archive_path_escape_duplicate_and_symlink_are_rejected(self):
        with tempfile.TemporaryDirectory() as temp:
            root = Path(temp)
            cases = [('escape', [('../outside.txt', b'x')]),
                     ('duplicate', [('file.txt', b'a'), ('FILE.txt', b'b')])]
            for name, members in cases:
                with zipfile.ZipFile(root/(name+'.zip'), 'w') as z:
                    for entry, data in members:
                        z.writestr(entry, data)
                with self.assertRaises(client.ServiceError):
                    client.safe_extract(root/(name+'.zip'), root/name)
            info = zipfile.ZipInfo('link')
            info.external_attr = (stat.S_IFLNK | 0o777) << 16
            with zipfile.ZipFile(root/'symlink.zip', 'w') as z:
                z.writestr(info, 'outside')
            with self.assertRaises(client.ServiceError):
                client.safe_extract(root/'symlink.zip', root/'symlink')
            self.assertFalse((root/'outside.txt').exists())

    def test_remote_absolute_and_scientific_path_guards(self):
        for value in ('../a', 'relative', '/srv/../etc', '/srv/evil\ncommand'):
            with self.assertRaises(client.ServiceError): client.absolute_remote(value)
        self.assertEqual(str(client.inside_remote(client.absolute_remote('/srv/cert'), '/srv/cert/science/RUN.json')),
                         '/srv/cert/science/RUN.json')

    def test_request_upload_mode_really_requires_write_and_is_read_back(self):
        sftp = FakeSFTP()
        with sftp.open('/wrong.json', 'x') as stream:
            with self.assertRaises(PermissionError):
                stream.write('must not succeed')
        self.assertEqual(sftp.saved['/wrong.json'], '')
        request = {'schema':'qe-certificate-request.v1', 'connection':{'user':'中文用户'}}
        client.write_request(sftp, '/correct.json', request)
        self.assertEqual(json.loads(sftp.saved['/correct.json']), request)
        self.assertEqual(sftp.modes[-2:], [('/correct.json','wx'),('/correct.json','rb')])

    def test_custom_upload_has_only_requested_files_and_preserves_verification_level(self):
        from test_import import INPUT
        ssh=FakeSSH(custom=True);events=[]
        with tempfile.TemporaryDirectory() as temp, patch.object(client, 'connect', return_value=ssh):
            root=Path(temp);(root/'carbon.in').write_text(INPUT,encoding='utf8');(root/'C.UPF').write_bytes(b'upf-original')
            (root/'unrelated-private.txt').write_text('do not upload')
            request=dict(host='example.invalid',user='test',port=22,password='custom-secret',mode='custom-qe',
                qe_input_path=str(root/'carbon.in'), material_name='Carbon')
            code=client.run(request,root/'out',root/'state',events.append,poll_seconds=0)
            self.assertEqual(code,0)
            public=json.loads((root/'out/RESULT.json').read_text(encoding='utf8'))
            self.assertTrue(public['calculation_completed']);self.assertTrue(public['finite_point_spectrum_certified'])
            self.assertFalse(public['full_chain_certified']);self.assertFalse(public['infinite_scf_certified'])
            uploaded=[p for p in ssh.sftp.saved if '/upload/' in p]
            self.assertEqual(len(uploaded),2)
            request_json=next(json.loads(v)for p,v in ssh.sftp.saved.items()if p.endswith('/REQUEST.json'))
            self.assertEqual(request_json['mode'],'custom-qe');self.assertEqual(request_json['schema'],'qe-certificate-request.v2')
            self.assertEqual(len(request_json['input_files']),2)
            self.assertNotIn(str(root),json.dumps(request_json));self.assertNotIn('custom-secret',json.dumps(request_json))
            self.assertNotIn('unrelated-private',str(ssh.sftp.saved))
            self.assertIn('有限点谱验证通过',finished_message(public))
            self.assertIn('无限轨道自洽尚未获证',finished_message(public))

    def test_changed_import_is_rejected_before_any_qe_command(self):
        from test_import import INPUT
        with tempfile.TemporaryDirectory() as temp:
            root=Path(temp);(root/'c.in').write_text(INPUT,encoding='utf8');(root/'C.UPF').write_bytes(b'original')
            spec=input_import.prepare_import(dict(qe_input_path=str(root/'c.in')))
            (root/'C.UPF').write_bytes(b'changed!')
            ssh=FakeSSH(custom=True)
            with self.assertRaises(client.ServiceError) as caught:
                client.upload_import(ssh.sftp,client.absolute_remote('/srv/cert/runs/new'),spec)
            self.assertEqual(caught.exception.code,'IMPORT_CHANGED');self.assertFalse(ssh.commands)

    def test_server_without_custom_support_rejects_before_upload_and_qe(self):
        from test_import import INPUT
        ssh=FakeSSH()
        with tempfile.TemporaryDirectory() as temp, patch.object(client,'connect',return_value=ssh):
            root=Path(temp);(root/'c.in').write_text(INPUT,encoding='utf8');(root/'C.UPF').write_bytes(b'upf')
            with self.assertRaises(client.ServiceError) as caught:
                client.run(dict(host='example.invalid',user='test',password='x',mode='custom-qe',qe_input_path=str(root/'c.in')),
                    root/'out',root/'state',poll_seconds=0)
            self.assertEqual(caught.exception.code,'CUSTOM_NOT_AVAILABLE');self.assertFalse(ssh.commands)
            self.assertFalse(ssh.sftp.saved)

    def test_calculation_only_message_does_not_invent_spectrum_or_infinite_certificate(self):
        event=dict(calculation_completed=True,full_chain_certified=False,native_operator_received=False,
                   finite_point_spectrum_certified=False,infinite_scf_certified=False)
        message=finished_message(event)
        self.assertIn('QE 计算已完成',message);self.assertIn('未取得 NC 点谱或无限自洽证书',message)

    def test_legacy_si_summary_uses_accepted_native_stage_and_keeps_custom_claims_separate(self):
        service=dict(full_chain_certified=True)
        state=dict(stages=[dict(id='native-dft',state='SUCCEEDED',claims=['raw_source_intake'])])
        value=client.result_identity(service,state,dict(mode='si-reference'))
        self.assertEqual(value['material_name'],'Si');self.assertTrue(value['native_operator_received'])
        self.assertNotIn('finite_point_spectrum_certified',value)
        # An unreceived source or a custom label cannot borrow the Si claim.
        value=client.result_identity({},dict(stages=[dict(id='native-dft',state='SUCCEEDED')]),dict(mode='si-reference'))
        self.assertFalse(value['native_operator_received'])
        value=client.result_identity(service,state,dict(mode='custom-qe',material_name='Carbon'))
        self.assertEqual(value['material_name'],'Carbon');self.assertFalse(value['native_operator_received'])
        value=client.result_identity(dict(material_name='Server name'),None,dict(mode='custom-qe',material_name='Local name'))
        self.assertEqual(value['material_name'],'Server name')

    def test_completed_paw_reception_preserves_not_applicable_and_actual_reasons(self):
        ssh=FakeSSH(custom=True);original=ssh.sftp.open;events=[]
        reasons=['USPP/PAW 或其他非 NC 赝势不适用当前标量 NC 完整算符证明。','当前自定义材料没有无限基组、连续 k 空间及非线性自洽根的完整证明；未继承 Si 的证书。']
        stages=[dict(id='qe-scf',label='QE 数值计算',state='SUCCEEDED'),dict(id='native-export',label='原生算符',state='NOT_APPLICABLE'),dict(id='finite-spectrum',label='严格点谱',state='NOT_APPLICABLE')]
        def received(path,mode):
            if path.endswith('/service.json'):
                return io.BytesIO(json.dumps(dict(status='SUCCEEDED',mode='custom-qe',calculation_completed=True,
                    full_chain_certified=False,native_operator_received=False,finite_point_spectrum_certified=False,
                    infinite_scf_certified=False,run_json='/srv/cert/science/RUN.json',result_zip=ssh.sftp.run_root+'/output/results.zip')).encode())
            if path.endswith('/RUN.json'):return io.BytesIO(json.dumps(dict(status='COMPLETED',stages=stages,remaining_obligations=reasons)).encode())
            return original(path,mode)
        ssh.sftp.open=received
        with tempfile.TemporaryDirectory()as temp,patch.object(client,'connect',return_value=ssh):
            root=Path(temp);request=dict(host='example.invalid',user='test',port=22,password='x',mode='custom-qe',resume_output='/srv/cert/runs/existing/output')
            self.assertEqual(client.run(request,root/'out',root/'state',events.append,poll_seconds=0),0)
            final=events[-1];self.assertEqual(final['remaining_obligations'],reasons);self.assertEqual(final['stages'],stages)
            self.assertFalse(final['finite_point_spectrum_certified']);self.assertFalse(final['infinite_scf_certified']);self.assertFalse(final['full_chain_certified'])
            rendered=stage_summary(final['stages'],True);self.assertIn('不适用',rendered);self.assertNotIn('等待',rendered)
            self.assertIn('USPP/PAW',verification_details(final));self.assertEqual(ssh.commands,[])
    def test_unknown_terminal_stage_never_becomes_waiting(self):
        text=stage_summary([dict(id='new',state='NEW_TERMINAL_STATE'),dict(id='old',state='QUEUED'),dict(id='stale',state='RUNNING')],True)
        self.assertNotIn('等待',text);self.assertIn('NEW_TERMINAL_STATE',text);self.assertIn('未执行',text)
        self.assertNotIn('运行中',text);self.assertIn('已结束（未确认完成）',text)


if __name__ == '__main__':
    unittest.main()
