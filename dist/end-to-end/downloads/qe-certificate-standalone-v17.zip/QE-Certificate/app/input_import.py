"""Import only the selected QE input and its explicitly required UPF files.

The server parses the original input independently. Local paths are never
part of the server request or certificate metadata.
SPDX-License-Identifier: GPL-3.0-or-later
"""
from pathlib import Path, PurePosixPath
import hashlib
import re
import stat

MAX_INPUT = 2 * 1024**2
MAX_UPF = 64 * 1024**2
MAX_TOTAL = 1024**3


class ImportErrorDetail(ValueError):
    pass


def safe_name(value):
    if (not isinstance(value, str) or not value or value in ('.', '..')
            or PurePosixPath(value).name != value or '\\' in value or ':' in value
            or any(ord(c) < 32 for c in value) or len(value) > 200):
        raise ImportErrorDetail('赝势文件名无效，请使用输入中指定的单个 UPF 文件名。')
    return value


def load_input(path):
    from qe_input import inspect_qe_input
    path = Path(path).resolve()
    if not path.is_file() or path.stat().st_size > MAX_INPUT:
        raise ImportErrorDetail('请选择小于 2 MB 的 QE 输入文件。')
    raw = path.read_bytes()
    try:
        text = raw.decode('utf-8-sig')
    except UnicodeError:
        raise ImportErrorDetail('输入文件应使用 UTF-8 或 ASCII 编码。') from None
    try:
        summary = inspect_qe_input(text)
    except ValueError as exc:
        raise ImportErrorDetail(str(exc)) from None
    return raw, summary


def required_pseudos(summary):
    rows = summary.get('species', [])
    names = [safe_name(row.get('pseudo', row.get('pseudopotential', row.get('file'))))
             for row in rows]
    if not names:
        raise ImportErrorDetail('输入文件中没有可识别的 ATOMIC_SPECIES 赝势清单。')
    unique = list(dict.fromkeys(names))
    if len({n.casefold() for n in unique}) != len(unique):
        raise ImportErrorDetail('赝势文件名只在大小写上不同，请使用不同名称。')
    return unique


def selected_files(selected=(), folder=None):
    """Bounded folder discovery, excluding links and directory junctions."""
    paths = []
    for p in selected or ():
        p = Path(p).resolve()
        if not p.is_file():
            raise ImportErrorDetail('选中的赝势文件不存在。')
        paths.append(p)
    if folder:
        root = Path(folder).resolve()
        if not root.is_dir():raise ImportErrorDetail('选中的赝势文件夹不存在。')
        pending = [(root, 0)];visited = 0
        while pending:
            directory, depth = pending.pop()
            for p in sorted(directory.iterdir(), key=lambda p:p.name.casefold()):
                visited += 1
                if visited > 4096:raise ImportErrorDetail('文件夹内容过多，请选择更具体的 UPF 文件夹或直接选择所需文件。')
                if p.is_symlink() or getattr(p, 'is_junction', lambda:False)():continue
                if p.is_file() and p.suffix.lower()=='.upf':paths.append(p.resolve())
                elif depth < 3 and p.is_dir():pending.append((p, depth+1))
    return list(dict.fromkeys(paths))


def expected_element(summary, name):
    # QE species labels may add digits or suffixes to a chemical symbol.
    symbols = set('H He Li Be B C N O F Ne Na Mg Al Si P S Cl Ar K Ca Sc Ti V Cr Mn Fe Co Ni Cu Zn Ga Ge As Se Br Kr Rb Sr Y Zr Nb Mo Tc Ru Rh Pd Ag Cd In Sn Sb Te I Xe Cs Ba La Ce Pr Nd Pm Sm Eu Gd Tb Dy Ho Er Tm Yb Lu Hf Ta W Re Os Ir Pt Au Hg Tl Pb Bi Po At Rn Fr Ra Ac Th Pa U Np Pu Am Cm Bk Cf Es Fm Md No Lr Rf Db Sg Bh Hs Mt Ds Rg Cn Nh Fl Mc Lv Ts Og'.split())
    elements=set()
    for row in summary['species']:
        if row['pseudo']!=name:continue
        match=re.match(r'^([A-Z][a-z]?)(?:$|[0-9_+\-])',row['label'])
        if not match or match[1]not in symbols:raise ImportErrorDetail('无法从原子标签确定元素，请使用输入中同名的赝势，或使用标准元素标签。')
        elements.add(match[1])
    if len(elements)!=1:raise ImportErrorDetail('该赝势对应多个不同元素，不能自动建议文件对应关系。')
    return elements.pop()


def upf_metadata(path):
    from qe_input import inspect_upf
    path=Path(path)
    if not path.is_file() or not 0 < path.stat().st_size <= MAX_UPF:
        raise ImportErrorDetail('请选择小于 64 MB 的有效 UPF 文件。')
    try:
        with path.open('rb')as stream:text=stream.read(512*1024).decode('utf8','replace')
        return inspect_upf(text)
    except ValueError:
        raise ImportErrorDetail('无法识别所选文件的 UPF 头部，不能确认不同文件名的对应关系。')from None


def make_binding(input_path, summary, required_name, selected_path):
    """Create a content-bound selection after the caller's explicit confirmation."""
    if required_name not in required_pseudos(summary):raise ImportErrorDetail('所确认的赝势不在当前输入清单中。')
    path=Path(selected_path).resolve();meta=upf_metadata(path)
    if meta['element']!=expected_element(summary,required_name):
        raise ImportErrorDetail('所选 UPF 的元素与输入要求不符，不能建立对应关系。')
    row=source_row(path,'pseudopotential','upload/pseudo/'+required_name,path.name,MAX_UPF)
    return dict(path=str(path),required_name=required_name,bytes=row['bytes'],sha256=row['sha256'],
                input_sha256=hashlib.sha256(load_input(input_path)[0]).hexdigest())


def binding_suggestions(summary, paths):
    """Propose only unique same-element choices; never accept them here."""
    suggestions=[]
    for name in required_pseudos(summary):
        exact=[p for p in paths if p.name.casefold()==name.casefold()]
        if exact:continue
        element=expected_element(summary,name);matches=[]
        for p in paths:
            try:meta=upf_metadata(p)
            except (ImportErrorDetail,OSError):continue
            if meta['element']==element:matches.append((p,meta))
        if len(matches)>1:
            raise ImportErrorDetail('输入要求 '+name+'，所选目录或文件中有多份 '+element+' 赝势。请直接选择本次要用的一份文件。')
        if matches:suggestions.append(dict(required_name=name,path=matches[0][0],metadata=matches[0][1]))
    return suggestions


def merge_selected_files(existing, new):
    """A new explicit choice replaces older choices for the same element."""
    new=selected_files(new);elements=set()
    for path in new:
        try:elements.add(upf_metadata(path)['element'])
        except (ImportErrorDetail,OSError):pass
    kept=[]
    for path in existing:
        path=Path(path)
        if not path.is_file():continue
        try:
            if upf_metadata(path)['element']in elements:continue
        except (ImportErrorDetail,OSError):pass
        kept.append(path)
    return list(dict.fromkeys(kept+new))


def binding_confirmation_text(summary, suggestions):
    rows=['文件名与输入要求不同。请确认本次实际使用的赝势：']
    for item in suggestions:
        meta=item['metadata'];path=item['path']
        rows.append('\n输入要求：'+item['required_name']+'\n所选文件：'+path.name+'\n位置：'+str(path)+
                    '\n元素：'+meta['element']+'；模型：'+meta['pseudo_type']+'；UPF 泛函：'+str(meta['functional']))
    rows.append('\n不同名称可能代表不同版本或泛函（例如 PBE / PBEsol）。确认表示本次采用所选文件的实际内容。')
    rows.append("QE 输入的 input_dft："+str(summary.get('input_dft')or'未指定，按 QE 规则处理')+'；程序不会自动修改它。')
    rows.append('原输入和本地赝势不改动；上传副本使用输入要求的文件名，运行记录保留所选文件的真实名称。')
    if any(item['metadata']['pseudo_type']!='NC'for item in suggestions):
        rows.append('所选 PAW/USPP 可进行数值 QE 计算，当前不生成 NC 严格点谱或无限自洽证书。')
    rows.append('\n是否确认使用以上赝势？')
    return '\n'.join(rows)


def find_pseudos(input_path, summary, selected=(), folder=None, bindings=None):
    input_path = Path(input_path).resolve()
    candidates = {}
    for p in selected_files(selected,folder):
        key = p.name.casefold()
        if key in candidates and candidates[key] != p:
            raise ImportErrorDetail('选中了同名赝势文件，请只保留本次使用的一份。')
        candidates[key] = p
    directories = []
    directories.extend((input_path.parent, input_path.parent/'pseudo'))
    pseudo_dir = summary.get('pseudo_dir')
    if pseudo_dir and isinstance(pseudo_dir, str):
        p = Path(pseudo_dir)
        if not p.is_absolute() and '..' not in p.parts:
            directories.append(input_path.parent/p)
    for directory in dict.fromkeys(directories):
        if directory.is_dir():
            for p in directory.iterdir():
                if p.is_file() and p.suffix.lower() == '.upf':
                    candidates.setdefault(p.name.casefold(), p.resolve())
    names = required_pseudos(summary)
    if bindings is not None and (not isinstance(bindings,dict) or set(bindings)-set(names)):
        raise ImportErrorDetail('赝势对应关系与当前输入不一致，请重新选择。')
    for name,binding in (bindings or {}).items():
        if not isinstance(binding,dict)or binding.get('required_name')!=name:
            raise ImportErrorDetail('赝势对应关系无效，请重新选择并确认。')
        current=make_binding(input_path,summary,name,binding.get('path',''))
        if current!=binding:raise ImportErrorDetail('输入或已确认的赝势文件发生变化，请重新选择并确认。')
        candidates[name.casefold()]=Path(binding['path']).resolve()
    missing = [n for n in names if n.casefold() not in candidates]
    if missing:
        actual=selected_files(selected,folder)
        detail=(' 当前选择：'+'、'.join(p.name for p in actual[:4])+'。文件名可能与输入要求不同，请确认对应关系。')if actual else''
        raise ImportErrorDetail('缺少赝势文件：'+'、'.join(missing)+'。请选择对应 UPF 文件或所在文件夹。'+detail)
    return [(name, candidates[name.casefold()]) for name in names]


def source_row(path, role, relative, original_name, limit):
    path = Path(path).resolve()
    meta = path.stat()
    if not stat.S_ISREG(meta.st_mode) or not 0 < meta.st_size <= limit:
        raise ImportErrorDetail('输入或赝势文件超出支持的大小，或不是普通文件。')
    with path.open('rb') as stream:
        digest = hashlib.file_digest(stream, 'sha256').hexdigest()
    if path.stat().st_size != meta.st_size:
        raise ImportErrorDetail('导入文件在读取时发生变化，请重新选择。')
    return dict(local_path=path, role=role, path=relative,
                original_name=original_name, bytes=meta.st_size, sha256=digest)


def prepare_import(request):
    path = Path(request.get('qe_input_path', '')).resolve()
    _, summary = load_input(path)
    selected = find_pseudos(path, summary, request.get('upf_paths', ()), request.get('pseudo_directory'),request.get('upf_bindings'))
    files = [source_row(path, 'qe-input', 'upload/pw.in', path.name, MAX_INPUT)]
    files += [source_row(p, 'pseudopotential', 'upload/pseudo/'+name, p.name, MAX_UPF)
              for name, p in selected]
    if sum(r['bytes'] for r in files) > MAX_TOTAL:
        raise ImportErrorDetail('本次导入文件合计超过 1 GB。')
    brief = {k: summary.get(k) for k in
             ('nat', 'ntyp', 'ibrav', 'ecutwfc', 'ecutrho', 'occupations', 'nspin',
              'noncolin', 'lspinorb', 'calculation', 'k_points') if k in summary}
    brief['species'] = summary.get('species', [])
    name = str(request.get('material_name') or path.stem).strip()
    if not name or len(name) > 160 or any(ord(c) < 32 for c in name):
        raise ImportErrorDetail('材料名称应为 1 至 160 个字符。')
    return dict(material_name=name, files=files, preview=brief, summary=summary)


def public_file(row):
    return {k: row[k] for k in ('role', 'path', 'original_name', 'bytes', 'sha256')}


def preview_text(summary):
    elements = ', '.join(str(r.get('label', r.get('symbol', '?'))) for r in summary.get('species', []))
    kp = summary.get('k_points', {})
    if isinstance(kp, dict):
        k_text = str(kp.get('mode', kp.get('kind', '')))
        mesh = kp.get('mesh', kp.get('grid'))
        if mesh:
            k_text += '  '+' × '.join(map(str, mesh[:3]))
        elif kp.get('count'):
            k_text += '  '+str(kp['count'])+' 点'
    else:
        k_text = str(kp)
    spin = '自旋轨道/非共线' if summary.get('noncolin') or summary.get('lspinorb') else \
           '自旋极化' if summary.get('nspin') == 2 else '标量/非磁性'
    return (f"元素：{elements}　原子：{summary.get('nat', '?')}　晶格类型：{summary.get('ibrav', '?')}\n"
            f"平面波截断：{summary.get('ecutwfc', '?')} Ry　电荷截断：{summary.get('ecutrho', '默认')} Ry\n"
            f"k 点：{k_text}　模型：{spin}　占据：{summary.get('occupations', 'fixed')}")


def pseudo_preview(selected):
    """Read only bounded UPF headers for display, never use this as a proof."""
    from qe_input import inspect_upf
    models = []
    for name, path in selected:
        try:
            with Path(path).open('rb') as stream:
                header = stream.read(512 * 1024).decode('utf8', 'replace')
            value = inspect_upf(header)
            models.append(value['pseudo_type'])
        except (OSError, ValueError, KeyError):
            models.append('待服务器识别')
    result='UPF 模型：'+'、'.join(dict.fromkeys(models)) if models else ''
    if any(model in('PAW','US','USPP')for model in models):
        result+='\nPAW/USPP 可进行 QE 数值计算；当前 NC 严格点谱验证不适用，无限自洽尚未证明。'
    return result
