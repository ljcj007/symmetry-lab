"""Build the self-contained Windows client from explicit local dependency inputs."""
from __future__ import annotations
import argparse
import hashlib
import importlib.metadata
import json
from pathlib import Path
import shutil
import subprocess
import sys
import zipfile

HERE = Path(__file__).resolve().parent
PAPER = HERE.parents[2]
CONDA = Path(sys.executable).resolve().parent
RUNTIME = PAPER/'research/ncs-program/phase27/benchmark_delivery/relocated_v6/runtime'
PACKAGES = ('paramiko', 'cryptography', 'bcrypt', 'pynacl', 'cffi', 'invoke', 'pycparser')
MODULES = ('paramiko', 'cryptography', 'bcrypt', 'nacl', 'cffi', 'invoke', 'pycparser')


def copy_tree(source, destination, omit=()):
    def ignore(path, names):
        return [name for name in names if name in {'__pycache__', *omit} or name.endswith(('.pyc', '.pyo'))]
    shutil.copytree(source, destination, ignore=ignore)


def pin(path):
    return dict(bytes=path.stat().st_size, sha256=hashlib.sha256(path.read_bytes()).hexdigest())


def build(destination, archive):
    destination = destination.resolve()
    if destination.exists() or archive.exists():
        raise ValueError('A new build and archive path are required.')
    destination.mkdir(parents=True)
    runtime = destination/'runtime'
    runtime.mkdir()
    for source in RUNTIME.iterdir():
        if source.is_file() and source.name != 'python313._pth':
            shutil.copy2(source, runtime/source.name)
    copy_tree(RUNTIME/'DLLs', runtime/'DLLs')
    copy_tree(RUNTIME/'Lib', runtime/'Lib', omit=('site-packages', 'test', 'ensurepip', 'idlelib', 'turtledemo'))
    packages = runtime/'Lib/site-packages'
    packages.mkdir()
    dependencies = []
    for package, module in zip(PACKAGES, MODULES):
        distribution = importlib.metadata.distribution(package)
        source = CONDA/'Lib/site-packages'/module
        copy_tree(source, packages/module)
        copy_tree(Path(distribution._path), packages/Path(distribution._path).name)
        dependencies.append(dict(name=package, version=distribution.version,
                                 source=f'https://pypi.org/project/{package}/{distribution.version}/#files',
                                 source_included=True if package in ('paramiko', 'invoke', 'pycparser') else False,
                                 metadata='runtime/Lib/site-packages/'+Path(distribution._path).name))
    for source in (CONDA/'Lib/site-packages').glob('_cffi_backend*.pyd'):
        shutil.copy2(source, packages/source.name)
    shutil.copy2(CONDA/'pythonw.exe', runtime/'pythonw.exe')
    # The isolated search path contains neither site initialization nor user packages.
    (runtime/'python313._pth').write_bytes(b'Lib\r\nDLLs\r\nLib/site-packages\r\n../app\r\n')
    for name in ('tcl8', 'tcl8.6', 'tk8.6'):
        copy_tree(CONDA/'Library/lib'/name, runtime/'tcl'/name)
    licenses = destination/'licenses'
    licenses.mkdir()
    recipes = destination/'build-sources/conda-recipes.zip'
    dependency_names = ('python-', 'tk-', 'openssl-', 'libffi-', 'bzip2-', 'xz-',
                        'zlib-', 'libzlib-', 'libexpat-', 'sqlite-', 'vc14_runtime-', 'vs2015_runtime-')
    conda_sources = []
    for package_root in sorted((CONDA/'pkgs').iterdir()):
        if not package_root.is_dir() or not package_root.name.startswith(dependency_names):
            continue
        license_path = package_root/'info/licenses'
        if license_path.is_dir():
            copy_tree(license_path, licenses/package_root.name)
            conda_sources.append(package_root.name)
            recipe = package_root/'info/recipe'
            if recipe.is_dir():
                recipes.parent.mkdir(exist_ok=True)
                with zipfile.ZipFile(recipes, 'a', compression=zipfile.ZIP_DEFLATED) as recipe_archive:
                    for source in sorted(recipe.rglob('*')):
                        if source.is_file():
                            recipe_archive.write(source, package_root.name+'/'+source.relative_to(recipe).as_posix())
    app = destination/'app'
    app.mkdir()
    for name in ('main.py', 'remote_service.py', 'material_gui.py', 'input_import.py', 'qe_input.py',
                 'launcher.c', 'build_app.py', 'test_client.py', 'test_import.py', 'test_gui_import.py', 'portable_controls.py'):
        shutil.copy2(HERE/name, app/name)
    compiler = Path('C:/MinGW/bin/gcc.exe')
    command = [str(compiler), '-Os', '-s', '-mwindows', '-static-libgcc', str(HERE/'launcher.c'),
               '-o', str(destination/'Run.exe')]
    subprocess.run(command, check=True, capture_output=True)
    shutil.copy2(destination/'Run.exe', destination/'一键运行.exe')
    batch = '@echo off\r\nsetlocal\r\nstart "" "%~dp0Run.exe" %*\r\n'
    (destination/'Run.cmd').write_bytes(batch.encode('ascii'))
    (destination/'一键运行.cmd').write_bytes(batch.encode('ascii'))
    shutil.copy2(PAPER.parent/'sites/symmetry-lab-e2e-20261122/LICENSE', destination/'LICENSE')
    (destination/'README.txt').write_text(
        'QE 独立运行程序（Windows 10/11，64 位）\n\n'
        '1. 将整个 ZIP 解压到可写入的文件夹。\n'
        '2. 双击“一键运行.exe”（英文名 Run.exe）。\n'
        '3. 输入已部署 QE 运行服务的服务器地址、用户名、端口和密码。\n'
        '4. 选择内置 Si 示例，或选择“导入自定义 QE 输入”，导入 .in/.pwi 和所需 UPF。\n'
        '   程序自动识别同目录赝势，也可选择赝势文件或文件夹；核对材料预览后点击“连接并开始运行”。\n'
        '   文件夹支持有限层级的子目录。文件名不同时显示输入要求、实际文件及泛函，确认后按所选内容运行。\n'
        '   原输入和赝势不改动，input_dft 不自动改变；实际使用的文件路径和名称会清楚显示。\n'
        '5. 等待程序取回结果，点击“打开结果文件夹”。\n\n'
        '无需本机 Python，无需原 paper 文件夹。自带隔离的 Python、SSH 和图形运行环境。\n'
        '密码仅保存在本次连接的内存和加密连接中，不写入设置或日志。\n'
        '若连接中断，重新打开程序、输入密码，点击“继续上次任务”即可取回同一任务结果。\n'
        '第一次连接自动记住服务器身份；后续身份变化会停止连接。\n\n'
        '自定义材料：自动执行新的 QE 计算，接收适用的原生 NC 算符并尝试有限点谱严格验证。\n'
        '程序分别显示计算、原生算符、有限点谱和无限自洽的实际验证状态。\n'
        'USPP/PAW、自旋或 SOC 等模型可运行 QE；不适用的 NC 谱验证在报告中清楚说明。\n'
        'PAW 数值计算完成后，NC 接收与点谱步骤显示“不适用”，并直接显示尚未获证的实际原因。\n'
        '新材料不会仅因计算收敛而被赋予无限轨道自洽证书。\n\n'
        '科学计算及大型证明资料由服务器运行服务提供。内置完整无限自洽流程针对固定 Si / QE 模型、\n'
        '固定 48³ 电荷观察和 72 点求积；证明无限轨道自洽根存在性及完整响应可逆性。\n'
        '每次重新计算 QE 和最终闭合；大型已接收证明通过完整原生输入身份绑定。\n'
        '这不表示每次重新计算全部大型矩阵证明，也不表示任意材料都已获证。\n\n'
        '服务器管理员部署资料和源程序见网站下载入口。客户端源码在 app 文件夹，许可证见 LICENSE 和 licenses。\n',
        encoding='utf-8-sig')
    metadata = dict(schema='qe-certificate-client-bundle.v1', version='17',
                    platform='windows-x86_64', entry='一键运行.exe', english_entry='Run.exe',
                    python='3.13.14', scientific_execution='remote-source-bound-service',
                    requires_local_paper=False, requires_installed_python=False,
                    supported_modes=['si-reference', 'custom-qe'], custom_input_import=True,
                    upf_binding_confirmation=True,upf_nested_folder_search=True,terminal_stage_status=True,
                    verification_levels=['numerical-qe', 'native-nc-source', 'finite-point-spectrum', 'infinite-scf-reference'],
                    dependencies=dependencies, runtime_licenses=conda_sources)
    (destination/'BUNDLE.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
    (destination/'THIRD_PARTY_SOURCES.txt').write_text(
        'Third-party runtime sources and license notices\n\n'
        'The application source in app/ is GPL-3.0-or-later. Third-party runtime components retain their own licenses.\n'
        'No VASP executable, VASP licensed dataset, QE executable, user login, password, or scientific proof database is included.\n\n'
        'CPython 3.13.14: Python Software Foundation License; runtime/LICENSE_PYTHON.txt.\n'
        'Source: https://www.python.org/ftp/python/3.13.14/Python-3.13.14.tgz\n'
        'The exact Anaconda runtime build recipes, upstream source locations and patches are included in build-sources/conda-recipes.zip.\n'
        'The Python runtime is derived from that build; this client has its own isolated ._pth and excludes its old sitecustomize.\n\n'
        'Tcl/Tk 8.6.15: BSD-style Tcl/Tk licenses, included under licenses/tk-* and runtime/tcl.\n'
        'Source: https://prdownloads.sourceforge.net/tcl/tcl8.6.15-src.tar.gz\n'
        'Source: https://prdownloads.sourceforge.net/tcl/tk8.6.15-src.tar.gz\n\n'
        'Paramiko 5.0.0: LGPL-2.1; complete Python module sources and license are included.\n'
        'Cryptography 49.0.0: Apache-2.0 OR BSD-3-Clause; source distribution and bundled dependency notices in its dist-info/licenses.\n'
        'bcrypt 5.0.0: Apache-2.0; PyNaCl 1.6.2: Apache-2.0, bundled libsodium ISC license.\n'
        'CFFI 2.1.0: MIT-0; Invoke 3.0.3: BSD-2-Clause; pycparser 3.0: BSD-3-Clause.\n'
        'Exact versioned distribution-source links are in BUNDLE.json. Each included dist-info directory retains LICENSE/METADATA.\n\n'
        'CPython shared-library dependencies retain their separate upstream licenses under licenses: OpenSSL 3.5.7,\n'
        'libffi 3.4.8, bzip2 1.0.8, xz 5.8.2, zlib 1.3.2, Expat 2.8.2, SQLite 3.53.2 and Microsoft Visual C++ runtime.\n'
        'Their exact upstream source URLs, source identities and Anaconda patches are preserved in the included build recipes.\n'
        'No claim is made that the independently licensed dependencies are relicensed under the application GPL.\n', encoding='utf8')
    archive.parent.mkdir(parents=True, exist_ok=True)
    with zipfile.ZipFile(archive, 'x', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as z:
        for path in sorted(destination.rglob('*')):
            if path.is_file():
                z.write(path, 'QE-Certificate/'+path.relative_to(destination).as_posix())
    record = dict(schema='qe-certificate-client-build.v1', status='BUILT', archive=str(archive.resolve()),
                  archive_pin=pin(archive), expanded_bytes=sum(p.stat().st_size for p in destination.rglob('*') if p.is_file()),
                  files=sum(p.is_file() for p in destination.rglob('*')), compiler=str(compiler),
                  sources={name: pin(HERE/name) for name in ('main.py', 'remote_service.py', 'material_gui.py',
                      'input_import.py', 'qe_input.py', 'launcher.c', 'build_app.py', 'test_gui_import.py')})
    return record


if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--destination', type=Path, required=True)
    parser.add_argument('--archive', type=Path, required=True)
    parser.add_argument('--report', type=Path, required=True)
    args = parser.parse_args()
    record = build(args.destination, args.archive)
    args.report.write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf8')
    print(json.dumps({key: record[key] for key in ('status', 'archive_pin', 'expanded_bytes', 'files')}, indent=2))
