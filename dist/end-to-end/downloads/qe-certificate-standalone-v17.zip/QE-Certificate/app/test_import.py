"""Real input parsing and selected-file controls, using a small carbon input."""
from pathlib import Path
import tempfile,unittest
import input_import as importer

INPUT="""&CONTROL
 calculation='scf', prefix='carbon', pseudo_dir='./pseudo', outdir='./out',
/
&SYSTEM
 ibrav=2, celldm(1)=6.7, nat=2, ntyp=1, ecutwfc=12,
 occupations='fixed',
/
&ELECTRONS
 conv_thr=1.d-9,
/
ATOMIC_SPECIES
C 12.011 C.UPF
ATOMIC_POSITIONS crystal
C 0 0 0
C 0.25 0.25 0.25
K_POINTS gamma
"""

def upf(element='C',functional='PBEsol'):
    return ('<UPF><PP_HEADER element="'+element+'" pseudo_type="PAW" is_paw="T" z_valence="4" functional="'+functional+'"/></UPF>').encode()

class ImportControls(unittest.TestCase):
    def fixture(self,root,text=INPUT):
        (root/'carbon.in').write_text(text,encoding='utf8')
        return root/'carbon.in'
    def test_real_parser_explains_structure_and_required_upf(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root)
            _,summary=importer.load_input(path)
            self.assertEqual(summary['nat'],2);self.assertEqual(summary['ntyp'],1)
            self.assertEqual(importer.required_pseudos(summary),['C.UPF'])
            self.assertIn('12 Ry',importer.preview_text(summary));self.assertIn('gamma',importer.preview_text(summary))
    def test_missing_upf_has_clear_error(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root)
            with self.assertRaises(importer.ImportErrorDetail)as error:importer.prepare_import(dict(qe_input_path=str(path)))
            self.assertIn('C.UPF',str(error.exception))
    def test_selected_folder_and_case_alias_upload_only_exact_needed_sources(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root);folder=root/'selected';folder.mkdir()
            (folder/'c.upf').write_bytes(b'actual-upf');(folder/'other.UPF').write_bytes(b'unrelated')
            value=importer.prepare_import(dict(qe_input_path=str(path),pseudo_directory=str(folder)))
            self.assertEqual(len(value['files']),2)
            self.assertEqual(value['files'][1]['path'],'upload/pseudo/C.UPF')
            public=importer.public_file(value['files'][1]);self.assertNotIn('local_path',public)
            self.assertEqual(public['bytes'],10)
    def test_file_path_in_upf_card_is_rejected(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root,INPUT.replace('C.UPF','../C.UPF'))
            with self.assertRaises(importer.ImportErrorDetail):importer.load_input(path)
    def test_spin_model_stays_importable_without_claiming_nc_export_support(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root,INPUT.replace('occupations=','nspin=2, occupations='))
            _,summary=importer.load_input(path)
            self.assertFalse(summary['scalar_nc_export_model_candidate']);self.assertEqual(summary['nspin'],2)
    def test_control_character_material_name_is_rejected(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root);(root/'C.UPF').write_bytes(b'upf')
            with self.assertRaises(importer.ImportErrorDetail):
                importer.prepare_import(dict(qe_input_path=str(path),material_name='bad\nname'))

    def test_pbe_pbesol_difference_requires_explicit_content_bound_mapping(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);expected='C.pbe-n-kjpaw_psl.1.0.0.UPF';actual='C.pbesol-n-kjpaw_psl.1.0.0.UPF'
            path=self.fixture(root,INPUT.replace('C.UPF',expected));selected=root/actual;selected.write_bytes(upf())
            original=path.read_bytes();_,summary=importer.load_input(path)
            suggestions=importer.binding_suggestions(summary,[selected]);self.assertEqual(len(suggestions),1)
            with self.assertRaises(importer.ImportErrorDetail):importer.prepare_import(dict(qe_input_path=str(path),upf_paths=[str(selected)]))
            binding=importer.make_binding(path,summary,expected,selected)
            prepared=importer.prepare_import(dict(qe_input_path=str(path),upf_paths=[str(selected)],upf_bindings={expected:binding}))
            self.assertEqual(prepared['files'][1]['path'],'upload/pseudo/'+expected)
            self.assertEqual(prepared['files'][1]['original_name'],actual);self.assertEqual(path.read_bytes(),original)
            self.assertEqual(prepared['files'][1]['local_path'].read_bytes(),upf())
            self.assertNotIn('local_path',importer.public_file(prepared['files'][1]))
            message=importer.binding_confirmation_text(summary,suggestions)
            self.assertIn(expected,message);self.assertIn(actual,message);self.assertIn('PBEsol',message);self.assertIn('PAW',message)
    def test_confirmed_choice_wins_over_automatic_exact_name(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root);(root/'C.UPF').write_bytes(b'auto exact')
            chosen=root/'chosen.UPF';chosen.write_bytes(upf());_,summary=importer.load_input(path)
            self.assertEqual(importer.find_pseudos(path,summary,[chosen])[0][1],root/'C.UPF')
            binding=importer.make_binding(path,summary,'C.UPF',chosen)
            self.assertEqual(importer.find_pseudos(path,summary,[chosen],bindings={'C.UPF':binding})[0][1],chosen)
    def test_wrong_element_or_unrecognized_file_cannot_be_bound(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root);selected=root/'wrong.UPF';_,summary=importer.load_input(path)
            for data in(upf('O'),b'not a UPF'):
                selected.write_bytes(data)
                with self.assertRaises(importer.ImportErrorDetail):importer.make_binding(path,summary,'C.UPF',selected)
    def test_multiple_same_element_candidates_are_not_guessed(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root);_,summary=importer.load_input(path);paths=[]
            for name in('C.first.UPF','C.second.UPF'):
                p=root/name;p.write_bytes(upf());paths.append(p)
            with self.assertRaises(importer.ImportErrorDetail):importer.binding_suggestions(summary,paths)
    def test_nested_folder_discovers_upf_and_has_a_depth_limit(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root);folder=root/'selected';nested=folder/'one'/'two'/'three';nested.mkdir(parents=True)
            good=nested/'C.UPF';good.write_bytes(upf());too_deep=nested/'four';too_deep.mkdir();(too_deep/'unused.UPF').write_bytes(upf())
            _,summary=importer.load_input(path);self.assertEqual(importer.find_pseudos(path,summary,folder=folder),[('C.UPF',good)])
            self.assertEqual(importer.selected_files(folder=folder),[good])
    def test_changed_upf_even_at_same_size_revokes_confirmation(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root);chosen=root/'chosen.UPF';chosen.write_bytes(upf(functional='PBE'));_,summary=importer.load_input(path)
            binding=importer.make_binding(path,summary,'C.UPF',chosen);chosen.write_bytes(upf(functional='LDA'))
            with self.assertRaises(importer.ImportErrorDetail):importer.find_pseudos(path,summary,bindings={'C.UPF':binding})
    def test_changed_input_revokes_confirmation(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root);chosen=root/'chosen.UPF';chosen.write_bytes(upf());_,summary=importer.load_input(path)
            binding=importer.make_binding(path,summary,'C.UPF',chosen);path.write_bytes(path.read_bytes()+b'\n! input changed\n')
            with self.assertRaises(importer.ImportErrorDetail):importer.prepare_import(dict(qe_input_path=str(path),upf_bindings={'C.UPF':binding}))
    def test_progressive_file_selection_preserves_other_elements(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);c=root/'C.UPF';o=root/'O.UPF';replacement=root/'C.new.UPF'
            c.write_bytes(upf());o.write_bytes(upf('O'));replacement.write_bytes(upf())
            self.assertEqual(importer.merge_selected_files([c],[o]),[c,o])
            self.assertEqual(importer.merge_selected_files([c,o],[replacement]),[o,replacement])
    def test_unconfirmed_or_unknown_binding_cannot_bypass_default_missing_check(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path=self.fixture(root);chosen=root/'selected.UPF';chosen.write_bytes(upf());_,summary=importer.load_input(path)
            with self.assertRaises(importer.ImportErrorDetail):importer.find_pseudos(path,summary,[chosen],bindings={})
            binding=importer.make_binding(path,summary,'C.UPF',chosen)
            with self.assertRaises(importer.ImportErrorDetail):importer.find_pseudos(path,summary,bindings={'O.UPF':binding})

if __name__=='__main__':unittest.main()
