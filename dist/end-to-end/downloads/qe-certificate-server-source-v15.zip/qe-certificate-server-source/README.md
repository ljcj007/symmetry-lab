# QE certificate server service source

This archive provides the actual new service, relocation adapters, installer,
payload builder and verification utilities used by the standalone Windows client.
Ordinary desktop users do not need to install these files. The desktop program
connects to an already deployed service through SSH and discovers its registry.

The server installation contains 4,796 bound scientific source files (6.807 GB).
Those proof inputs, original QE sources, restricted server settings and QE
executables are not included in this code archive. A server administrator needs
the complete corresponding scientific payload and the pinned NC QE exporter;
installing an arbitrary pw.x alone does not supply those proof prerequisites.

The build scripts are supplied in their actual workspace layout, as auditable
sources for preparing the complete payload. Install only after the full payload
verification and energy/response/ionic relocation smoke checks pass. The service
registry is ~/.local/share/qe-certificate/server.json. No password is installed.

The relocation adapter preserves frozen receipt bytes, logical source labels
and the mathematical target. It verifies the original approved receiver bytes
before redirecting their Path import. It is additional trusted code, not an
operating system isolation mechanism. Historical filesystem labels in its source
are mathematical provenance labels, not connection settings for a new computer.

Each job executes fresh QE SCF/native exports, independently receives the source,
and recomputes the final energy and complete-response compositions. Large matrix
proofs are received by exact matching mathematical sources; full_chain_recomputed
remains false. The fixed case uses Si, UPF-node C1 continuation, reference PBE,
48^3 charge observations, canonical 72-point quadrature and infinite orbitals.

The new service sources retain the application GPL-3.0-or-later license. Original
scientific sources, pseudopotentials and dependencies retain their own licenses.
This code archive does not redistribute VASP or QE executables or login details.
