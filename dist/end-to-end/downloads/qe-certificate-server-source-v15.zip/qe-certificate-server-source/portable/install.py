"""Install non-secret server settings for the source-complete payload."""
from pathlib import Path
import argparse,hashlib,json,sys

HERE=Path(__file__).resolve().parent;PAPER=HERE.parent
def pin(p):return {'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()}
def save(p,v):p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(v,indent=2)+'\n',encoding='utf8')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--user',required=True);a=ap.parse_args()
    verification=HERE/'VERIFY.json'
    if not verification.is_file()or json.loads(verification.read_text()).get('status')!='VERIFIED_COMPLETE_SCIENTIFIC_PAYLOAD':raise ValueError('Verify the complete installed source payload before enabling its service')
    source=PAPER/'work/infinite_scf_20261122';config=HERE/'config';config.mkdir(exist_ok=True)
    original=json.loads((source/'native/server_profile_fresh_scf_v7.json').read_text(encoding='utf-8-sig'))
    original.update(host='127.0.0.1',user=a.user)
    original['reference72Local']=str(PAPER/'work/qe_si_end_to_end_20261117/root/native72_v1')
    save(config/'server.json',original)
    recipe=(source/'native/infinite_recipe_complete_r72af.json').read_bytes();(config/'recipe.json').write_bytes(recipe)
    # Source-chain mathematical files are unchanged. The new runtime mapping
    # adapter and launch stages have their own explicitly registered bytes.
    profile=json.loads((source/'web/profiles/qe-si-infinite-complete-r72af.json').read_text(encoding='utf-8-sig')) if (source/'web/profiles/qe-si-infinite-complete-r72af.json').exists() else json.loads((HERE/'original-profile.json').read_text())
    profile.update(id='qe-si-standalone-v1',python_executable=sys.executable,source_root='portable/config',inputs=['server.json','recipe.json'])
    for st in profile['stages']:
        if st['id']=='native-dft':
            st['arguments']=[str(config/'server.json')if x.endswith('server_profile_fresh_scf_v7.json')else x for x in st['arguments']]
        else:
            f=HERE/('source_chain_stage.py'if st['id']=='ionic-input'else'infinite_chain_stage.py')
            st['program']=f.relative_to(PAPER).as_posix();st['program_pin']=pin(f)
            if st['id']=='infinite-scf':st['arguments']=[str(config/'recipe.json')if x.endswith('infinite_recipe_complete_r72af.json')else x for x in st['arguments']]
        st['dependencies'] += [dict(path=p.relative_to(PAPER).as_posix(),**pin(p))for p in(HERE/'portable_exec.py',HERE/'portable_paths.py')]
    save(source/'web/profiles/qe-si-standalone-v1.json',profile)
    registry={'schema':'qe-certificate-server.v1','python':sys.executable,'entry':str(HERE/'service.py'),'root':str(PAPER.parent),'profile':'qe-si-standalone-v1','scope':profile['scope']}
    save(Path.home()/'.local/share/qe-certificate/server.json',registry)
    trust_sources={name:pin(HERE/name)for name in('service.py','portable_exec.py','portable_paths.py','source_chain_stage.py','infinite_chain_stage.py','install.py','payload-manifest.json','VERIFY.json')}
    trust_sources['registered-profile']=pin(source/'web/profiles/qe-si-standalone-v1.json')
    save(HERE/'installation.json',registry|{'adapter_is_additional_trust_source':True,'new_trust_source_pins':trust_sources,'frozen_receipt_bytes_rewritten':False,'full_chain_recomputed':False})
    print(json.dumps({'status':'INSTALLED','root':str(PAPER.parent)}))
if __name__=='__main__':main()
