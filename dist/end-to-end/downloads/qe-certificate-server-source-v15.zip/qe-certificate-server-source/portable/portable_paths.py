"""Explicit read-only relocation of byte-identical historical source paths.

This adapter is a new trust source. It preserves the logical Windows path
strings in frozen receipts and target identities, and maps actual I/O into the
installed science payload. It does not change receipt bytes or waive hashes.
"""
from pathlib import Path as NativePath, PureWindowsPath
import os

ROOT = NativePath(__file__).resolve().parent.parent
OLD = PureWindowsPath('C:/Users/ljcj007/Videos/vasp/20261014-group/20261014-group/paper')
EXTERNAL = {PureWindowsPath('C:/MinGW/bin/gcc.exe'): 'received_external/gcc.exe'}


class Path:
    @classmethod
    def _wrap(cls, logical, historical=False):
        obj=object.__new__(cls);obj.logical=logical;obj.historical=historical
        return obj
    def __init__(self, *parts):
        if len(parts) == 1 and isinstance(parts[0], Path):
            self.logical = parts[0].logical
            self.historical = parts[0].historical
            return
        first = os.fsdecode(parts[0]) if parts else '.'
        # Backslash paths in immutable manifests are logical Windows paths.
        native_installed = os.name=='nt' and PureWindowsPath(first).is_relative_to(PureWindowsPath(str(ROOT.parent)))
        if len(first) > 2 and first[1] == ':' and not native_installed:
            p = PureWindowsPath(first)
            if not p.is_relative_to(OLD) and p not in EXTERNAL:
                raise ValueError('Historical path is outside the installed scientific source')
            self.logical = p.joinpath(*parts[1:])
            self.historical = True
        else:
            self.logical = NativePath(first, *parts[1:])
            self.historical = False

    @property
    def physical(self):
        if self.historical:
            if self.logical in EXTERNAL:
                return ROOT / EXTERNAL[self.logical]
            rel = self.logical.relative_to(OLD)
            if '..' in rel.parts:
                raise ValueError('Historical path escapes the installed scientific source')
            p=ROOT.joinpath(*rel.parts)
            return NativePath('\\\\?\\'+str(p))if os.name=='nt'else p
        return self.logical

    def __str__(self): return str(self.logical)
    def __fspath__(self): return str(self.physical)
    def __repr__(self): return 'PortablePath(' + repr(str(self)) + ')'
    def __hash__(self): return hash(str(self))
    def __eq__(self, other): return str(self) == str(other)
    def __lt__(self, other): return str(self) < str(other)
    def __truediv__(self, other): return self._wrap(self.logical / str(other),self.historical)
    @property
    def parent(self): return self._wrap(self.logical.parent,self.historical)
    @property
    def parents(self): return tuple(self._wrap(p,self.historical)for p in self.logical.parents)
    @property
    def suffix(self): return self.logical.suffix
    @property
    def name(self): return self.logical.name
    @property
    def parts(self): return self.logical.parts
    def is_absolute(self): return self.logical.is_absolute()
    def is_relative_to(self, other):
        return self.physical.resolve().is_relative_to(NativePath(os.fspath(other)).resolve())
    def relative_to(self, other):
        return Path(str(self.physical.relative_to(NativePath(os.fspath(other)))))
    def resolve(self, strict=False):
        if self.historical:
            if strict and not self.physical.exists(): raise FileNotFoundError(str(self))
            return self
        return self._wrap(self.logical.resolve(strict=strict))
    def is_file(self): return self.physical.is_file()
    def is_dir(self): return self.physical.is_dir()
    def exists(self): return self.physical.exists()
    def stat(self, *a, **kw): return self.physical.stat(*a, **kw)
    def open(self, mode='r', *a, **kw):
        if self.historical and any(c in mode for c in 'wax+'):
            raise ValueError('Frozen historical sources are read-only')
        return self.physical.open(mode, *a, **kw)
    def read_text(self, *a, **kw): return self.physical.read_text(*a, **kw)
    def read_bytes(self): return self.physical.read_bytes()
    def write_text(self, *a, **kw):
        if self.historical: raise ValueError('Frozen source is read-only')
        return self.physical.write_text(*a, **kw)
    def mkdir(self, *a, **kw):
        if self.historical: raise ValueError('Frozen source is read-only')
        return self.physical.mkdir(*a, **kw)
    def with_name(self, name): return self._wrap(self.logical.with_name(name),self.historical)
    def as_posix(self): return self.logical.as_posix()
