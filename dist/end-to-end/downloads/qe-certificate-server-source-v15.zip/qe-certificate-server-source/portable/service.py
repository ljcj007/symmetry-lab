"""Detached authenticated QE-to-certificate execution for the standalone app.

Passwords arrive only via stdin and are held in memory for the original
same-server SSH native driver. They never enter requests, argv or receipts.
"""
from pathlib import Path
import argparse,datetime,hashlib,html,json,os,subprocess,sys,threading,time,uuid,zipfile
from fractions import Fraction
sys.set_int_max_str_digits(0);sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent;PAPER=HERE.parent;ROOT=PAPER.parent
WEB=PAPER/'work/infinite_scf_20261122/web'
sys.path.insert(0,str(WEB))
import runner as R

def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def secret():
    raw=sys.stdin.buffer.readline(16385)
    if not raw or len(raw)>16384:raise ValueError('Authentication input is absent')
    v=json.loads(raw)
    if not isinstance(v.get('password'),str)or not v['password']or any(c in v['password']for c in'\r\n\0'):raise ValueError('Invalid authentication input')
    return v['password']
def output_path(p):
    p=p.resolve()
    if not p.is_relative_to(ROOT/'runs'):raise ValueError('Run output must remain inside installed server runs')
    return p
def safe_request(p):
    if p.stat().st_size>16384:raise ValueError('Request exceeds bounded size')
    d=R.load(p)
    if d.get('schema')not in(None,'qe-certificate-request.v1'):raise ValueError('Unsupported request')
    forbidden={'password','token','secret'}
    def check(v):
        if isinstance(v,dict):
            if forbidden&{str(k).lower()for k in v}:raise ValueError('Credentials must not be stored in requests')
            for vv in v.values():check(vv)
        elif isinstance(v,list):
            for vv in v:check(vv)
    check(d);return d
def status(out,**v):
    p=out/'service.json';old=R.load(p)if p.exists()else{}
    R.save(p,old|v|{'schema':'qe-certificate-service.v1','updated_at':now()})
def readable_certificate(job,result,out):
    def esc(v):return html.escape(str(v))
    def read(relative):
        p=job/relative
        return R.load(p)if p.is_file()else{}
    energy=read('stages/infinite-scf/output/energy-proof/RESULTS.json')
    response=read('stages/infinite-scf/output/response-proof/RESULTS.json')
    accepted=result.get('full_chain_certified')is True
    heading='本次 QE 至完整证书已完成'if accepted else'本次运行尚未获得完整证书'
    def num(v):
        try:return format(float(Fraction(v)),'.3g')
        except(TypeError,ValueError,ZeroDivisionError):return '—'
    rows=''.join('<tr><td>'+esc(s['label'])+'</td><td>'+esc({'SUCCEEDED':'完成并接收','FAILED':'执行中断','UNRESOLVED':'尚未获证','NOT_RUN':'未执行'}.get(s['state'],s['state']))+'</td></tr>'for s in result.get('stages',[]))
    body='''<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>QE 运行证书</title><style>body{font:17px/1.7 system-ui,sans-serif;margin:0;background:#f2f5f7;color:#142d39}main{max-width:900px;margin:40px auto;background:white;padding:36px;border-radius:20px}h1{font-size:30px;line-height:1.3}table{width:100%;border-collapse:collapse}td{padding:12px;border-bottom:1px solid #dce4e8}.lead{font-size:20px;color:#075c53}.note{padding:20px;background:#eef5f5;border-radius:12px}dt{font-weight:bold}dd{margin-bottom:12px}</style><main>'''
    body+='<p>QE 独立运行版 · 本次结果</p><h1>'+heading+'</h1><p class="lead">'+('无限轨道占据自洽根存在性与完整响应可逆性均已接收。'if accepted else'结果按实际执行状态保存，未完成的步骤没有赋予证书。')+'</p>'
    body+='<dl><dt>本次运行编号</dt><dd>'+esc(result['id'])+'</dd><dt>开始时间（UTC）</dt><dd>'+esc(result.get('started_at','—'))+'</dd><dt>本次运行时间</dt><dd>'+num(result.get('elapsed_seconds'))+' 秒</dd></dl><table><tr><th align="left">流程</th><th align="left">本次结果</th></tr>'+rows+'</table>'
    body+='<h2>证书说明</h2><p>本次从原子初猜执行新的 QE 自洽计算，接收完整原生算符导出与未混合输入态；随后执行离子势衔接、无限轨道根存在性与完整响应的最后证明组合。</p><dl>'
    body+='<dt>无限轨道占据自洽根</dt><dd>'+('已接收'if energy.get('root_exists')is True and energy.get('fresh_source_root_exists')is True else'未接收')+'</dd><dt>完整响应（2618 个平均为零的势方向）</dt><dd>'+('已接收'if response.get('complete_infinite_response_invertibility_received')is True else'未接收')+'</dd><dt>轨道 H¹ 球半径</dt><dd>'+num(energy.get('weighted_orbital_chart_H1_radius'))+'</dd><dt>严格边界余量</dt><dd>'+num(energy.get('actual_fresh_source_boundary_margin'))+'</dd></dl>'
    body+='<div class="note"><strong>适用模型与重算范围</strong><p>固定 QE–Si 算例、72 点求积、48³ 电荷观测、UPF 节点的 C¹ 延拓和参考 PBE 能量模型；轨道空间覆盖完整无限倒格子。没有增加连续电荷网格、任意新材料、全局基态或唯一性结论。</p><p>本次 QE 原始数学输入须与完整证明包相符，源有变化就停止接收。此前的大矩阵包围数据及其源文件在服务器逐项验证，最后的根存在性与响应证明组合在本次重新运行。完整证书流程已接收不表示全部大矩阵证明已重新计算。</p></div>'
    body+='<p>同一压缩包内的 run 文件夹保留本次原始 QE 输入输出、阶段日志、RUN.json 与最终证明文件，供详细复核。</p></main></html>'
    for name in('Certificate.html','证书.html'):(out/name).write_text(body,encoding='utf8')
def worker(request,out,password):
    # This private environment is inherited only by the already-approved
    # native driver; no configuration or event serializer reads its values.
    os.environ['DFT_SSH_PASSWORD']=password
    password=None
    status(out,status='RUNNING',full_chain_certified=False,full_chain_recomputed=False)
    R.JOBS=out/'jobs';R.JOBS.mkdir()
    job_id=R.create_job('qe-si-standalone-v1');job=R.JOBS/job_id
    status(out,run_json=str(job/'RUN.json'),job_id=job_id)
    result=R.execute(job_id)
    os.environ.pop('DFT_SSH_PASSWORD',None)
    # The canonical archive contains all fresh raw QE outputs, stage logs and
    # final proof compositions. Static6.8GB received sources stay installed.
    archive=out/'qe-certificate-results.zip'
    readable_certificate(job,result,out)
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6)as z:
        for p in sorted(job.rglob('*')):
            if p.is_file():z.write(p,('run/'+p.relative_to(job).as_posix()))
        z.write(request,'REQUEST.json')
        z.write(HERE/'installation.json','installation.json')
        z.write(out/'Certificate.html','Certificate.html')
        z.write(out/'证书.html','证书.html')
    complete=result.get('full_chain_certified')is True and result.get('status')=='COMPLETED'
    status(out,status='SUCCEEDED'if complete else'PARTIAL'if result.get('status')!='FAILED'else'FAILED',full_chain_certified=complete,full_chain_recomputed=result.get('full_chain_recomputed')is True,result_zip=str(archive),result_bytes=archive.stat().st_size,message_safe='完整证书已生成'if complete else'计算未获完整证书，请查看保留结果。')
def main():
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['start','worker']);ap.add_argument('--request',required=True,type=Path);ap.add_argument('--out',required=True,type=Path);a=ap.parse_args()
    out=output_path(a.out);request=a.request.resolve();safe_request(request)
    if not request.is_relative_to(ROOT/'runs'):raise ValueError('Request outside run root')
    password=secret()
    if a.action=='start':
        out.mkdir(parents=True,exist_ok=False)
        status(out,status='STARTING',full_chain_certified=False,full_chain_recomputed=False)
        env=os.environ.copy();env.pop('DFT_SSH_PASSWORD',None);env['PYTHONDONTWRITEBYTECODE']='1'
        with(out/'service.stdout').open('xb')as fo,(out/'service.stderr').open('xb')as fe:
            p=subprocess.Popen([sys.executable,'-B',str(Path(__file__).resolve()),'worker','--request',str(request),'--out',str(out)],stdin=subprocess.PIPE,stdout=fo,stderr=fe,start_new_session=True,env=env)
            p.stdin.write((json.dumps({'password':password})+'\n').encode());p.stdin.close()
        password=None
        print(json.dumps({'status':'STARTED','pid':p.pid,'service_json':str(out/'service.json')}),flush=True)
    else:
        try:worker(request,out,password)
        except Exception:
            os.environ.pop('DFT_SSH_PASSWORD',None)
            # Keep detailed exceptions in local stage logs. Avoid writing any
            # arbitrary exception string that could include authentication.
            status(out,status='FAILED',full_chain_certified=False,full_chain_recomputed=False,message_safe='服务器流程中断，请查看运行日志。')
            raise
if __name__=='__main__':main()
