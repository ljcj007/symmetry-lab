"""Run one of three approved frozen receivers with explicit path relocation.

Only the pathlib Path import is redirected. Arithmetic, receipt contents,
approval pins, logical source ledger strings and target digest stay intact.
The transformed execution and this adapter are additional trusted code.
"""
from pathlib import Path,PureWindowsPath
import ast, hashlib, os, sys

ROOT = Path(__file__).resolve().parent.parent
APPROVED = {
 'work/infinite_scf_20261121/math/proof_closure_20261122/receive_ionic_input_bridge_v2.py': '232b977ff24b57dad8b96de8abe396d6fa677a2916316f6864684361a3ad25ad',
 'work/infinite_scf_20261121/math/proof_closure_20261122/translated_energy_r72b_29f60d/compose_translated_v2.py': '59e789920743a189ff51e399096c638dc523adf2e01a1fb8e3bcc10c7d35a7b4',
 'work/infinite_scf_20261121/math/proof_closure_20261122/compose_complete_response_r72b_c61e4d_v2.py': 'db3c1ac664a44ddcaeb24cf08f20155324b39ae400aa377b4bf5adca5c8c0a02',
}


def main():
    sys.set_int_max_str_digits(0)
    script = Path(sys.argv[1]).resolve()
    key = script.relative_to(ROOT).as_posix()
    raw = script.read_bytes()
    if hashlib.sha256(raw).hexdigest() != APPROVED.get(key):
        raise ValueError('Unapproved frozen receiver or changed source bytes')
    tree = ast.parse(raw, filename=str(script))
    count = 0
    for node in ast.walk(tree):
        if isinstance(node, ast.ImportFrom) and node.module == 'pathlib':
            if len(node.names) != 1 or node.names[0].name != 'Path':
                raise ValueError('Unexpected pathlib import in approved receiver')
            node.module = 'portable_paths'
            count += 1
    if count != 1: raise ValueError('Exactly one approved Path import required')
    old=PureWindowsPath('C:/Users/ljcj007/Videos/vasp/20261014-group/20261014-group/paper')
    installed=PureWindowsPath(str(ROOT.parent))if os.name=='nt'else None
    def forbid_unmapped_source(event,args):
        if event!='open' or not args or isinstance(args[0],int):return
        raw=os.fsdecode(args[0])
        if len(raw)>2 and raw[1]==':':
            candidate=PureWindowsPath(raw)
            if candidate.is_relative_to(old)and not(installed and candidate.is_relative_to(installed)):
                raise ValueError('Unmapped access to original scientific workspace is forbidden')
    sys.addaudithook(forbid_unmapped_source)
    sys.path.insert(0, str(Path(__file__).parent))
    sys.path.insert(0, str(script.parent))
    sys.argv = [str(script), *sys.argv[2:]]
    ns = {'__name__':'__main__','__file__':str(script),'__package__':None,'__cached__':None}
    exec(compile(tree, str(script), 'exec'), ns)


if __name__ == '__main__': main()
