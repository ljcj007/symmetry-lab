"""Hidden real Tk callback controls; dialogs are simulated, scientific files are real."""
from pathlib import Path
import os,tempfile,unittest
from types import SimpleNamespace
from unittest.mock import patch
import material_gui
import input_import
from test_import import INPUT,upf

runtime=Path(__file__).resolve().parent.parent/'runtime'
if runtime.is_dir():
    os.environ['TCL_LIBRARY']=str(runtime/'tcl/tcl8.6')
    os.environ['TK_LIBRARY']=str(runtime/'tcl/tk8.6')

class InlineThread:
    def __init__(self,target,args,daemon):self.target,self.args=target,args
    def start(self):self.target(*self.args)

class GUIControls(unittest.TestCase):
    def drive(self,root,driver):
        calls=[]
        def execute(request,out,callback):calls.append((request,input_import.prepare_import(request)))
        api=SimpleNamespace(load_settings=lambda:{},load_last_job=lambda:None,save_settings=lambda r:None,
            STATE=root/'Settings',RESULTS=root/'Results',execute=execute)
        api.STATE.mkdir()
        def wrapped(c):
            c['mode'].set('custom-qe');c['refresh']()
            c['host'].set('example.invalid');c['user'].set('test');c['password'].set('transient-test-value')
            return driver(c,calls)
        with patch.object(material_gui.threading,'Thread',InlineThread):
            return material_gui.launch(api,test_driver=wrapped)
    def fixture(self,root):
        expected='C.pbe-n-kjpaw_psl.1.0.0.UPF';chosen=root/'C.pbesol-n-kjpaw_psl.1.0.0.UPF'
        path=root/'scf.in';path.write_text(INPUT.replace('C.UPF',expected).replace("occupations='fixed',","occupations='fixed', input_dft='pbe',"),encoding='utf8')
        chosen.write_bytes(upf());return path,chosen,expected
    def test_selected_different_name_confirmed_then_start_passes_actual_binding(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path,chosen,expected=self.fixture(root);raw=path.read_bytes()
            # Even when an automatic exact-name file exists, the explicit
            # different-name choice must be confirmed and actually used.
            (root/expected).write_bytes(b'automatic exact file')
            def driver(c,calls):
                with patch('tkinter.filedialog.askopenfilename',return_value=str(path)):c['pick_input']()
                with patch('tkinter.filedialog.askopenfilenames',return_value=(str(chosen),)),patch('tkinter.messagebox.askyesno',return_value=True)as ask:c['pick_upf']()
                self.assertEqual(ask.call_count,1);self.assertIn('PBEsol',ask.call_args.args[1]);self.assertIn('pbe',ask.call_args.args[1])
                self.assertIn(str(chosen),c['upf_text'].get());self.assertIn('不适用',c['preview'].get())
                c['begin']();self.assertEqual(len(calls),1)
                request,prepared=calls[0];self.assertIn(expected,request['upf_bindings'])
                self.assertEqual(prepared['files'][1]['local_path'],chosen);self.assertEqual(prepared['files'][1]['original_name'],chosen.name)
                self.assertEqual(path.read_bytes(),raw)
            self.drive(root,driver)
    def test_declining_different_name_blocks_start_even_if_auto_exact_exists(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path,chosen,expected=self.fixture(root);(root/expected).write_bytes(b'automatic exact file')
            def driver(c,calls):
                with patch('tkinter.filedialog.askopenfilename',return_value=str(path)):c['pick_input']()
                with patch('tkinter.filedialog.askopenfilenames',return_value=(str(chosen),)),patch('tkinter.messagebox.askyesno',return_value=False):c['pick_upf']()
                with patch('tkinter.messagebox.showinfo')as info:c['begin']()
                self.assertFalse(calls);self.assertIn('尚未确认',info.call_args.args[1]);self.assertFalse(c['bindings'][0])
            self.drive(root,driver)
    def test_nested_folder_confirmation_and_file_change_stop_before_connect(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);path,chosen,expected=self.fixture(root);nested=root/'folder'/'inner';nested.mkdir(parents=True)
            moved=nested/chosen.name;moved.write_bytes(chosen.read_bytes());chosen.unlink()
            def driver(c,calls):
                with patch('tkinter.filedialog.askopenfilename',return_value=str(path)):c['pick_input']()
                with patch('tkinter.filedialog.askdirectory',return_value=str(root/'folder')),patch('tkinter.messagebox.askyesno',return_value=True):c['pick_folder']()
                self.assertIn(str(moved),c['upf_text'].get());moved.write_bytes(upf(functional='PBE'))
                with patch('tkinter.messagebox.showinfo')as info:c['begin']()
                self.assertFalse(calls);self.assertIn('发生变化',info.call_args.args[1])
            self.drive(root,driver)
    def test_finished_paw_event_replaces_waiting_with_reason_and_not_applicable(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp)
            def driver(c,calls):
                c['apply_event'](dict(event='progress',stages=[dict(id='native',state='QUEUED')]))
                self.assertIn('等待',c['stages'].get())
                c['apply_event'](dict(event='finished',calculation_completed=True,full_chain_certified=False,native_operator_received=False,
                    finite_point_spectrum_certified=False,infinite_scf_certified=False,
                    stages=[dict(id='qe',label='QE 数值计算',state='SUCCEEDED'),dict(id='native',label='NC 原生接收',state='NOT_APPLICABLE'),dict(id='spectrum',label='严格点谱',state='NOT_APPLICABLE')],
                    remaining_obligations=['USPP/PAW 不适用当前 NC 完整算符证明。','无限轨道非线性自洽尚未证明。']))
                self.assertIn('QE 计算已完成',c['status'].get());self.assertNotIn('等待',c['stages'].get())
                self.assertEqual(c['stages'].get().count('不适用'),2);self.assertIn('USPP/PAW',c['details'].get('1.0','end'))
                self.assertIn('无限轨道',c['details'].get('1.0','end'));self.assertFalse(calls)
            self.drive(root,driver)

    def test_current_band_report_button_opens_already_generated_report(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);report=root/'能带与验证.html';report.write_text('offline report',encoding='utf8')
            def driver(c,calls):
                c['apply_event'](dict(event='finished',calculation_completed=True,visualization_file=str(report)))
                with patch.object(material_gui.os,'startfile',create=True)as opened:c['open_view']()
                opened.assert_called_once_with(str(report));self.assertFalse(calls)
            self.drive(root,driver)

    def test_initial_si_demo_opens_without_connection_or_execution(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);demo=root/'Si能带示例.html';demo.write_text('offline Si example',encoding='utf8')
            def driver(c,calls):
                self.assertEqual(c['view_button'].cget('text'),'查看Si示例')
                with patch.object(material_gui.os,'startfile',create=True)as opened:c['open_view']()
                opened.assert_called_once_with(str(demo));self.assertFalse(calls)
            with patch.object(material_gui,'DEMO',demo):self.drive(root,driver)

    def test_history_xml_read_creates_local_report_without_execute(self):
        from test_band_report import XML
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);xml=root/'data-file-schema.xml';xml.write_text(XML,encoding='utf8')
            def driver(c,calls):
                with patch('tkinter.messagebox.askyesnocancel',return_value=True),patch('tkinter.filedialog.askopenfilename',return_value=str(xml)):c['read_history']()
                event=c['events'].get_nowait();self.assertEqual(event['event'],'visualization-ready')
                self.assertTrue(Path(event['path']).is_file());self.assertFalse(calls)
            self.drive(root,driver)

if __name__=='__main__':unittest.main()
