"""Offline display of recorded QE bands and source-matched certificate receipts.

This reader never reruns QE or a mathematical receiver. A source-matched
receipt is not an independently re-proved theorem or an authenticated issuer.
SPDX-License-Identifier: GPL-3.0-or-later
"""
from pathlib import Path, PurePosixPath
from fractions import Fraction
import argparse, hashlib, html, json, math, os, re, stat, zipfile
import xml.etree.ElementTree as ET

HA_EV=27.211386245988
RY_EV=Fraction('13.605693122994')
MAX_XML=32*1024**2
MAX_JSON=16*1024**2
MAX_FILES=16384
PROGRAM='82f4091bcb8f7f9eba7af7694850777eaed1df889f64e24beb7897c57cd9ff0d'
READER='3a2f9bc261aba7a770e9268fa9e1f5e4c57ed2eaca406afbbabb07defc7c9103'

class ReportError(ValueError):pass
def need(value,message):
    if not value:raise ReportError(message)
def finite(value):
    value=float(str(value).replace('D','e').replace('d','e'))
    need(math.isfinite(value),'能带数据含非有限数值。')
    return value
def vec(text):return [finite(x)for x in (text or '').split()]
def clean(value,limit=1000):
    return ''.join(c for c in str(value)if ord(c)>=32)[:limit]
def sha(data):return hashlib.sha256(data).hexdigest()
def approximate_fraction(value):
    """Bounded leading-digit display conversion, never a proof calculation."""
    if isinstance(value,(int,float)):return finite(value)
    text=str(value);need(len(text)<=1024*1024,'模型预算数字超出显示范围。')
    if '/'not in text:return finite(text)
    numerator,denominator=text.split('/',1);negative=numerator.startswith('-')
    numerator=numerator.lstrip('+-').lstrip('0')or'0';denominator=denominator.lstrip('0')or'0'
    need(numerator.isdigit()and denominator.isdigit()and denominator!='0','模型预算分数格式不完整。')
    from decimal import Decimal,localcontext
    with localcontext()as c:
        c.prec=40
        a=numerator[:36];b=denominator[:36]
        approx=Decimal(a)/Decimal(b)*(Decimal(10)**(len(numerator)-len(a)-len(denominator)+len(b)))
    return finite(-approx if negative else approx)

class Source:
    def __init__(self,path):
        self.path=Path(path).resolve();self.zip=None;self.files={}
        if self.path.is_file()and self.path.suffix.lower()=='.xml':
            self.base=self.path.parent;self.files[self.path.name]=self.path
        elif self.path.is_file():
            need(zipfile.is_zipfile(self.path),'请选择结果 ZIP、结果文件夹或 QE XML。')
            self.zip=zipfile.ZipFile(self.path)
            infos=self.zip.infolist();need(len(infos)<=MAX_FILES,'结果包文件数量超出可视化范围。')
            need(sum(i.file_size for i in infos)<=12*1024**3,'结果包展开大小超过 12 GB。')
            seen=set()
            for info in infos:
                p=PurePosixPath(info.filename);mode=(info.external_attr>>16)&0o170000
                normalized=info.filename.rstrip('/').casefold()
                need(not p.is_absolute()and'..'not in p.parts and'\\'not in info.filename and':'not in info.filename,'结果包包含不安全路径。')
                need(normalized not in seen and mode in(0,stat.S_IFREG,stat.S_IFDIR),'结果包有重复文件或链接。')
                seen.add(normalized)
                if not info.is_dir():self.files[info.filename]=info
        else:
            need(self.path.is_dir(),'结果位置不存在。');self.base=self.path
            pending=[(self.path,0)]
            while pending:
                folder,depth=pending.pop()
                for p in folder.iterdir():
                    need(len(self.files)<MAX_FILES,'结果目录文件数量超出可视化范围。')
                    if p.is_symlink()or getattr(p,'is_junction',lambda:False)():continue
                    if p.is_file():self.files[p.relative_to(self.base).as_posix()]=p
                    elif p.is_dir()and depth<12:pending.append((p,depth+1))
    def close(self):
        if self.zip:self.zip.close()
    def read(self,name,limit=MAX_JSON):
        need(name in self.files,'缺少可视化所需文件：'+name)
        row=self.files[name];size=row.file_size if self.zip else row.stat().st_size
        need(size<=limit,'可视化文件过大：'+name)
        if self.zip:
            with self.zip.open(row)as f:data=f.read(limit+1)
        else:data=row.read_bytes()
        need(len(data)<=limit,'可视化文件超过大小限制。');return data
    def digest(self,name):
        need(name in self.files,'证书源文件缺失：'+name)
        row=self.files[name];size=row.file_size if self.zip else row.stat().st_size
        need(size<=512*1024**2,'单个证书源超出 512 MB 显示核对范围。')
        stream=self.zip.open(row)if self.zip else row.open('rb')
        with stream:
            h=hashlib.sha256()
            while data:=stream.read(1024**2):h.update(data)
        return dict(bytes=size,sha256=h.hexdigest())
    def js(self,name):return json.loads(self.read(name).decode('utf-8-sig'))
    def find(self,suffix):
        names=[n for n in self.files if n==suffix or n.endswith('/'+suffix)]
        need(len(names)<=1,'同一结果位置包含多个任务，请选择其中一个结果文件夹或 ZIP。')
        return names[0]if names else None

def cross(a,b):return[a[1]*b[2]-a[2]*b[1],a[2]*b[0]-a[0]*b[2],a[0]*b[1]-a[1]*b[0]]
def dot(a,b):return sum(x*y for x,y in zip(a,b))
def fractional(k,b):
    if not b:return None
    det=dot(b[0],cross(b[1],b[2]));need(abs(det)>1e-14,'倒格矢矩阵不可逆。')
    return[dot(k,cross(b[1],b[2]))/det,dot(k,cross(b[2],b[0]))/det,dot(k,cross(b[0],b[1]))/det]
def xml_bands(data):
    need(b'<!DOCTYPE'not in data.upper()and b'<!ENTITY'not in data.upper(),'不支持带实体声明的 XML。')
    root=ET.fromstring(data)
    need(root.attrib.get('Units','').strip().lower()=='hartree atomic units','XML 未明确使用 Hartree 原子单位，不能猜测能量单位。')
    for e in root.iter():e.tag=e.tag.rsplit('}',1)[-1]
    out=root.find('output');need(out is not None,'QE XML 缺少最终输出。')
    bands=out.find('band_structure');need(bands is not None,'QE XML 缺少能带数据。')
    atom=out.find('atomic_structure');alat=None
    if atom is not None and'alat'in atom.attrib:alat=finite(atom.attrib['alat'])
    recip=out.find('basis_set/reciprocal_lattice');b=None
    if recip is not None:
        b=[vec(recip.findtext('b'+str(i)))for i in(1,2,3)];need(all(len(x)==3 for x in b),'倒格矢数据不完整。')
    rows=[];total=0
    for i,r in enumerate(bands.findall('ks_energies'),1):
        need(i<=4096,'记录 k 点超过 4096 个可视化点。')
        kp=r.find('k_point');need(kp is not None,'QE 缺少 k 点坐标。');k=vec(kp.text);need(len(k)==3,'k 点需三个坐标。')
        energies=[v*HA_EV for v in vec(r.findtext('eigenvalues'))];occ=vec(r.findtext('occupations'))
        need(0<len(energies)<=4096 and(not occ or len(occ)==len(energies)),'能级或占据行数不完整。')
        total+=len(energies);need(total<=2000000,'能带数值超过可视化容量。')
        rows.append(dict(index=i,k_tpiba=k,k_fractional=fractional(k,b),
            k_cartesian_bohr_inverse=[x*2*math.pi/alat for x in k]if alat else None,
            weight=finite(kp.attrib.get('weight',1)),npw=int(r.findtext('npw','0')),
            energies_eV=energies,occupations=occ,certificate=dict(status='NUMERICAL_ONLY')))
    need(rows,'QE XML 没有可显示的能级。')
    nelec=finite(bands.findtext('nelec','0'));fermi=bands.findtext('fermi_energy');highest=bands.findtext('highestOccupiedLevel')
    spin=any(root.findtext(tag,'false').strip().lower()in('true','.true.','t')for tag in('input/spin/lsda','input/spin/noncolin','output/band_structure/lsda','output/band_structure/noncolin'))
    need(not spin,'当前能带视图只支持单一非磁标量能谱通道；自旋或非共线结果已保留，不合并为一组能带。')
    occupation=root.find('input/bands/occupations');kind=occupation.attrib.get('kind')if occupation is not None else None
    if not kind:kind=root.findtext('input/bands/occupations','unknown')
    if kind=='fixed'and highest is not None:reference=highest;reference_kind='highest-occupied'
    elif fermi is not None:reference=fermi;reference_kind='fermi'
    else:reference=highest;reference_kind='highest-occupied'if highest is not None else'absolute'
    return dict(points=rows,nelec=nelec,nbands=max(len(r['energies_eV'])for r in rows),
        energy_reference_eV=finite(reference)*HA_EV if reference is not None else None,
        fermi_raw_eV=finite(fermi)*HA_EV if fermi is not None else None,
        energy_reference_kind=reference_kind,
        occupation_kind=kind,nspin=2 if spin else 1,alat_bohr=alat,reciprocal_lattice_tpiba=b,
        functional=out.findtext('dft/functional','unknown'),energy_unit='eV',raw_energy_unit='Hartree')

def cuts(row):
    values=row.get('cuts_Ry');need(isinstance(values,list)and len(values)==2,'证书谱切口不完整。')
    a,b=[Fraction(x)for x in values];need(a<b,'证书谱切口次序无效。')
    need(Fraction(row['gap_lower_Ry'])==b-a,'严格窗宽与谱切口不一致。')
    gap=(b-a)*RY_EV
    return dict(lower_cut_eV=float(a*RY_EV),upper_cut_eV=float(b*RY_EV),gap_lower_eV=float(gap),
        gap_lower_eV_floor3=f'{(gap*1000).numerator//(gap*1000).denominator/1000:.3f}',cuts_Ry=values)

def receive_finite(source,prefix,run,dataset):
    need(run.get('native_operator_received')is True,'本次结果未接收原生 NC 算符。')
    proof=source.js(prefix+'finite-spectrum/RESULTS.json')
    need(proof.get('schema')=='custom-QE-finite-spectrum-collection.v1','谱证书格式不支持。')
    need(proof.get('program_sha256')==PROGRAM and proof.get('reader_sha256')==READER,'证书接收程序不在当前支持版本中。')
    audit=source.js(prefix+'native/NATIVE_OPERATOR_AUDIT.json');join=source.js(prefix+'native/ORDERED_POINT_RECEPTION.json')
    binding=source.js(prefix+'native/EXECUTION_SOURCE_BINDING.json')
    need(source.digest(dataset['_xml'])==binding['child_XML_is_new_output'],'能带 XML 与原生导出记录不一致。')
    imported=source.js(prefix+'IMPORTED_INPUT.json')
    from qe_input import inspect_upf
    for name,pin in imported['original_sources'].items():
        need(name.startswith('upload/'),'原输入记录路径无效。')
        relative=name[len('upload/'):];actual=prefix+'original-inputs/'+relative
        need(source.digest(actual)==pin,'原输入或赝势与接收记录不一致。')
        if relative.startswith('pseudo/'):
            need(inspect_upf(source.read(actual,64*1024**2).decode('utf8'))['norm_conserving'],'实际赝势不是 NC，不能显示 NC 点谱成功。')
    points=dataset['points'];rows=proof.get('rows',[]);audits=audit.get('rows',[]);joined=join.get('rows',[])
    need(len(rows)==len(audits)==len(joined)==len(points)==proof.get('points_requested'),'原生源、证书与能带点数不一致。')
    rank=proof.get('spectral_index');need(type(rank)is int and rank>0,'谱计数指标无效。')
    for p,row,a,j in zip(points,rows,audits,joined):
        name='ncs_native_k'+str(p['index']).zfill(5)+'.bin'
        need(row.get('file')==a.get('file')==j.get('file')==name,'点序或原生文件清单不一致。')
        pin=source.digest(prefix+'native/'+name)
        need(pin['sha256']==proof['source_files'][name]==row.get('source_sha256')==a.get('sha256'),'谱证书原生源已改变。')
        need(audit['source_files'][name]==pin,'原生接收源身份已改变。')
        k=p['k_cartesian_bohr_inverse'];need(k is not None,'无法将能带坐标对应到原生点。')
        need(len(row.get('k_inverse_bohr',[]))==3 and all(abs(x-y)<=128*2**-52*max(1,abs(x),abs(y))for x,y in zip(k,row['k_inverse_bohr'])),'证书与能带 k 点不一致。')
        ne=a.get('native_energies_eV',[])
        need(len(ne)==len(p['energies_eV'])and max(abs(x-y)for x,y in zip(ne,p['energies_eV']))<=1e-5,'能带数值与原生能级接收记录不一致。')
        need(row.get('dimension')==a.get('full_native_plane_wave_dimension'),'完整有限载体维数不一致。')
        if row.get('finite_point_spectrum_certified')is True:
            need(row.get('spectral_index')==rank and row.get('negative_count_at_lower_cut')==rank and row.get('positive_count_at_upper_cut')==row['dimension']-rank,'谱计数结论不完整。')
            window=cuts(row)
            need(rank<len(p['energies_eV'])and p['energies_eV'][rank-1]<=window['lower_cut_eV']+1e-5 and window['upper_cut_eV']<=p['energies_eV'][rank]+1e-5,'谱切口与已记录前沿能级数值冲突。')
            p['certificate']=dict(status='CERTIFIED',rank=rank,dimension=row['dimension'],
                negative_count_at_lower_cut=rank,positive_count_at_upper_cut=row['dimension']-rank,**window)
        else:p['certificate']=dict(status='UNRESOLVED',rank=rank,reason='此记录点的严格谱界尚未闭合。')
    all_ok=all(p['certificate']['status']=='CERTIFIED'for p in points)
    need(not proof.get('finite_point_spectrum_certified')or(all_ok and proof.get('points_certified')==len(points)),'整体谱证书覆盖与逐点记录不一致。')
    dataset['spectral_index']=rank
    accepted_all=all_ok and proof.get('finite_point_spectrum_certified')is True and run.get('finite_point_spectrum_certified')is True and proof.get('points_certified')==len(points)
    if accepted_all and proof.get('finite_kpoint_common_gap_certified')and run.get('finite_kpoint_common_gap_certified'):
        common=cuts(proof['common_finite_point_gap'])
        need(all(p['certificate']['lower_cut_eV']<=common['lower_cut_eV']+1e-10 and common['upper_cut_eV']<=p['certificate']['upper_cut_eV']+1e-10 for p in points),'共同谱窗超出逐点已接收区间。')
        dataset['common_certificate']=dict(status='CERTIFIED',rank=rank,**common)
    return accepted_all

def _read_dataset(source,trusted=False):
    xmls=[n for n in source.files if n.endswith('data-file-schema.xml')or n.lower().endswith('.xml')and len(source.files)==1]
    need(xmls,'未找到 QE 原始能带 XML。请选择完整结果 ZIP 或含 data-file-schema.xml 的目录。')
    def priority(n):return(0 if'/native/out/'in'/'+n else 1 if'/native72_fresh/'in'/'+n else 2 if'/scf/'in'/'+n else 3,len(n),n)
    xmlname=sorted(xmls,key=priority)[0];dataset=xml_bands(source.read(xmlname,MAX_XML));dataset['_xml']=xmlname
    runname=source.find('run/RUN.json')
    if not runname and 'RUN.json'in source.files:runname='RUN.json'
    run=source.js(runname)if runname else{};prefix=runname[:-len('RUN.json')]if runname else''
    reasons=[clean(x)for x in run.get('remaining_obligations',[])if isinstance(x,str)]
    dataset.update(schema='qe-band-visualization.v1',label=clean(run.get('material_name')or run.get('label')or source.path.stem,160),
        run_id=clean(run.get('id',''),100),common_certificate=None,spectral_index=None,
        model=dict(pseudo_types=[],occupations=dataset['occupation_kind'],functional=dataset['functional']),
        verification=dict(calculation_completed=run.get('calculation_completed')is True or run.get('status')=='COMPLETED',native_operator_received=False,reason=reasons),
        scope=dict(finite_point_spectrum_certified=False,infinite_scf_certified=False,full_chain_certified=False,
                   global_BZ=False,pointwise_eigenvalue_intervals=False,certificate_replayed=False,
                   receipt_integrity_checked=False,description='数值能带只覆盖原始输出中的 k 点；图形不补造连续能带或逐带严格区间。'))
    importedname=prefix+'IMPORTED_INPUT.json'
    if importedname in source.files:
        imported=source.js(importedname);dataset['model']['pseudo_types']=sorted(set(x.get('pseudo_type','unknown')for x in imported.get('pseudopotentials',{}).values()))
    if not trusted:
        dataset['verification']['reason'].append('当前仅导入数值数据；未接收此来源的证书记录。')
    elif run.get('schema')=='custom-QE-run.v1'and prefix+'finite-spectrum/RESULTS.json'in source.files:
        try:
            certified=receive_finite(source,prefix,run,dataset)
            dataset['scope'].update(finite_point_spectrum_certified=certified,receipt_integrity_checked=True)
            dataset['verification']['native_operator_received']=True
            dataset['scope']['description']='绿色窗表示已接收记录点上精确有限载体的无谱区间和完整谱计数；数值能带不等于逐带严格区间。本视图未重跑数学证明。'
        except (ReportError,KeyError,ValueError,TypeError)as exc:
            for p in dataset['points']:p['certificate']=dict(status='UNRESOLVED',reason='证书记录未能与本次显示数据完成源一致性核对。')
            dataset['common_certificate']=None
            dataset['verification']['reason'].append('证书显示未接收：'+clean(exc))
    elif run.get('schema')=='custom-QE-run.v1':
        for p in dataset['points']:p['certificate']=dict(status='NOT_APPLICABLE'if'PAW'in dataset['model']['pseudo_types']or'US'in dataset['model']['pseudo_types']else'NUMERICAL_ONLY')
    elif trusted and run.get('full_chain_certified')is True:
        # Si's model-level theorem is shown separately from its printed bands.
        try:
            need(run.get('status')=='COMPLETED','Si 接收记录未完成。')
            claims=set(run.get('verified_claims',[]))
            need({'infinite_orbital_nonlinear_scf_root_enclosed','complete_infinite_scf_response_invertibility_enclosed'}<=claims,'Si 完整模型结论缺失。')
            for stage in run.get('stages',[]):
                need(stage.get('state')=='SUCCEEDED','Si 前提阶段未全部完成。')
                base=prefix+'stages/'+stage['id']+'/output/'
                need(source.digest(base+'stage-receipt.json')==stage['receipt_pin'],'Si 阶段记录已改变。')
                stage_receipt=source.js(base+'stage-receipt.json')
                need(stage_receipt.get('status')=='ACCEPTED'and stage_receipt.get('run_id')==run['id'],'Si 阶段接收未完成或任务不一致。')
                artifacts={p['path']:p for p in stage_receipt['artifacts']}
                wanted=['RESULTS.json']
                if stage['id']=='native-dft':wanted.append('job/native72_fresh/out/si.save/data-file-schema.xml')
                if stage['id']=='infinite-scf':wanted+=['energy-proof/RESULTS.json','response-proof/RESULTS.json']
                for name in wanted:need(source.digest(base+name)=={k:artifacts[name][k]for k in('bytes','sha256')},'Si 模型关键文件与阶段接收记录不一致。')
            native=source.js(prefix+'stages/native-dft/output/RESULTS.json')
            native_receipt=source.js(prefix+'stages/native-dft/output/stage-receipt.json')
            xml_relative='native72_fresh/out/si.save/data-file-schema.xml'
            need(source.digest(dataset['_xml'])==native['downloaded_files'][xml_relative],'Si 原生能带 XML 与接收记录不一致。')
            receipt=source.js(prefix+'stages/infinite-scf/output/RESULTS.json')
            need(receipt.get('root_exists')is True and receipt.get('complete_response_received')is True and receipt.get('full_infinite_chain_received')is True,'Si 无限模型接收记录缺少实际结论。')
            for key in('mathematical_proof','response_proof'):
                proof=receipt[key];need(source.digest(prefix+'stages/infinite-scf/output/'+proof['path'])=={k:proof[k]for k in('bytes','sha256')},'Si 模型证明文件与接收记录不一致。')
            dataset['scope'].update(infinite_scf_certified=True,full_chain_certified=True,receipt_integrity_checked=True,
                description='固定 Si C¹/PBE 参考方程的无限轨道自洽根与完整响应证书已接收。此模型级结论不为图中的每条 QE 数值能带提供误差棒，也不覆盖连续布里渊区。本视图未重跑数学证明。')
            dataset['verification']['native_operator_received']=native_receipt.get('actual_science_received',{}).get('complete_finite_NC_operator_source')is True
            if dataset['verification']['native_operator_received']:dataset['model']['pseudo_types']=['NC']
            try:
                energy=source.js(prefix+'stages/infinite-scf/output/energy-proof/RESULTS.json')
                response=source.js(prefix+'stages/infinite-scf/output/response-proof/RESULTS.json')
                radius=approximate_fraction(energy['weighted_orbital_chart_H1_radius'])
                alpha=approximate_fraction(response['fresh_complete_chart_energy_Hessian_lower'])
                force=approximate_fraction(energy['reference_true_chart_gradient_dual_upper'])+approximate_fraction(energy['actual_fresh_source_gradient_change_at_translated_center_upper'])
                budget=alpha*radius
                need(budget>0,'模型稳定性预算未给出正显示值。')
                dataset['model_certificate']=dict(status='received',root_exists=True,complete_response_received=True,
                    response_directions=response['mean_zero_potential_dimension'],
                    closure=dict(force_to_boundary_ratio=force/budget,stability_budget_approx=budget,
                        force_upper_approx=force,positive_margin_approx=approximate_fraction(energy['actual_fresh_source_boundary_margin']),
                        inner_radius_H1=radius,normalization='Ephysical/4; fixed H1 chart',values_are_approximate=True),
                    description='这是已接收 Si 参考方程的自洽闭合预算，量纲与归一化按证明记录；不是 eV 能隙，也不是置信度。显示近似值不承担新的数学证明。')
            except (ReportError,KeyError,ValueError,TypeError,OverflowError):
                dataset['verification']['reason'].append('原模型证书已接收；预算数值未能整理成显示摘要。')
        except (ReportError,KeyError,ValueError,TypeError)as exc:dataset['verification']['reason'].append('Si 模型证书显示未接收：'+clean(exc))
    if dataset['spectral_index']is None and dataset['nspin']==1 and dataset['nelec']>0 and abs(dataset['nelec']/2-round(dataset['nelec']/2))<1e-10:
        dataset['spectral_index']=int(round(dataset['nelec']/2))
    if not dataset['verification']['reason']:dataset['verification']['reason']=['证书状态按实际记录显示；数值收敛不替代严格证明。']
    dataset.pop('_xml',None)
    dataset['source_note']='本地读取原始 QE 输出；只作可视化和记录源一致性检查，未运行 QE、未重放数学证明。'
    return dataset

def build_dataset(path,trusted=False):
    source=Source(path)
    try:return _read_dataset(source,trusted)
    except ET.ParseError as exc:raise ReportError('QE XML 格式不完整。')from exc
    finally:source.close()

def history_is_local_result(path):
    p=Path(path).resolve();folder=p if p.is_dir()else p.parent
    if folder.name=='results':folder=folder.parent
    try:
        result=json.loads((folder/'RESULT.json').read_text(encoding='utf8'))
        connection=json.loads((folder/'connection.json').read_text(encoding='utf8'))
        return result.get('schema')=='qe-certificate-client-result.v1'and result.get('run_id')==connection.get('id')and connection.get('schema')in('qe-certificate-request.v1','qe-certificate-request.v2')
    except (OSError,ValueError,TypeError):return False

def write_report(path,out,trusted=False,viewer_dir=None,label=None):
    dataset=build_dataset(path,trusted=trusted)
    if label is not None:dataset['label']=clean(label,160)
    root=Path(viewer_dir)if viewer_dir else Path(__file__).resolve().parent/'viewer'
    if viewer_dir is None and not root.is_dir():root=Path(__file__).resolve().parent.parent/'viewer'
    template=(root/'template.html').read_text(encoding='utf8')
    js=(root/'viewer.js').read_text(encoding='utf8');css=(root/'style.css').read_text(encoding='utf8')
    js=re.sub(r'(?m)^export\s+','',js)
    payload=json.dumps([dataset],ensure_ascii=False,allow_nan=False).replace('<','\\u003c').replace('\u2028','\\u2028').replace('\u2029','\\u2029')
    need(all(token in template for token in('__DATA__','__VIEWER_JS__','__VIEWER_CSS__')),'离线视图模板不完整。')
    rendered=template.replace('__DATA__',payload).replace('__VIEWER_JS__',js).replace('__VIEWER_CSS__',css)
    need('__DATA__'not in rendered and len(rendered.encode('utf8'))<=32*1024**2,'离线视图数据过大或模板未完成。')
    out=Path(out).resolve();out.parent.mkdir(parents=True,exist_ok=True)
    staged=out.with_name(out.name+'.tmp');staged.write_text(rendered,encoding='utf8');os.replace(staged,out)
    return dict(path=str(out),points=len(dataset['points']),bands=dataset['nbands'],
        finite_point_spectrum_certified=dataset['scope']['finite_point_spectrum_certified'])

def main():
    ap=argparse.ArgumentParser();ap.add_argument('source',type=Path);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--trusted-receipt',action='store_true');ap.add_argument('--viewer-dir',type=Path);ap.add_argument('--label');a=ap.parse_args()
    print(json.dumps(write_report(a.source,a.out,a.trusted_receipt,a.viewer_dir,a.label),ensure_ascii=False))
if __name__=='__main__':main()
