"""Meaningful offline-reader controls; no QE, proof replays or network."""
from pathlib import Path
from fractions import Fraction
import hashlib,json,tempfile,unittest,zipfile
import band_report as report

XML='''<espresso Units="Hartree atomic units"><input><spin><lsda>false</lsda><noncolin>false</noncolin></spin><bands><occupations kind="fixed"/></bands></input><output><atomic_structure alat="8"/><basis_set><reciprocal_lattice><b1>1 0 0</b1><b2>0 1 0</b2><b3>0 0 1</b3></reciprocal_lattice></basis_set><band_structure><nelec>2</nelec><fermi_energy>-1</fermi_energy><highestOccupiedLevel>-1</highestOccupiedLevel><ks_energies><k_point weight="1">0 0 0</k_point><npw>10</npw><eigenvalues>-1 1 2</eigenvalues><occupations>1 0 0</occupations></ks_energies></band_structure></output></espresso>'''
def j(v):return json.dumps(v).encode()
def pin(b):return dict(bytes=len(b),sha256=hashlib.sha256(b).hexdigest())
def fixture():
    binary=b'recorded-factor-fixture';xml=XML.encode();raw=b'original-qe';upf=b'<UPF><PP_HEADER element="H" pseudo_type="NC" z_valence="1" functional="PZ"/></UPF>'
    row=dict(file='ncs_native_k00001.bin',source_sha256=pin(binary)['sha256'],dimension=10,spectral_index=1,
        negative_count_at_lower_cut=1,positive_count_at_upper_cut=9,k_inverse_bohr=[0,0,0],finite_point_spectrum_certified=True,cuts_Ry=['-1/2','1/2'],gap_lower_Ry='1')
    pf=dict(schema='custom-QE-finite-spectrum-collection.v1',program_sha256=report.PROGRAM,reader_sha256=report.READER,
        points_requested=1,points_certified=1,spectral_index=1,rows=[row],source_files={row['file']:row['source_sha256']},
        finite_point_spectrum_certified=True,finite_kpoint_common_gap_certified=True,common_finite_point_gap=dict(cuts_Ry=row['cuts_Ry'],gap_lower_Ry='1'))
    run=dict(schema='custom-QE-run.v1',id='fixture',material_name='H fixture',status='COMPLETED',calculation_completed=True,native_operator_received=True,
        finite_point_spectrum_certified=True,finite_kpoint_common_gap_certified=True,remaining_obligations=[])
    audit=dict(rows=[dict(file=row['file'],sha256=row['source_sha256'],full_native_plane_wave_dimension=10,native_energies_eV=[-report.HA_EV,report.HA_EV,2*report.HA_EV])],source_files={row['file']:pin(binary)})
    return {'run/RUN.json':j(run),'run/finite-spectrum/RESULTS.json':j(pf),'run/native/out/custom.save/data-file-schema.xml':xml,
        'run/native/'+row['file']:binary,'run/native/NATIVE_OPERATOR_AUDIT.json':j(audit),
        'run/native/ORDERED_POINT_RECEPTION.json':j(dict(rows=[dict(file=row['file'])])),
        'run/native/EXECUTION_SOURCE_BINDING.json':j(dict(child_XML_is_new_output=pin(xml))),
        'run/IMPORTED_INPUT.json':j(dict(original_sources={'upload/pw.in':pin(raw),'upload/pseudo/H.UPF':pin(upf)},pseudopotentials={'H.UPF':dict(pseudo_type='NC')})),
        'run/original-inputs/pw.in':raw,'run/original-inputs/pseudo/H.UPF':upf}
def write_zip(p,files):
    with zipfile.ZipFile(p,'w')as z:
        for n,b in files.items():z.writestr(n,b)

class BandControls(unittest.TestCase):
    def test_single_point_all_bands_and_fixed_energy_reference(self):
        d=report.xml_bands(XML.encode());self.assertEqual(d['nbands'],3);self.assertEqual(d['points'][0]['k_fractional'],[0,0,0])
        self.assertAlmostEqual(d['points'][0]['energies_eV'][1],report.HA_EV);self.assertEqual(d['energy_reference_kind'],'highest-occupied')
    def test_smearing_uses_actual_printed_fermi(self):
        d=report.xml_bands(XML.replace('kind="fixed"','kind="smearing"').encode());self.assertEqual(d['energy_reference_kind'],'fermi')
    def test_missing_units_spin_and_entities_are_rejected(self):
        for xml in (XML.replace(' Units="Hartree atomic units"',''),XML.replace('<lsda>false','<lsda>true'),'<!DOCTYPE x>'+XML):
            with self.assertRaises(report.ReportError):report.xml_bands(xml.encode())
    def test_missing_energy_and_nonfinite_reject(self):
        for xml in (XML.replace('-1 1 2',''),XML.replace('-1 1 2','NaN 1 2')):
            with self.assertRaises(report.ReportError):report.xml_bands(xml.encode())
    def load(self,files,trusted=True):
        with tempfile.TemporaryDirectory()as temp:
            p=Path(temp)/'result.zip';write_zip(p,files);return report.build_dataset(p,trusted)
    def test_matching_source_record_has_complete_count_not_individual_intervals(self):
        d=self.load(fixture());self.assertTrue(d['scope']['finite_point_spectrum_certified'])
        self.assertFalse(d['scope']['pointwise_eigenvalue_intervals']);self.assertFalse(d['scope']['certificate_replayed'])
        self.assertEqual(d['points'][0]['certificate']['dimension'],10);self.assertEqual(d['common_certificate']['gap_lower_eV_floor3'],'13.605')
    def test_unknown_archive_never_inherits_receipt_claim(self):
        d=self.load(fixture(),False);self.assertFalse(d['scope']['finite_point_spectrum_certified']);self.assertIsNone(d['common_certificate'])
    def test_native_mutation_revokes_display_receipt_without_losing_bands(self):
        f=fixture();f['run/native/ncs_native_k00001.bin']=b'changed';d=self.load(f)
        self.assertFalse(d['scope']['finite_point_spectrum_certified']);self.assertEqual(d['nbands'],3);self.assertIsNone(d['common_certificate'])
    def test_xml_mutation_revokes_receipt(self):
        f=fixture();f['run/native/out/custom.save/data-file-schema.xml']=XML.replace('-1 1 2','-2 1 2').encode()
        self.assertFalse(self.load(f)['scope']['finite_point_spectrum_certified'])
    def test_shifted_cut_or_revoked_outer_does_not_get_common_green(self):
        for mode in ('shift','revoke'):
            f=fixture()
            if mode=='shift':
                p=json.loads(f['run/finite-spectrum/RESULTS.json']);p['rows'][0]['cuts_Ry']=['10','11'];f['run/finite-spectrum/RESULTS.json']=j(p)
            else:
                r=json.loads(f['run/RUN.json']);r['finite_point_spectrum_certified']=False;f['run/RUN.json']=j(r)
            d=self.load(f);self.assertFalse(d['scope']['finite_point_spectrum_certified']);self.assertIsNone(d['common_certificate'])
    def test_paw_result_keeps_numerical_bands_and_not_applicable(self):
        f=fixture();f.pop('run/finite-spectrum/RESULTS.json');r=json.loads(f['run/RUN.json']);r.update(native_operator_received=False,finite_point_spectrum_certified=False);f['run/RUN.json']=j(r)
        f['run/IMPORTED_INPUT.json']=j(dict(pseudopotentials={'H.UPF':dict(pseudo_type='PAW')}))
        d=self.load(f);self.assertEqual(d['points'][0]['certificate']['status'],'NOT_APPLICABLE');self.assertFalse(d['scope']['finite_point_spectrum_certified'])
    def test_zip_path_escape_is_rejected_without_extracting(self):
        with tempfile.TemporaryDirectory()as temp:
            p=Path(temp)/'bad.zip';write_zip(p,{'../outside.xml':XML.encode()})
            with self.assertRaises(report.ReportError):report.build_dataset(p)
            self.assertFalse((Path(temp).parent/'outside.xml').exists())
    def test_offline_html_escapes_data_and_has_no_placeholder(self):
        with tempfile.TemporaryDirectory()as temp:
            root=Path(temp);p=root/'result.zip';f=fixture();r=json.loads(f['run/RUN.json']);r['material_name']='</script><script>bad()</script>';f['run/RUN.json']=j(r);write_zip(p,f)
            out=root/'view.html';report.write_report(p,out,True)
            text=out.read_text(encoding='utf8');self.assertNotIn('__DATA__',text);self.assertNotIn('</script><script>bad()',text);self.assertIn('mountBandExplorer',text)

if __name__=='__main__':unittest.main()
