"""Desktop material importer; scientific acceptance remains server-side.
SPDX-License-Identifier: GPL-3.0-or-later
"""
import datetime
import json
import os
from pathlib import Path
import queue
import threading
import uuid
DEMO=Path(__file__).resolve().parent/'demo/Si能带示例.html'


def stage_summary(rows,terminal=False):
    labels={'SUCCEEDED':'完成','COMPLETED':'完成','RUNNING':'运行中','FAILED':'未完成','ERROR':'未完成',
        'UNRESOLVED':'未获证','SKIPPED':'已跳过','NOT_APPLICABLE':'不适用','PARTIAL':'部分完成',
        'QUEUED':'等待','PENDING':'等待','WAITING':'等待'}
    lines=[]
    for row in rows or []:
        state=row.get('state')or'UNKNOWN'
        label='未执行'if terminal and state in('QUEUED','PENDING','WAITING')else labels.get(state,'状态：'+str(state)[:40])
        if terminal and state=='RUNNING':label='已结束（未确认完成）'
        lines.append(label+'  ·  '+str(row.get('label')or row.get('id')or'执行步骤'))
    return '\n'.join(lines)


def verification_details(event):
    reasons=event.get('remaining_obligations',[])
    return '\n'.join('• '+value for value in reasons if isinstance(value,str))if isinstance(reasons,list)else''


def finished_message(event):
    if event.get('full_chain_certified'):
        return '运行完成：无限轨道自洽存在性与完整响应证书已通过，结果已保存。'
    if event.get('calculation_completed'):
        if event.get('finite_point_spectrum_certified'):
            return '运行完成：QE 计算与有限点谱验证通过；无限轨道自洽尚未获证。结果已保存。'
        if event.get('native_operator_received'):
            return 'QE 计算与原生算符接收已完成；点谱或无限自洽尚未获证。请查看结果报告。'
        return 'QE 计算已完成；本模型未取得 NC 点谱或无限自洽证书。计算结果和说明已保存。'
    return '本次流程未完成，请打开结果文件夹查看运行记录。'


def launch(api, smoke=False, test_driver=None):
    import tkinter as tk
    from tkinter import filedialog, messagebox, ttk
    from input_import import (ImportErrorDetail, find_pseudos, load_input, preview_text, pseudo_preview,
        selected_files, binding_suggestions, binding_confirmation_text, make_binding, merge_selected_files)

    window = tk.Tk()
    if smoke or test_driver:window.withdraw()
    window.title('QE 材料计算与验证')
    window.geometry('980x840')
    window.minsize(920, 760)
    window.configure(background='#f3f8f6')
    style = ttk.Style();style.theme_use('clam')
    style.configure('TFrame', background='#f3f8f6')
    style.configure('TLabel', background='#f3f8f6', foreground='#243d3a', font=('Microsoft YaHei UI', 10))
    style.configure('TLabelframe', background='#f3f8f6')
    style.configure('TLabelframe.Label', background='#f3f8f6', foreground='#103e39', font=('Microsoft YaHei UI', 11, 'bold'))
    style.configure('Title.TLabel', font=('Microsoft YaHei UI', 22, 'bold'), foreground='#103e39')
    style.configure('Start.TButton', font=('Microsoft YaHei UI', 12, 'bold'), padding=10)
    frame = ttk.Frame(window, padding=24);frame.pack(fill='both', expand=True)
    ttk.Label(frame, text='导入材料，一键计算并验证', style='Title.TLabel').pack(anchor='w')
    ttk.Label(frame, text='自带运行环境；连接服务器后自动计算、分层验证并取回可读报告。').pack(anchor='w', pady=(6, 16))
    columns = ttk.Frame(frame);columns.pack(fill='x')
    columns.columnconfigure(0, weight=4);columns.columnconfigure(1, weight=6)
    connection = ttk.LabelFrame(columns, text='计算服务器', padding=16)
    connection.grid(row=0, column=0, sticky='nsew', padx=(0, 16));connection.columnconfigure(1, weight=1)
    saved = api.load_settings()
    host = tk.StringVar(value=str(saved.get('host', '')))
    user = tk.StringVar(value=str(saved.get('user', '')))
    port = tk.StringVar(value=str(saved.get('port', 22)))
    password = tk.StringVar()
    entries = []
    for row, (label, value) in enumerate((('服务器', host), ('用户名', user), ('端口', port), ('密码', password))):
        ttk.Label(connection, text=label).grid(row=row, column=0, sticky='w', padx=(0, 12), pady=5)
        entry = ttk.Entry(connection, textvariable=value, show='●' if label == '密码' else '', width=24)
        entry.grid(row=row, column=1, sticky='ew', pady=5);entries.append(entry)
    ttk.Label(connection, text='密码仅在本次连接中使用。\n记住地址和账号，便于下次运行。', wraplength=300).grid(row=4, column=0, columnspan=2, sticky='w', pady=(12, 0))
    material = ttk.LabelFrame(columns, text='材料与输入', padding=16)
    material.grid(row=0, column=1, sticky='nsew');material.columnconfigure(1, weight=1)
    mode = tk.StringVar(value='si-reference')
    mode_row = ttk.Frame(material);mode_row.grid(row=0, column=0, columnspan=3, sticky='w', pady=(0, 8))
    radios = [ttk.Radiobutton(mode_row, text='内置 Si 完整证书示例', value='si-reference', variable=mode),
              ttk.Radiobutton(mode_row, text='导入自定义 QE 输入', value='custom-qe', variable=mode)]
    for radio in radios:radio.pack(side='left', padx=(0, 12))
    material_name = tk.StringVar()
    input_path = tk.StringVar()
    pseudo_folder = [None]
    selected_upfs = [[]]
    confirmed_bindings = [{}]
    selection_issue = ['']
    current_summary = [None]
    import_widgets = []
    ttk.Label(material, text='材料名称').grid(row=1, column=0, sticky='w', pady=4)
    name_entry = ttk.Entry(material, textvariable=material_name)
    name_entry.grid(row=1, column=1, columnspan=2, sticky='ew', padx=(8, 0), pady=4)
    import_widgets.append(name_entry)
    ttk.Label(material, text='QE 输入').grid(row=2, column=0, sticky='w', pady=4)
    input_label = ttk.Entry(material, textvariable=input_path, state='readonly')
    input_label.grid(row=2, column=1, sticky='ew', padx=8, pady=4)
    choose_input = ttk.Button(material, text='选择文件')
    choose_input.grid(row=2, column=2, sticky='e', pady=4);import_widgets.append(choose_input)
    upf_text = tk.StringVar(value='选择输入后，自动识别所需 UPF。')
    ttk.Label(material, textvariable=upf_text, wraplength=440).grid(row=3, column=0, columnspan=3, sticky='w', pady=(6, 5))
    upf_actions = ttk.Frame(material);upf_actions.grid(row=4, column=0, columnspan=3, sticky='w')
    choose_upf = ttk.Button(upf_actions, text='选择 UPF 文件')
    choose_upf.pack(side='left', padx=(0, 8));import_widgets.append(choose_upf)
    choose_folder = ttk.Button(upf_actions, text='选择 UPF 文件夹')
    choose_folder.pack(side='left');import_widgets.append(choose_folder)
    clear_upf = ttk.Button(upf_actions, text='清除选择')
    clear_upf.pack(side='left', padx=(8,0));import_widgets.append(clear_upf)
    preview = tk.StringVar(value='Si 示例使用已登记的固定输入，自动接续完整无限轨道自洽证书。')
    ttk.Label(material, textvariable=preview, wraplength=460, justify='left').grid(row=5, column=0, columnspan=3, sticky='w', pady=(12, 0))
    ttk.Separator(frame).pack(fill='x', pady=16)
    progress = ttk.Progressbar(frame, mode='indeterminate');progress.pack(fill='x')
    status = tk.StringVar(value='准备就绪。请选择内置示例，或导入自己的输入文件与赝势。')
    ttk.Label(frame, textvariable=status, wraplength=900).pack(anchor='w', pady=(12, 8))
    stages = tk.StringVar(value='① QE 计算　② 原生算符接收　③ 按本材料条件验证并生成报告')
    ttk.Label(frame, textvariable=stages, wraplength=900, justify='left').pack(anchor='w', pady=(0, 12))
    details = tk.Text(frame,height=3,wrap='word',font=('Microsoft YaHei UI',9),background='#f3f8f6',
        foreground='#645125',relief='flat',borderwidth=0,state='disabled')
    details.pack(fill='x',pady=(0,8))
    actions = ttk.Frame(frame);actions.pack(fill='x')
    start = ttk.Button(actions, text='连接并开始运行', style='Start.TButton');start.pack(side='left')
    last_job = [api.load_last_job()]
    resume_button = ttk.Button(actions, text='继续上次任务', state='normal' if last_job[0] else 'disabled')
    resume_button.pack(side='left', padx=(14, 0))
    open_button = ttk.Button(actions, text='打开结果文件夹', state='disabled');open_button.pack(side='left', padx=14)
    view_button=ttk.Button(actions,text='查看Si示例'if DEMO.is_file()else'查看能带与验证',state='normal'if DEMO.is_file()else'disabled');view_button.pack(side='left',padx=(0,8))
    history_button=ttk.Button(actions,text='读取历史结果');history_button.pack(side='left')
    scope = tk.StringVar()
    ttk.Label(frame, textvariable=scope, wraplength=900, font=('Microsoft YaHei UI', 9)).pack(anchor='w', pady=(15, 0))
    events = queue.Queue();running = [False];current_out = [None];running_connection = [None];current_view=[None]

    def refresh_import():
        custom = mode.get() == 'custom-qe'
        for widget in import_widgets:
            widget.configure(state='normal' if custom and not running[0] else 'disabled')
        if custom:
            scope.set('自定义材料分别报告计算、原生算符和有限点谱验证的实际结果；完整无限轨道自洽证书需满足该材料的证明条件。')
            if current_summary[0]:
                preview.set(preview_text(current_summary[0]))
                try:
                    if selection_issue[0]:raise ImportErrorDetail(selection_issue[0])
                    found = find_pseudos(input_path.get(), current_summary[0], selected_upfs[0], pseudo_folder[0],confirmed_bindings[0])
                    used={p for _,p in found}
                    unused=[p.name for p in selected_files(selected_upfs[0],pseudo_folder[0])if p not in used]
                    rows=[name+' → '+str(path)for name,path in found[:3]]
                    upf_text.set('赝势已就绪（输入名称 → 实际使用文件）：\n'+'\n'.join(rows)+
                        ('\n未用于本次输入：'+'、'.join(unused[:3])if unused else''))
                    preview.set(preview_text(current_summary[0])+'\n'+pseudo_preview(found))
                except (ImportErrorDetail, OSError) as exc:
                    upf_text.set(str(exc))
            else:
                preview.set('选择 .in 或 .pwi 输入后，显示结构、截断、k 点和模型。')
        else:
            preview.set('Si 示例：固定 72 点、48³ 电荷观测与完整无限轨道空间。')
            scope.set('内置 Si 示例接收同源大型证明，本次重算 QE、源接收与最终存在性和完整响应闭合。')

    def pick_input():
        path = filedialog.askopenfilename(parent=window, title='导入 QE 输入',
            filetypes=[('QE 输入', '*.in *.pwi *.pw *.inp'), ('所有文件', '*.*')])
        if not path:return
        try:
            _, summary = load_input(path)
        except (ImportErrorDetail, OSError) as exc:
            messagebox.showinfo('输入文件', str(exc), parent=window);return
        input_path.set(path);current_summary[0] = summary
        selected_upfs[0] = [];pseudo_folder[0] = None
        confirmed_bindings[0]={};selection_issue[0]=''
        material_name.set(Path(path).stem)
        refresh_import()

    def pick_upf():
        paths = filedialog.askopenfilenames(parent=window, title='选择本次所需的 UPF 文件',
            filetypes=[('UPF 赝势', '*.UPF *.upf'), ('所有文件', '*.*')])
        if paths:
            selected_upfs[0] = merge_selected_files(selected_upfs[0], paths);pseudo_folder[0] = None
            resolve_selection()

    def pick_folder():
        folder = filedialog.askdirectory(parent=window, title='选择包含所需 UPF 的文件夹')
        if folder:
            pseudo_folder[0] = folder;selected_upfs[0] = []
            resolve_selection()

    def clear_selection():
        selected_upfs[0]=[];pseudo_folder[0]=None;confirmed_bindings[0]={};selection_issue[0]='';refresh_import()

    def resolve_selection():
        confirmed_bindings[0]={};selection_issue[0]=''
        try:
            if current_summary[0] is None:raise ImportErrorDetail('请先选择 QE 输入文件。')
            _,summary=load_input(input_path.get());current_summary[0]=summary
            paths=selected_files(selected_upfs[0],pseudo_folder[0])
            suggestions=binding_suggestions(summary,paths)
            if suggestions:
                # Compute pins before asking; changes while the dialog is open
                # invalidate the approval in find_pseudos / prepare_import.
                bindings={item['required_name']:make_binding(input_path.get(),summary,item['required_name'],item['path'])for item in suggestions}
                if messagebox.askyesno('确认赝势对应关系',binding_confirmation_text(summary,suggestions),parent=window):
                    confirmed_bindings[0]=bindings
                else:selection_issue[0]='尚未确认使用所选的不同名赝势。请选择输入中同名文件，或重新选择并确认。'
        except (ImportErrorDetail,OSError)as exc:selection_issue[0]=str(exc)
        refresh_import()

    def open_results():
        if current_out[0] and current_out[0].is_dir():os.startfile(str(current_out[0]))

    def make_view(source,trusted):
        from band_report import write_report,history_is_local_result
        path=Path(source)
        base=path if path.is_dir()else path.parent
        if base.name=='results':base=base.parent
        try:
            result=write_report(path,base/'能带与验证.html',trusted=trusted or history_is_local_result(path))
            events.put(dict(event='visualization-ready',path=result['path']))
        except Exception as exc:events.put(dict(event='visualization-error',message=str(exc)[:600]))

    def open_view():
        if current_view[0]and Path(current_view[0]).is_file():os.startfile(current_view[0]);return
        if current_out[0]:
            archive=current_out[0]/'QE-certificate-results.zip'
            source=archive if archive.is_file()else current_out[0]
            threading.Thread(target=make_view,args=(source,True),daemon=True).start()
        elif DEMO.is_file():os.startfile(str(DEMO))

    def read_history():
        choice=messagebox.askyesnocancel('读取历史结果','选择结果 ZIP 或 QE XML 文件？\n\n“是”：选择文件；“否”：选择结果文件夹。\n只在本地读取，不上传数据、不重新计算。',parent=window)
        if choice is None:return
        path=filedialog.askopenfilename(parent=window,title='读取已保存结果',filetypes=[('QE 结果 ZIP / XML','*.zip *.xml'),('所有文件','*.*')])if choice else filedialog.askdirectory(parent=window,title='选择一个已完成任务的结果文件夹')
        if path:threading.Thread(target=make_view,args=(Path(path),False),daemon=True).start()

    def begin(resume=False):
        if running[0]:return
        try:
            port_number = int(port.get())
            if not host.get().strip() or not user.get().strip() or not password.get() or not 1 <= port_number <= 65535:
                raise ValueError()
        except ValueError:
            messagebox.showinfo('连接信息', '请填写服务器地址、用户名、有效端口和密码。', parent=window);return
        request = dict(host=host.get().strip(), user=user.get().strip(), port=port_number,
                       password=password.get(), mode=mode.get())
        if resume:
            previous = last_job[0]
            if not previous or any(request[key] != previous[key] for key in ('host', 'user', 'port')):
                messagebox.showinfo('继续上次任务', '请填写上次任务使用的服务器地址、用户名和端口。', parent=window);return
            request.update(resume_output=previous['remote_output'], mode=previous.get('mode', 'si-reference'))
        elif request['mode'] == 'custom-qe':
            try:
                if not input_path.get():raise ImportErrorDetail('请先选择 QE 输入文件。')
                _, summary = load_input(input_path.get())
                if selection_issue[0]:raise ImportErrorDetail(selection_issue[0])
                found = find_pseudos(input_path.get(), summary, selected_upfs[0], pseudo_folder[0],confirmed_bindings[0])
                preview.set(preview_text(summary))
                request.update(qe_input_path=input_path.get(), upf_paths=[str(p)for _,p in found],
                               upf_bindings=confirmed_bindings[0],
                               material_name=material_name.get().strip() or Path(input_path.get()).stem)
            except (ImportErrorDetail, OSError) as exc:
                messagebox.showinfo('材料输入', str(exc), parent=window);return
        password.set('');api.save_settings(request)
        running_connection[0] = {key:request[key]for key in ('host', 'user', 'port', 'mode')}
        stamp = datetime.datetime.now().strftime('%Y%m%d-%H%M%S-')+uuid.uuid4().hex[:8]
        current_out[0] = api.RESULTS/stamp;api.RESULTS.mkdir(parents=True, exist_ok=True)
        current_view[0]=None;view_button.configure(text='查看能带与验证',state='disabled')
        running[0] = True;start.configure(state='disabled');resume_button.configure(state='disabled')
        for entry in entries:entry.configure(state='disabled')
        for radio in radios:radio.configure(state='disabled')
        refresh_import();progress.start(15);status.set('正在准备本次计算…');stages.set('输入检查与服务器连接。')
        threading.Thread(target=api.execute, args=(request, current_out[0], events.put), daemon=True).start()

    def apply_event(event):
        if event['event'] == 'progress':
            if event.get('message'):status.set(event['message'])
            if event.get('stages'):stages.set(stage_summary(event['stages']))
        elif event['event'] == 'started':
            status.set('服务器正在执行本次任务，完成后会自动取回结果。');open_button.configure(state='normal')
            last_job[0] = dict(running_connection[0], remote_output=event['remote_output'])
            (api.STATE/'last-job.json').write_text(json.dumps(last_job[0], ensure_ascii=False, indent=2)+'\n', encoding='utf8')
        elif event['event'] in ('finished', 'error'):
            running[0] = False;progress.stop();start.configure(state='normal')
            resume_button.configure(state='normal' if last_job[0] else 'disabled')
            for entry in entries:entry.configure(state='normal')
            for radio in radios:radio.configure(state='normal')
            refresh_import();open_button.configure(state='normal' if current_out[0]and current_out[0].is_dir() else 'disabled')
            status.set(event['message'] if event['event'] == 'error' else finished_message(event))
            if event.get('stages'):stages.set(stage_summary(event['stages'],terminal=True))
            details.configure(state='normal');details.delete('1.0','end');details.insert('1.0',verification_details(event));details.configure(state='disabled')
            current_view[0]=event.get('visualization_file')
            view_button.configure(text='查看能带与验证'if current_out[0]or current_view[0]else'查看Si示例',state='normal'if(current_out[0]and current_out[0].is_dir())or current_view[0]or DEMO.is_file()else'disabled')
            if event.get('visualization_error'):
                details.configure(state='normal');details.insert('end','\n能带视图尚未生成：'+event['visualization_error']);details.configure(state='disabled')
        elif event['event']=='visualization-ready':
            current_view[0]=event['path'];view_button.configure(text='查看能带与验证',state='normal');os.startfile(event['path'])
        elif event['event']=='visualization-error':
            messagebox.showinfo('能带可视化',event['message']+'\n原计算结果和证书保持原样。',parent=window)

    def receive():
        try:
            while True:
                event = events.get_nowait()
                apply_event(event)
        except queue.Empty:pass
        window.after(180, receive)

    def close():
        if running[0]:
            messagebox.showinfo('任务正在运行', '服务器任务正在运行。请等待结果取回后再关闭程序。', parent=window);return
        window.destroy()

    for radio in radios:radio.configure(command=refresh_import)
    choose_input.configure(command=pick_input);choose_upf.configure(command=pick_upf);choose_folder.configure(command=pick_folder)
    clear_upf.configure(command=clear_selection)
    start.configure(command=begin);resume_button.configure(command=lambda:begin(resume=True));open_button.configure(command=open_results)
    view_button.configure(command=open_view);history_button.configure(command=read_history)
    window.protocol('WM_DELETE_WINDOW', close);entries[0].focus_set();refresh_import()
    if test_driver:
        window.update_idletasks()
        try:return test_driver(dict(window=window,mode=mode,input_path=input_path,material_name=material_name,
            host=host,user=user,port=port,password=password,pick_input=pick_input,pick_upf=pick_upf,
            pick_folder=pick_folder,clear_selection=clear_selection,begin=begin,refresh=refresh_import,
            bindings=confirmed_bindings,selected_upfs=selected_upfs,upf_text=upf_text,preview=preview,
            apply_event=apply_event,status=status,stages=stages,details=details,
            open_view=open_view,read_history=read_history,events=events,current_out=current_out,current_view=current_view,view_button=view_button))
        finally:window.destroy()
    if smoke:
        mode.set('custom-qe');refresh_import();window.update_idletasks()
        result=dict(custom_input_mode=True,qe_input_picker=True,upf_file_and_folder_pickers=True,
                    preview=True,verification_levels_distinct=True,offline_Si_demo=DEMO.is_file())
        window.destroy();return result
    receive();window.mainloop()
