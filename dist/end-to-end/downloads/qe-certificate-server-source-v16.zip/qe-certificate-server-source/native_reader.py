"""Reassemble the complete native NC plane-wave operator decomposition.

Inputs are the task-private post-diagonalization QE exports, never spectral
matrix reconstructions. Agreement with native h_psi is a numerical audit.
The floating native factors may also define a new exact finite source, but no
rigorous arithmetic, native-binary inclusion or all-zone certificate is implied.
"""
from pathlib import Path
import argparse,gzip,hashlib,json,math,os,struct,sys,time
for name in ('OPENBLAS_NUM_THREADS','OMP_NUM_THREADS','MKL_NUM_THREADS'):os.environ[name]='1'
import numpy as np
RY_EV=13.605693122994
def require(x,m):
 if not x:raise ValueError(m)
def sha(p):
 with Path(p).open('rb') as f:return hashlib.file_digest(f,'sha256').hexdigest()
def write(p,obj):
 opener=gzip.open if str(p).endswith('.gz') else open
 with opener(p,'wt',encoding='utf-8') as f:json.dump(obj,f,indent=None if str(p).endswith('.gz') else 2,sort_keys=True,allow_nan=False)
def record(f,endian,expected=None):
 head=f.read(4);require(len(head)==4,'Complete record marker')
 n=struct.unpack(endian+'i',head)[0];require(0<=n<=512*1024**2,'Record budget')
 if expected is not None:require(n==expected,'Exact record size')
 data=f.read(n);tail=f.read(4);require(len(data)==n and tail==head,'Record marker/tail agreement')
 return data
def read_native(path):
 path=Path(path)
 with path.open('rb') as f:
  first=f.read(4);require(len(first)==4,'Header exists')
  options=[e for e in ('<','>') if struct.unpack(e+'i',first)[0]==32]
  require(len(options)==1,'Native diagnostic 32-byte magic')
  e=options[0];f.seek(0);magic=record(f,e,32).decode('ascii').rstrip()
  require(magic=='NCS_NATIVE_NC_V2','Explicit native factor schema v2')
  head=list(struct.unpack(e+'16i',record(f,e,64)))
  keys=['ik','npw','npwx','nbnd','nkb','nat','nspin','current_spin','nr1','nr2','nr3','nr1x','nr2x','nr3x','nnr','nprobe']
  x=dict(zip(keys,head));n=x['npw'];m=x['nbnd'];b=x['nkb'];p=x['nprobe']
  require(0<n<=50000 and 0<m<=256 and 0<=b<=1024 and p==8,'Bounded complete factor dimensions')
  require(x['npwx']>=n and x['nspin']==x['current_spin']==1,'Scalar native context')
  require(x['nr1x']*x['nr2x']*x['nr3x']==x['nnr'],'Full serial padded FFT volume')
  def values(dtype,count):
   dt=np.dtype(e+dtype);a=np.frombuffer(record(f,e,count*dt.itemsize),dtype=dt).copy()
   require(np.isfinite(a).all(),'Finite native numerical factors');return a
  x['k_inverse_bohr']=values('f8',3)
  x['reciprocal_columns_inverse_bohr']=values('f8',9).reshape(3,3,order='F')
  x['energies_Ry']=values('f8',m)
  x['kinetic_Ry']=values('f8',n)
  x['G']=values('i4',3*n).reshape(3,n,order='F').T
  x['fft_nl_1based']=values('i4',n)
  x['local_potential_Ry']=values('f8',x['nnr'])
  x['beta']=values('c16',n*b).reshape(n,b,order='F')
  x['D_Ry']=values('f8',b*b).reshape(b,b,order='F')
  x['frame']=values('c16',n*m).reshape(n,m,order='F')
  x['native_H_frame_Ry']=values('c16',n*m).reshape(n,m,order='F')
  x['probe']=values('c16',n*p).reshape(n,p,order='F')
  x['native_H_probe_Ry']=values('c16',n*p).reshape(n,p,order='F')
  rh=list(struct.unpack(e+'13i',record(f,e,52)))
  rk=['nat','nsp','nhm','lmaxkb','nqx','tab_dim1','tab_dim2','tab_dim3','map_dim1','map_dim2','dense_nr1','dense_nr2','dense_nr3']
  radial=dict(zip(rk,rh));require(radial['nat']==x['nat'],'Atom inventory')
  require(all(0<=v<=100000 for k,v in radial.items() if k!='lmaxkb'),'Nonnegative bounded radial sizes')
  require(all(radial[k]>0 for k in ('nat','nsp','nqx','dense_nr1','dense_nr2','dense_nr3')),'Positive atom/grid/radial sampling sizes')
  x['tpiba'],x['volume_bohr3'],radial['dq_inverse_bohr']=values('f8',3).tolist()
  x['at_columns_alat']=values('f8',9).reshape(3,3,order='F')
  x['tau_columns_alat']=values('f8',3*x['nat']).reshape(3,x['nat'],order='F')
  x['atom_species_1based']=values('i4',x['nat'])
  radial['nh']=values('i4',radial['nsp'])
  radial['ofsbeta_0based']=values('i4',x['nat'])
  mapsize=radial['map_dim1']*radial['map_dim2']
  for key in ['nhtol','nhtolm','indv']:
   radial[key]=values('i4',mapsize).reshape(radial['map_dim1'],radial['map_dim2'],order='F')
  tabsize=radial['tab_dim1']*radial['tab_dim2']*radial['tab_dim3']
  radial['tab']=values('f8',tabsize).reshape(radial['tab_dim1'],radial['tab_dim2'],radial['tab_dim3'],order='F')
  x['radial']=radial
  require(not f.read(1),'No trailing native export bytes')
 return x
def assemble_action(x,psi):
 n=x['npw'];require(psi.shape[0]==n,'Full native carrier')
 logical=(x['nr1'],x['nr2'],x['nr3']);padded=(x['nr1x'],x['nr2x'],x['nr3x'])
 require(all(a<=b for a,b in zip(logical,padded)),'FFT logical dimensions fit padding')
 index=x['fft_nl_1based']-1
 require(len(set(index.tolist()))==n,'No aliased native plane-wave FFT indices')
 coords=np.array(np.unravel_index(index,padded,order='F')).T
 expected=x['G']%np.array(logical)
 require(np.array_equal(coords,expected),'Original native nl mapping equals full integer G modulo logical FFT dimensions')
 potential=x['local_potential_Ry'].reshape(padded,order='F')[:logical[0],:logical[1],:logical[2]]
 states=np.zeros((*logical,psi.shape[1]),dtype=np.complex128)
 ind=tuple(coords.T);states[(*ind,slice(None))]=psi
 realspace=np.fft.ifftn(states,axes=(0,1,2))
 transformed=np.fft.fftn(realspace*potential[...,None],axes=(0,1,2))
 local=transformed[(*ind,slice(None))]
 kinetic=x['kinetic_Ry'][:,None]*psi
 nonlocal_part=x['beta']@(x['D_Ry']@(x['beta'].conj().T@psi))
 return kinetic+local+nonlocal_part,dict(kinetic=kinetic,local=local,nonlocal_part=nonlocal_part)
def audit_one(path,tol):
 x=read_native(path);n=x['npw'];G=x['G'];bg=x['reciprocal_columns_inverse_bohr']
 q=x['k_inverse_bohr'];cart=G@bg.T+q
 kinetic=np.sum(cart*cart,axis=1)
 kinetic_error=float(np.max(abs(kinetic-x['kinetic_Ry'])))
 require(kinetic_error<1e-10,'Native g2kin agrees with complete physical reciprocal carrier')
 H,parts=assemble_action(x,x['frame']);HP,_=assemble_action(x,x['probe'])
 delta=np.linalg.norm(H-x['native_H_frame_Ry'],axis=0)
 probe_delta=np.linalg.norm(HP-x['native_H_probe_Ry'],axis=0)
 residual=np.linalg.norm(x['native_H_frame_Ry']-x['frame']*x['energies_Ry'],axis=0)
 assembled_residual=np.linalg.norm(H-x['frame']*x['energies_Ry'],axis=0)
 gram=x['frame'].conj().T@x['frame']
 hermitianD=float(np.max(abs(x['D_Ry']-x['D_Ry'].T))) if x['nkb'] else 0.
 require(hermitianD<1e-13,'Native NC nonlocal D is symmetric')
 require(float(np.max(delta))<=tol and float(np.max(probe_delta))<=tol,'Full decomposition reproduces native h_psi on all saved states and basis probes')
 return dict(status='PASS_NATIVE_FULL_FACTOR_ACTION_AUDIT',file=path.name,sha256=sha(path),bytes=path.stat().st_size,
  ik=x['ik'],full_native_plane_wave_dimension=n,stored_bands=x['nbnd'],nkb=x['nkb'],
  k_inverse_bohr=q.tolist(),G_min=np.min(G,axis=0).tolist(),G_max=np.max(G,axis=0).tolist(),
  smooth_FFT_logical=[x['nr1'],x['nr2'],x['nr3']],smooth_FFT_padded=[x['nr1x'],x['nr2x'],x['nr3x']],
  kinetic_max_error_Ry=kinetic_error,D_symmetry_error=hermitianD,
  all_stored_frame_action_errors_Ry=delta.tolist(),all_probe_action_errors_Ry=probe_delta.tolist(),
  max_frame_action_error_Ry=float(np.max(delta)),max_probe_action_error_Ry=float(np.max(probe_delta)),
  native_eigenpair_residuals_eV=(residual*RY_EV).tolist(),assembled_eigenpair_residuals_eV=(assembled_residual*RY_EV).tolist(),
  max_native_eigenpair_residual_eV=float(np.max(residual))*RY_EV,
  max_Gram_element_error=float(np.max(abs(gram-np.eye(x['nbnd'])))),
  native_energies_eV=(x['energies_Ry']*RY_EV).tolist(),
  radial_metadata={k:v for k,v in x['radial'].items() if not isinstance(v,np.ndarray)},
  native_projector_l_values=sorted(set(map(int,x['radial']['nhtol'].ravel()))),
  radial_table_all_retained=True,native_source_formula='T + projected discrete FFT multiplication + beta D beta^dagger',
  assembly_numerical_gate_Ry=tol,scope='Actual complete native factor decomposition numerically reassembled, not a 16-state spectral reconstruction. Numerical h_psi agreement is not a strict whole-operator error certificate.')
def main():
 p=argparse.ArgumentParser();p.add_argument('--input',required=True);p.add_argument('--out',required=True);p.add_argument('--assembly-tol-ry',type=float,default=1e-9);a=p.parse_args()
 inp,out=Path(a.input).resolve(),Path(a.out).resolve();require(not out.exists(),'Keep previous audits');out.mkdir(parents=True)
 files=sorted(inp.glob('ncs_native_k*.bin'));require(files,'Native exports exist')
 before={f.name:dict(bytes=f.stat().st_size,sha256=sha(f)) for f in files};write(out/'INPUT_BEFORE.json',before)
 started=time.monotonic();rows=[]
 try:
  for f in files:
   rows.append(audit_one(f,a.assembly_tol_ry));print(json.dumps(rows[-1]),flush=True)
  after={f.name:dict(bytes=f.stat().st_size,sha256=sha(f)) for f in files};write(out/'INPUT_AFTER.json',after);require(before==after,'Native raw factors unchanged')
  result=dict(status='PASS_ALL_NATIVE_FULL_FACTOR_ACTION_AUDITS',points=len(rows),rows=rows,wall_seconds=time.monotonic()-started,
   max_native_frame_action_error_Ry=max(r['max_frame_action_error_Ry'] for r in rows),max_native_probe_action_error_Ry=max(r['max_probe_action_error_Ry'] for r in rows),
   max_native_eigenpair_residual_eV=max(r['max_native_eigenpair_residual_eV'] for r in rows),program_sha256=sha(__file__),numpy=np.__version__,raw_before_after_equal=True)
  write(out/'RESULTS.json',result);print(json.dumps({k:v for k,v in result.items() if k!='rows'}),flush=True)
 except Exception as e:
  write(out/'FAILURE.json',dict(error=type(e).__name__,reason=str(e),completed=rows));raise
if __name__=='__main__':main()
