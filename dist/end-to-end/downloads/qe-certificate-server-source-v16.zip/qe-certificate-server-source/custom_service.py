"""Versioned custom-material service; old Si certificate route is delegated.
SPDX-License-Identifier: GPL-3.0-or-later
"""
from pathlib import Path
import argparse,datetime,hashlib,html,json,math,os,re,shutil,signal,stat,subprocess,sys,time,traceback,uuid,xml.etree.ElementTree as ET,zipfile
import qe_input as QI
sys.set_int_max_str_digits(0);sys.dont_write_bytecode=True
HERE=Path(__file__).resolve().parent
CONFIG=json.loads((HERE/'server-config.json').read_text(encoding='utf8'))if(HERE/'server-config.json').exists()else{}
ROOT=Path(CONFIG.get('root',str(HERE.parents[1]))).resolve()

def need(v,s):
    if not v:raise ValueError(s)
def now():return datetime.datetime.now(datetime.timezone.utc).isoformat()
def pin(p):
    with Path(p).open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return{'bytes':Path(p).stat().st_size,'sha256':h}
def load(p):return json.loads(Path(p).read_text(encoding='utf8'))
def save(p,v):
    Path(p).parent.mkdir(parents=True,exist_ok=True);temp=Path(str(p)+'.pending-'+uuid.uuid4().hex);temp.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8');os.replace(temp,p)
def inside(root,value):
    p=(root/value).resolve();need(p.is_relative_to(root.resolve()),'运行文件必须保留在本次任务目录。');return p
def status(out,**updates):
    p=out/'service.json';old=load(p)if p.exists()else{}
    save(p,old|updates|{'schema':'qe-certificate-service.v1','updated_at':now()})
def read_secret():
    v=json.loads(sys.stdin.buffer.readline(16385));need(isinstance(v.get('password'),str)and bool(v['password']),'需要本次连接认证。');return v['password']
def check_request(request):
    need(request.stat().st_size<=1024*1024,'请求文件过大。');d=load(request)
    need(d.get('schema')=='qe-certificate-request.v2'and d.get('mode')=='custom-qe','自定义材料请求协议错误。')
    def walk(v):
        if isinstance(v,dict):
            need(not({'password','token','secret'}&{str(k).lower()for k in v}),'请求不得存储密码。')
            for x in v.values():walk(x)
        elif isinstance(v,list):
            for x in v:walk(x)
    walk(d);return d
def verify_upload(request,d):
    root=request.parent;rows=d.get('input_files');need(isinstance(rows,list)and 2<=len(rows)<=34,'需要一个 QE 输入文件和相应赝势。')
    seen=set();inputs=[];pseudos={};pins={}
    for row in rows:
        name=row.get('path');need(isinstance(name,str)and'\\'not in name and':'not in name and not Path(name).is_absolute()and'..'not in Path(name).parts,'上传路径无效。')
        need(name not in seen,'上传文件路径重复。');seen.add(name);p=inside(root,name);need(stat.S_ISREG(p.lstat().st_mode),'上传输入必须是普通文件。')
        expected={k:row.get(k)for k in('bytes','sha256')};need(type(expected['bytes'])is int and 0<expected['bytes']<=64*1024*1024,'上传文件大小无效。');need(pin(p)==expected,'上传文件接收不完整或已改变。');pins[name]=expected
        if row.get('role')=='qe-input':need(name=='upload/pw.in','QE 输入必须使用登记的上传位置。');inputs.append(p)
        elif row.get('role')=='pseudopotential':
            need(Path(name).parent.as_posix()=='upload/pseudo'and QI.SAFE_NAME.fullmatch(p.name),'赝势上传位置无效。');pseudos[p.name]=p
        else:raise ValueError('不支持的上传文件类别。')
    need(len(inputs)==1,'需要唯一的 QE 输入文件。');text=inputs[0].read_text(encoding='utf-8-sig');summary=QI.inspect_qe_input(text,pseudo_names=pseudos)
    required={s['pseudo']for s in summary['species']};need(set(pseudos)==required,'仅接收当前 QE 输入实际引用的赝势。')
    upf={name:QI.inspect_upf(path.read_text(encoding='utf8',errors='strict'))for name,path in pseudos.items()}
    return text,summary,upf,pseudos,pins
def xml_data(path):
    need(path.is_file()and path.stat().st_size<=128*1024*1024,'QE XML 不完整或过大。');tree=ET.parse(path)
    for element in tree.iter():element.tag=element.tag.rsplit('}',1)[-1]
    output=tree.getroot().find('output');need(output is not None,'QE 缺少最终 XML 输出。');bands=output.find('band_structure');need(bands is not None,'QE 缺少最终能带数据。')
    nelec=float(bands.findtext('nelec'));nbnd0=bands.findtext('nbnd');nbnd=int(nbnd0)if nbnd0 else max(int(bands.findtext('nbnd_up','1')),int(bands.findtext('nbnd_dw','1')));points=[]
    for row in bands.findall('ks_energies'):
        k=row.find('k_point');vals=[float(v)for v in k.text.split()];need(len(vals)==3 and all(math.isfinite(v)for v in vals),'QE k点数据无效。');points.append(vals+[float(k.attrib.get('weight','1'))])
    need(points and all(math.isfinite(v)for p in points for v in p),'QE k点列表缺失。')
    return{'electrons':nelec,'nbnd':nbnd,'points':points,'functional':output.findtext('dft/functional','')}
def run_program(command,folder,label,timeout=1800,env_extra=None,program_sources=()):
    before=pin(Path(command[0]));env=dict(os.environ,OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
    sources_before={str(Path(p).resolve()):pin(Path(p))for p in program_sources}
    if env_extra:env.update(env_extra)
    t=time.monotonic();timed_out=False;owned_group_stopped=False;pid=None
    with(folder/(label+'.stdout')).open('xb')as fo,(folder/(label+'.stderr')).open('xb')as fe:
        child=subprocess.Popen(command,cwd=folder,stdout=fo,stderr=fe,env=env,start_new_session=True);pid=child.pid
        try:code=child.wait(timeout=timeout)
        except subprocess.TimeoutExpired:
            timed_out=True
            if child.poll()is None:
                need(os.getpgid(pid)==pid and Path('/proc/'+str(pid)+'/cwd').resolve()==folder.resolve(),'超时进程组身份已改变，不能停止未知进程。')
                os.killpg(pid,signal.SIGKILL);owned_group_stopped=True
            code=child.wait(timeout=10)
    result={'command':list(map(str,command)),'pid':pid,'process_group':pid,'owned_group_stopped':owned_group_stopped,'program_before':before,'program_after':pin(Path(command[0])),'additional_programs_before':sources_before,'additional_programs_after':{p:pin(Path(p))for p in sources_before},'environment_overrides':env_extra or{},'returncode':code,'timed_out':timed_out,'seconds':round(time.monotonic()-t,3),'stdout':pin(folder/(label+'.stdout')),'stderr':pin(folder/(label+'.stderr'))}
    save(folder/(label+'-execution.json'),result);need(result['program_before']==result['program_after']and result['additional_programs_before']==result['additional_programs_after'],'执行程序在运行期间已改变。');return result

def point_join(headers,points):
    need(len(headers)==len(points)and bool(points),'Actual requested/native k point count mismatch')
    rows=[]
    for i,(native,proposed)in enumerate(zip(headers,points),1):
        need(native['file']=='ncs_native_k%05d.bin'%i and native['ik']==i,'Native file/header point order mismatch')
        scale=float(native['tpiba']);q=list(map(float,native['k_inverse_bohr']))
        need(math.isfinite(scale)and scale>0 and len(q)==3 and len(proposed)>=3,'Finite native point scale/coordinates required')
        target=[scale*float(v)for v in proposed[:3]];errors=[abs(a-b)for a,b in zip(q,target)];gates=[128*sys.float_info.epsilon*max(1,abs(a),abs(b))for a,b in zip(q,target)]
        need(all(math.isfinite(a)and math.isfinite(b)and e<=t for a,b,e,t in zip(q,target,errors,gates)),'Native k does not correspond to the requested XML point')
        rows.append({'ik':i,'file':native['file'],'requested_tpiba':list(map(float,proposed[:3])),'native_inverse_bohr':q,'max_error_inverse_bohr':max(errors),'component_gates_inverse_bohr':gates})
    return{'status':'RECEIVED_ORDERED_EXPORTED_POINTS_AT_NUMERICAL_INPUT_PRECISION','points':len(rows),'rows':rows,'nominal_point_identity_is_rigorous':False,'strict_spectrum_point_subject':'Recorded binary64 native k and full recorded T,V,beta,D factors, not an exact nominal input point.'}
def k_card(text,points):
    card=['K_POINTS tpiba',str(len(points))]+[' '.join(format(v,'.17g')for v in p)for p in points]
    original=QI.normalize_qe_input(text,calculation='nscf',prefix='custom')
    # Locate the card in normalized text with known line counts from its parser.
    rawlines=original.splitlines();ks=next(i for i,v in enumerate(rawlines)if v.split()and v.split()[0].upper()=='K_POINTS');ke=len(rawlines)
    for i in range(ks+1,len(rawlines)):
        if rawlines[i].split()and rawlines[i].split()[0].upper()in QI.CARDS:ke=i;break
    return'\n'.join(rawlines[:ks]+card+rawlines[ke:])+'\n'
def certificate(out,result):
    esc=lambda v:html.escape(str(v));v=result['verification'];finite=v['finite_point_spectrum_certified'];calc=result['calculation_completed']
    title='自定义材料计算与验证结果'if calc else'本次计算未完成'
    rows=''.join('<tr><td>'+esc(s['label'])+'</td><td>'+esc({'SUCCEEDED':'完成','UNRESOLVED':'未闭合','NOT_APPLICABLE':'模型不适用','FAILED':'执行失败'}.get(s['state'],s['state']))+'</td></tr>'for s in result['stages'])
    lead='已重新计算并严格验证给定k点的完整有限平面波谱。'if finite else'已完成 QE 数值自洽计算，严格证明状态按下表与说明保存。'if calc else'输入、原始日志和失败位置均已保留。'
    body='<!doctype html><html lang="zh-CN"><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>'+title+'</title><style>body{font:17px/1.7 system-ui;background:#f1f6f6;color:#173a3b}main{max-width:920px;margin:32px auto;padding:32px;background:white;border-radius:18px}table{width:100%;border-collapse:collapse}td{padding:12px;border-bottom:1px solid #d5e1e2}.note{padding:20px;background:#edf5f3;border-radius:12px}dt{font-weight:bold}dd{margin-bottom:12px}</style><main><p>QE 自定义材料 · 本次结果</p><h1>'+esc(title)+'</h1><p>'+esc(lead)+'</p><dl><dt>材料</dt><dd>'+esc(result['material_name'])+'</dd><dt>运行编号</dt><dd>'+esc(result['id'])+'</dd><dt>用时</dt><dd>'+format(result['elapsed_seconds'],'.3f')+' 秒</dd></dl><table>'+rows+'</table><h2>本次验证层级</h2><dl>'
    for label,key in [('数值自洽计算','numerical_scf_completed'),('完整原生 NC 算符导出与独立作用重构','native_operator_received'),('完整导出有限载体的给定 k 点谱证书','finite_point_spectrum_certified'),('无限轨道非线性自洽证书','infinite_scf_certified')]:body+='<dt>'+label+'</dt><dd>'+('通过'if v[key]else'尚未获得')+'</dd>'
    body+='</dl><div class="note"><strong>证明对象</strong><p>有限点谱证书以本次原生二进制中完整的 T、V、β、D 因子和全部导出 G 行定义精确有限 Hermitian 算符。数值本征对只提出切口和试探子空间，严格谱计数及尾部比较在本次用 Arb 区间重新计算。没有把 Si 的证明转给新材料。</p><p>该证书不自动扩展到连续 k 点、无限基组或非线性自洽根。数值 SCF 收敛和原生作用重构另行报告。</p></div><h2>尚待满足的条件</h2><ul>'+''.join('<li>'+esc(s)+'</li>'for s in result['remaining_obligations'])+'</ul><p>run 文件夹包含原始导入文件、有效输入、UPF、QE 原始输出、算符源和本次证明结果。</p></main></html>'
    for n in('Certificate.html','证书.html'):(out/n).write_text(body,encoding='utf8')
def worker(request,out):
    d=check_request(request);start=time.monotonic();job=out/'run';job.mkdir();material=str(d.get('material_name')or'自定义材料')[:120]
    stages=[{'id':i,'label':label,'state':'WAITING'}for i,label in [('input-check','导入输入与赝势独立接收'),('qe-scf','全新 QE 数值自洽计算'),('native-export','完整原生算符导出与独立重构'),('finite-spectrum','给定 k 点的严格有限谱验证')]]
    ver={'numerical_scf_completed':False,'native_operator_received':False,'finite_point_spectrum_certified':False,'finite_kpoint_common_gap_certified':False,'infinite_scf_certified':False,'full_chain_certified':False}
    result={'schema':'custom-QE-run.v1','id':d.get('id',request.parent.name),'material_name':material,'status':'RUNNING','started_at':now(),'calculation_completed':False,'full_chain_certified':False,'full_chain_recomputed':False,'verification':ver,'remaining_obligations':[],'stages':stages}
    engine_env={}
    if CONFIG.get('qe_library_path'):engine_env['LD_LIBRARY_PATH']=CONFIG['qe_library_path']+(os.pathsep+os.environ['LD_LIBRARY_PATH']if os.environ.get('LD_LIBRARY_PATH')else'')
    engine_env['I_MPI_PIN']='0'
    def flush():
        result['elapsed_seconds']=round(time.monotonic()-start,3);save(job/'RUN.json',result);status(out,status='RUNNING',run_json=str(job/'RUN.json'),material_name=material,calculation_completed=result['calculation_completed'],verification_level=result.get('verification_level','not-evaluated'),**ver)
    def stage(i,state):stages[i]['state']=state;flush()
    flush();inventory={};summary={};registration=load(HERE/'installation.json');code_before={name:pin(HERE/name)for name in registration['new_trusted_code']}
    try:
        need(code_before==load(HERE/'installation.json')['new_trusted_code'],'登记的自定义材料程序已经改变。')
        need(all(pin(path)==value for path,value in registration.get('qe_library_sources',{}).items()),'登记的 QE 动态库已经改变。')
        stage(0,'RUNNING');text,summary,upf,pseudos,inventory=verify_upload(request,d);shutil.copytree(request.parent/'upload',job/'original-inputs');save(job/'IMPORTED_INPUT.json',{'summary':summary,'pseudopotentials':upf,'original_sources':inventory,'normalization':'Fresh SCF, owned prefix/outdir/pseudo_dir; original bytes retained.'});stage(0,'SUCCEEDED')
        stage(1,'RUNNING');scf=job/'scf';scf.mkdir();(scf/'pseudo').mkdir()
        for name,p in pseudos.items():shutil.copy2(p,scf/'pseudo'/name)
        effective=QI.normalize_qe_input(text,calculation='scf',prefix='custom');(scf/'pw.in').write_text(effective,encoding='utf8');save(scf/'INPUT_BEFORE.json',{p.relative_to(scf).as_posix():pin(p)for p in scf.rglob('*')if p.is_file()})
        exe=Path(CONFIG['qe_executable']);need(exe.is_file(),'服务器 QE 程序不存在。');need(pin(exe)==registration['qe_program'],'已配置 QE 程序的身份已改变。');command=[str(exe),'-in','pw.in'];programs=[exe]
        if CONFIG.get('qe_mpi_ranks',1)>1:
            launcher=Path(CONFIG['qe_mpi_launcher']);need(pin(launcher)==registration['qe_mpi_launcher'],'登记的 SCF MPI 启动器身份已改变。');command=[str(launcher),'-np',str(CONFIG['qe_mpi_ranks']),*command];programs.append(launcher)
        run=run_program(command,scf,'qe',timeout=CONFIG.get('qe_timeout',1800),env_extra=engine_env,program_sources=programs);stdout=(scf/'qe.stdout').read_text(encoding='utf8',errors='replace')
        need(not run['timed_out']and run['returncode']==0 and'JOB DONE.'in stdout and'convergence has been achieved'in stdout,'QE 未完成数值自洽收敛，请查看本次原始日志。')
        for name,value in load(scf/'INPUT_BEFORE.json').items():need(pin(scf/name)==value,'SCF 原始执行输入已改变。')
        parent=scf/'out/custom.save';xml=xml_data(parent/'data-file-schema.xml');save(scf/'FINAL_XML_SUMMARY.json',xml);result['calculation_completed']=True;ver['numerical_scf_completed']=True;result['verification_level']='numerical-scf';stage(1,'SUCCEEDED')
        model_reasons=list(summary['unsupported_native_models'])
        functional=str(xml.get('functional','')).strip().upper()
        allowed_semilocal={'PZ','LDA','PBE','PBESOL','PW','PW91','BLYP','BP','PBE-ERNS','WC','OLYP','REVPBE','RPBE','SLA PW PBX PBC','SLA PZ NOGX NOGC'}
        if functional not in allowed_semilocal:model_reasons.append('最终 QE XML 的泛函未列入当前已验证的标量半局域算符覆盖范围：'+functional)
        if not all(u['norm_conserving']for u in upf.values()):model_reasons.append('USPP/PAW 或其他非 NC 赝势不适用当前标量 NC 完整算符证明。')
        if len(xml['points'])>CONFIG.get('max_native_points',64):model_reasons.append('实际 k 点数量超过当前原生导出与严格谱验证预算。')
        if not CONFIG.get('export_executable'):model_reasons.append('服务器没有配置完整原生 NC 导出程序。')
        if model_reasons:
            stages[2]['state']=stages[3]['state']='NOT_APPLICABLE';result['remaining_obligations']+=model_reasons
        else:
            source_before_proof=None
            try:
                stage(2,'RUNNING');native=job/'native';native.mkdir();save0=native/'out/custom.save';save0.mkdir(parents=True);(native/'pseudo').mkdir()
                parent_before={p.name:pin(p)for p in parent.iterdir()if p.is_file()}
                for p in parent.iterdir():
                    if p.is_file()and(p.name in('charge-density.dat','data-file-schema.xml')or p.suffix.lower()=='.upf'):shutil.copy2(p,save0/p.name)
                for name,p in pseudos.items():shutil.copy2(p,native/'pseudo'/name)
                half=xml['electrons']/2;rank=int(half)if math.isfinite(half)and half>0 and half.is_integer()else None
                nbnd=max(xml['nbnd'],math.ceil(half)+4);need(nbnd<=256,'严格谱验证所需试探态超过当前预算。')
                ntext=QI.normalize_qe_input(text,calculation='nscf',prefix='custom',nbnd=nbnd);ntext=k_card(ntext,xml['points']);ntext=ntext.replace('&SYSTEM\n','&SYSTEM\n nosym=.true.,\n noinv=.true.,\n',1)
                # Remove any imported duplicate symmetry entries before adding
                # the explicit-point choices; only these two booleans change.
                for key in('nosym','noinv'):
                    ntext=re.sub(r'(?im)^\s*'+key+r'\s*=.*?,\s*$', '',ntext)
                ntext=ntext.replace('&SYSTEM\n','&SYSTEM\n nosym=.true.,\n noinv=.true.,\n',1)
                (native/'pw.in').write_text(ntext,encoding='utf8')
                native_inputs={p.relative_to(native).as_posix():pin(p)for p in native.rglob('*')if p.is_file()}
                for name in('charge-density.dat','data-file-schema.xml'):need(native_inputs['out/custom.save/'+name]==parent_before[name],'复制的 NSCF 父输入不一致。')
                save(native/'EXECUTION_INPUT_BEFORE.json',native_inputs)
                export=Path(CONFIG['export_executable']);need(pin(export)==registration['export_program'],'已登记的原生导出程序身份已改变。');ex=run_program([str(export),'-in','pw.in'],native,'qe-export',timeout=CONFIG.get('export_timeout',1800),env_extra=engine_env,program_sources=[export])
                need(not ex['timed_out']and ex['returncode']==0 and'JOB DONE.'in(native/'qe-export.stdout').read_text(errors='replace'),'原生完整 NC 导出未完成；数值 SCF 结果仍保留。')
                need(parent_before=={p.name:pin(p)for p in parent.iterdir()if p.is_file()},'原始 SCF 父电荷或 XML 已改变。')
                for name,expected in native_inputs.items():
                    if name!='out/custom.save/data-file-schema.xml':need(pin(native/name)==expected,'NSCF 执行输入或父电荷已改变。')
                save(native/'EXECUTION_SOURCE_BINDING.json',{'actual_input_before':native_inputs,'parent_before_after_equal':parent_before,'child_XML_is_new_output':pin(native/'out/custom.save/data-file-schema.xml'),'unchanged_input_paths':[name for name in native_inputs if name!='out/custom.save/data-file-schema.xml']})
                files=sorted(native.glob('ncs_native_k*.bin'));need(len(files)==len(xml['points']),'实际 NC 导出点数与本次 SCF 点集不一致。')
                import native_reader
                point_source_before={p.name:pin(p)for p in files};headers=[]
                for path in files:
                    source=native_reader.read_native(path);headers.append({'file':path.name,'ik':source['ik'],'tpiba':source['tpiba'],'k_inverse_bohr':source['k_inverse_bohr'].tolist()})
                join=point_join(headers,xml['points']);save(native/'ORDERED_POINT_RECEPTION.json',join)
                audits=[native_reader.audit_one(p,1e-9)for p in files];save(native/'NATIVE_OPERATOR_AUDIT.json',{'status':'ACCEPTED_COMPLETE_EXPORTED_NC_FACTOR_SOURCES','rows':audits,'source_files':{p.name:pin(p)for p in files},'parent_sources_before_after_equal':parent_before,'strict_native_unrounded_operator_inclusion_claimed':False,'scope':'Numerical reconstruction of all saved-state and probe actions; exact finite factor target defined separately by the recorded dyadic factors.'})
                need(point_source_before=={p.name:pin(p)for p in files},'点序与独立作用接收期间原生源发生改变。')
                ver['native_operator_received']=True;result['verification_level']='native-operator';result['points_requested']=len(files);result['plane_wave_dimensions']=[min(a['full_native_plane_wave_dimension']for a in audits),max(a['full_native_plane_wave_dimension']for a in audits)];stage(2,'SUCCEEDED')
                need(rank is not None,'电子数未给出正整数双占据秩；原生算符接收保留，当前占据谱验证条件未闭合。')
                stage(3,'RUNNING');proof=job/'finite-spectrum';source_before_proof={p.name:pin(p)for p in files};env={'PYTHONPATH':CONFIG.get('scientific_pythonpath','')};proofrun=run_program([sys.executable,'-X','utf8','-B',str(HERE/'finite_certificate.py'),'--input',str(native),'--out',str(proof),'--rank',str(rank),'--max-core',str(CONFIG.get('max_proof_core',512))],job,'finite-proof',timeout=CONFIG.get('proof_timeout',1800),env_extra=env)
                if(proof/'RESULTS.json').is_file():
                    pf=load(proof/'RESULTS.json')
                    need(not proofrun['timed_out']and proofrun['returncode']in(0,3),'严格谱接收器未正常完成。')
                    need(pf.get('schema')=='custom-QE-finite-spectrum-collection.v1'and pf.get('points_requested')==len(files),'严格谱接收器的对象或点数错误。')
                    need(source_before_proof=={p.name:pin(p)for p in files},'严格谱验证期间原生因子已改变。')
                    need(pf.get('source_files')=={name:value['sha256']for name,value in source_before_proof.items()},'谱证书未绑定本次完整原生源。')
                    need(pf.get('program_sha256')==pin(HERE/'finite_certificate.py')['sha256']and pf.get('reader_sha256')==pin(HERE/'native_reader.py')['sha256'],'谱接收程序身份不一致。')
                    accepted=pf.get('finite_point_spectrum_certified')is True
                    if accepted:
                        need(proofrun['returncode']==0 and pf.get('status')=='CERTIFIED_ALL_EXPORTED_FINITE_K_POINTS'and pf.get('points_certified')==len(files)and len(pf.get('rows',[]))==len(files)and not pf.get('remaining_obligations'),'谱证书缺少完整覆盖条件。')
                        need({row.get('file')for row in pf['rows']}==set(source_before_proof),'谱证书存在重复或缺失源点。')
                        for row in pf['rows']:
                            need(row.get('source_sha256')==source_before_proof[row['file']]['sha256']and row.get('spectral_index')==rank and row.get('negative_count_at_lower_cut')==rank and row.get('positive_count_at_upper_cut')==row.get('dimension',0)-rank,'点谱计数或源绑定不完整。')
                    ver['finite_point_spectrum_certified']=accepted;ver['finite_kpoint_common_gap_certified']=accepted and pf.get('finite_kpoint_common_gap_certified')is True;result['points_certified']=pf.get('points_certified',0);result['finite_proof_recomputed']=True
                    if pf.get('common_finite_point_gap'):result['common_gap_lower_eV']=pf['common_finite_point_gap']['gap_lower_eV']
                    if ver['finite_point_spectrum_certified']:result['verification_level']='finite-point-spectrum';stage(3,'SUCCEEDED')
                    else:result['remaining_obligations'].append('部分给定 k 点的严格谱计数未在当前资源预算内闭合。');stage(3,'UNRESOLVED')
                else:result['remaining_obligations'].append('严格谱验证运行未生成完整证明结果，请查看 finite-proof 日志。');stage(3,'UNRESOLVED')
            except Exception as e:
                ver['finite_point_spectrum_certified']=False;ver['finite_kpoint_common_gap_certified']=False
                if source_before_proof is not None:
                    try:stable=source_before_proof=={p.name:pin(p)for p in files}
                    except OSError:stable=False
                    if not stable:ver['native_operator_received']=False;stages[2]['state']='UNRESOLVED'
                result['remaining_obligations'].append(str(e));active=next((s for s in stages[2:]if s['state']=='RUNNING'),None)
                if active:active['state']='UNRESOLVED'
                for s in stages[2:]:
                    if s['state']=='WAITING':s['state']='NOT_APPLICABLE'
        result['remaining_obligations'].append('当前自定义材料没有无限基组、连续 k 空间及非线性自洽根的完整证明；未继承 Si 的证书。')
        need(all(pin(inside(request.parent,n))==p for n,p in inventory.items()),'导入原文或赝势在任务期间已改变。')
        for name,value in load(scf/'INPUT_BEFORE.json').items():need(pin(scf/name)==value,'最终接收时 SCF 执行输入已改变。')
        need(code_before=={name:pin(HERE/name)for name in code_before},'执行程序在任务期间已经改变。')
        result['status']='COMPLETED';result['finished_at']=now();result['input_summary']=summary
    except Exception as e:
        result['status']='FAILED';result['remaining_obligations'].append(str(e));result['finished_at']=now()
        for key in('native_operator_received','finite_point_spectrum_certified','finite_kpoint_common_gap_certified'):ver[key]=False
        result['verification_level']='numerical-scf'if result['calculation_completed']else'not-evaluated'
        for s in stages[2:]:
            if s['state']=='SUCCEEDED':s['state']='UNRESOLVED'
        for s in stages:
            if s['state']=='RUNNING':s['state']='FAILED'
    result['verification_level']='finite-point-spectrum'if ver['finite_point_spectrum_certified']else'native-operator'if ver['native_operator_received']else'numerical-scf'if ver['numerical_scf_completed']else'not-evaluated'
    result['elapsed_seconds']=round(time.monotonic()-start,3);result.update(ver);result['program_sources_before_after_equal']=code_before;save(job/'RUN.json',result);save(job/'RESULTS.json',result);certificate(out,result)
    archive=out/'qe-certificate-results.zip'
    with zipfile.ZipFile(archive,'x',zipfile.ZIP_DEFLATED,compresslevel=6)as z:
        for p in job.rglob('*'):
            if p.is_file():z.write(p,'run/'+p.relative_to(job).as_posix())
        for name in('Certificate.html','证书.html'):z.write(out/name,name)
        z.write(request,'REQUEST.json');z.write(HERE/'installation.json','custom-service-installation.json')
    status(out,status='SUCCEEDED'if result['status']=='COMPLETED'and result['calculation_completed']else'FAILED',run_json=str(job/'RUN.json'),result_zip=str(archive),material_name=material,calculation_completed=result['calculation_completed'],verification_level=result.get('verification_level','not-evaluated'),verification=ver,remaining_obligations=result['remaining_obligations'],message_safe='自定义材料计算已完成，结果按实际验证层级保存。'if result['status']=='COMPLETED'else'本次流程未完成，请查看保留结果。',**ver)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('action',choices=['start','worker']);ap.add_argument('--request',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args();request=a.request.resolve();out=a.out.resolve();need(request.is_relative_to(ROOT/'runs')and out.is_relative_to(ROOT/'runs'),'任务必须位于配置服务器的运行目录。')
    d=load(request)
    if d.get('mode','si-reference')!='custom-qe':
        need(a.action=='start','参考源只能通过登记入口启动。');old_request=request
        if d.get('schema')!='qe-certificate-request.v1':
            old_request=request.with_name('REFERENCE_REQUEST_V1.json');save(old_request,d|{'schema':'qe-certificate-request.v1'})
        os.execv(sys.executable,[sys.executable,'-X','utf8','-B',CONFIG['reference_entry'],'start','--request',str(old_request),'--out',str(out)])
    check_request(request)
    if a.action=='start':
        password=read_secret();password=None;verify_upload(request,d);out.mkdir(parents=True,exist_ok=False);status(out,status='STARTING',full_chain_certified=False,full_chain_recomputed=False,calculation_completed=False)
        env=os.environ.copy();env.pop('DFT_SSH_PASSWORD',None)
        with(out/'service.stdout').open('xb')as fo,(out/'service.stderr').open('xb')as fe:
            child=subprocess.Popen([sys.executable,'-X','utf8','-B',str(Path(__file__).resolve()),'worker','--request',str(request),'--out',str(out)],stdin=subprocess.DEVNULL,stdout=fo,stderr=fe,start_new_session=True,env=env)
        print(json.dumps({'status':'STARTED','pid':child.pid,'service_json':str(out/'service.json')}),flush=True)
    else:
        try:worker(request,out)
        except Exception:
            status(out,status='FAILED',full_chain_certified=False,full_chain_recomputed=False,calculation_completed=False,message_safe='自定义材料流程中断，请查看服务器日志。');raise
if __name__=='__main__':main()
