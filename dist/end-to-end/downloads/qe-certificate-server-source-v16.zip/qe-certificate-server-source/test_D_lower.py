"""Independent exact controls for the generic real-symmetric D lower bound."""
from pathlib import Path
from fractions import Fraction as F
import itertools,json,random
HERE=Path(__file__).resolve().parent

def determinant(a):
    if not a:return F(1)
    return sum(((-1)**j*a[0][j]*determinant([r[:j]+r[j+1:]for r in a[1:]])for j in range(len(a))),F(0))

def lower(D):
    return [max(F(0),sum((abs(D[i][j])for j in range(len(D))if i!=j),F(0))-D[i][i])for i in range(len(D))]

def quadratic(D,x):return sum((x[i]*D[i][j]*x[j]for i in range(len(x))for j in range(len(x))),F(0))

def main():
    rows=[]
    D=[[F(0),F(2)],[F(2),F(0)]];c=lower(D)
    assert c==[2,2]
    assert quadratic(D,[1,-1])==-4
    P=[[D[i][j]+(c[i]if i==j else 0)for j in range(2)]for i in range(2)]
    assert determinant(P)==0 and all(P[i][i]>0 for i in range(2))
    rows.append('offdiagonal_negative_direction_is_retained')
    # A positive kinetic diagonal does not make an indefinite NC source PSD.
    H=[[D[i][j]+(1 if i==j else 0)for j in range(2)]for i in range(2)]
    assert quadratic(H,[1,-1])==-2
    assert min(F(1)-v for v in c)<0
    rows.append('incorrect_PSD_tail_would_miss_a_true_negative_direction')
    rng=random.Random(162023)
    count=0
    for n in (1,2,3,4):
        for case in range(25):
            D=[[F(0)for j in range(n)]for i in range(n)]
            for i in range(n):
                for j in range(i,n):D[i][j]=D[j][i]=F(rng.randrange(-15,16),rng.randrange(1,10))
            c=lower(D);P=[[D[i][j]+(c[i]if i==j else 0)for j in range(n)]for i in range(n)]
            assert all(P[i][i]>=sum(abs(P[i][j])for j in range(n)if i!=j)for i in range(n))
            for size in range(1,n+1):
                for ids in itertools.combinations(range(n),size):
                    assert determinant([[P[i][j]for j in ids]for i in ids])>=0
            count+=1
    rows.append('all_principal_minors_nonnegative_in_100_exact_controls')
    record=dict(status='PASS_EXACT_GENERIC_D_LOWER_CONTROLS',controls=rows,matrix_cases=count,
                arithmetic='fractions.Fraction',general_argument='Hermitian weak diagonal dominance with nonnegative diagonal',
                scope='Controls support the algebraic implementation; the general PSD theorem is proved in SCIENCE_DESIGN_REVIEW.md, not inferred from these cases.')
    (HERE/'D_LOWER_CONTROLS.json').write_text(json.dumps(record,indent=2)+'\n',encoding='utf8')
    print(json.dumps({'status':record['status'],'cases':count}))
if __name__=='__main__':main()
