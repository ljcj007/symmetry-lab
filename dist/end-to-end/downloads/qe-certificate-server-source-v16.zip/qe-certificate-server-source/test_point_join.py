"""Prepared a6 point-identity reception and its independent data controls.

This file tests the actual a6 production function. The numerical reception
gate does not replace the exact dyadic source point in a rigorous certificate.
"""
from pathlib import Path
import json,math,sys,unittest
HERE=Path(__file__).resolve().parent

from custom_service import point_join

class PointControls(unittest.TestCase):
    def setUp(self):
        self.rows=[{'file':'ncs_native_k00001.bin','ik':1,'tpiba':2.,'k_inverse_bohr':[0.,0.,0.]},{'file':'ncs_native_k00002.bin','ik':2,'tpiba':2.,'k_inverse_bohr':[.5,.25,0.]}]
        self.points=[[0.,0.,0.,1],[.25,.125,0.,1]]
    def test_valid_points(self):self.assertEqual(point_join(self.rows,self.points)['points'],2)
    def test_wrong_header_index(self):
        self.rows[1]['ik']=1
        with self.assertRaises(ValueError):point_join(self.rows,self.points)
    def test_wrong_filename(self):
        self.rows[1]['file']='ncs_native_k00003.bin'
        with self.assertRaises(ValueError):point_join(self.rows,self.points)
    def test_wrong_native_point(self):
        self.rows[1]['k_inverse_bohr']=[.5,.26,0.]
        with self.assertRaises(ValueError):point_join(self.rows,self.points)
    def test_wrong_order(self):
        with self.assertRaises(ValueError):point_join(self.rows,list(reversed(self.points)))
    def test_missing_point(self):
        with self.assertRaises(ValueError):point_join(self.rows,self.points[:1])
    def test_nonfinite_coordinate(self):
        self.rows[0]['k_inverse_bohr']=[float('nan'),0,0]
        with self.assertRaises(ValueError):point_join(self.rows,self.points)

if __name__=='__main__':
    suite=unittest.defaultTestLoader.loadTestsFromTestCase(PointControls);r=unittest.TextTestRunner().run(suite)
    (HERE/'POINT_JOIN_CONTROLS.json').write_text(json.dumps({'status':'PASS'if r.wasSuccessful()else'FAILED','tests':r.testsRun,'rejects_missing_reordered_wrong_coordinates_and_nonfinite_points':r.wasSuccessful(),'numerical_join_not_a_rigorous_nominal_k_bridge':True},indent=2)+'\n',encoding='utf8');raise SystemExit(0 if r.wasSuccessful()else 1)
