# QE custom-material server extension v16

This is the source-only extension actually used by the standalone Windows
client. Ordinary desktop users only download the client and connect to an
already configured server. This archive contains no login settings, UPF,
material input/output, QE executable, shared library or large Si proof corpus.

## Computation and verification

The custom route independently receives a static SCF/nscf input and every UPF
referenced by ATOMIC_SPECIES. It retains the original bytes. Its effective input
uses a fresh SCF, an owned prefix/output/pseudopotential directory and controlled
startup choices. A Gamma-only card is expanded to an explicit complex Gamma
point so the exported carrier is complete. Other card values and structures
remain attributable to the retained original and effective input files.

The configured standard QE program runs SCF with MPI2. In the tested server,
MPI2 avoids a stalled singleton runtime. The native NC exporter always runs
serially to keep a full Fourier grid. Library directories are passed only to
the QE children; they do not replace the Python/Arb environment. Both programs
and the MPI launcher are bound to registered source bytes. A timeout stops only
the verified process group launched for that working directory.

Scalar semilocal norm-conserving sources are independently reconstructed from
all exported T,V,beta,D factors and complete G rows. Every requested file/header
index is joined to the actual SCF XML point list at double-input precision.
The strict mathematical object remains the recorded dyadic factors and actual
exported point. The numerical point join is not a rigorous nominal-k bridge.

For that exact finite Hermitian source, Arb recomputes full positive/negative
spectral counts. Approximate eigenvalues and vectors propose cuts/congruences
only. Signed and offdiagonal real-symmetric D is retained: exact diagonal
dominance gives D >= -diag(c), c_i=max(0,sum_{j!=i}|D_ij|-D_ii). A Woodbury tail
comparison and complete core/tail inertia control all exported rows. Saved
states are not substituted for the full operator.

The spectrum result covers the reported finite k-point set and finite carrier.
It does not certify a continuous Brillouin zone, infinite basis or nonlinear SCF
root. USPP/PAW, spin-orbit, magnetic and other unsupported NC extensions can
still return a numerical QE result with the unavailable proof layers explicit.
Resource exhaustion or a failed strict inequality remains UNRESOLVED.

The original fixed Si infinite-orbital workflow is delegated to the unchanged
v15 entry. A custom material never inherits that theorem by its name or input
shape. All failed runs and source/proof records remain separate.

## Administrator preparation

This extension expects an existing configured v15 server root and original Si
reference entry at ROOT/paper/portable/service.py. Prepare a new directory under
ROOT/extensions; retain the previous installed extension and registry backup.
Provide a trusted scientific Python (tested Python3.12, NumPy2.5.2,
python-flint0.8.0), a working standard pw.x, the complete NCS_NATIVE_NC_V2 scalar
NC exporter, its required runtime libraries and the existing proof resources.

Example paths below are placeholders, not settings for a particular account:

```
/path/to/scientific/python -B install_custom_service.py \
  --root /path/to/qe-certificate-server \
  --qe-executable /path/to/pw.x \
  --export-executable /path/to/pw_export.x \
  --scientific-pythonpath /path/to/arb-and-numpy/site-packages \
  --qe-library-path /path/to/oneapi/mkl/lib \
  --qe-mpi-launcher /path/to/mpirun --qe-mpi-ranks 2
```

Run the imported-material and reference-route checks first. The installer can
then be invoked with the same arguments and `--activate` to atomically update
the per-account service registry while saving REGISTRY_BEFORE.json. No password
is written. The client continues to discover ~/.local/share/qe-certificate/server.json.
This data/path control is not an operating-system sandbox or hostile-host
attestation. Keep administrative access and trusted runtime sources explicit.

## Independent source controls

With only Python, run `python -B test_point_join.py` and
`python -B test_D_lower.py`. With NumPy and python-flint available, run
`python -B test_finite_sources.py`. These create fresh synthetic finite sources
and counterexamples in the extracted directory; they never run QE, need UPFs,
modify original scientific data, or assert an SCF theorem. The tests cover
missing/reordered/mismatched points, generic signed D, local-only sources,
complex beta, a nontrivial 3D Fourier potential, resource limits and changed
source rejection. Their outputs are diagnostics, not new material evidence.

The five production files and SOURCE_MANIFEST.json are copied byte-for-byte
from the frozen a6 server extension. PUBLIC_CODE_MANIFEST.json additionally
describes the source-only archive members. New source code retains the included
GPL-3.0-or-later license. Runtime dependencies, original scientific data and
pseudopotentials retain their own licenses and are not redistributed here.
