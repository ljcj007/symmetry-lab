"""Independent tiny source controls; no QE or original scientific data writes."""
from pathlib import Path
from fractions import Fraction
import contextlib,datetime,hashlib,importlib.util,io,json,math,shutil,struct,sys,uuid
HERE=Path(__file__).resolve().parent
SCI=HERE
sys.path.insert(0,str(SCI))
import numpy as np
import native_reader as Native
import finite_certificate as FC

def sha(p):
    with p.open('rb')as f:return hashlib.file_digest(f,'sha256').hexdigest()

def fixture(path,D,three_d=False):
    g=np.array([-10,-9,-8,-2,-1,0,1,2,8,9,10],dtype=np.int32)
    G=np.array([(0,0,0),(1,0,0),(-1,0,0),(0,1,0),(0,-1,0),(0,0,1),(0,0,-1),(8,0,0),(-8,0,0),(0,3,0),(0,-3,0),(0,0,3),(0,0,-3)],dtype=np.int32)if three_d else np.column_stack([g,np.zeros(len(g),dtype=np.int32),np.zeros(len(g),dtype=np.int32)])
    shape=(19,7,7)if three_d else(33,1,1);grid=math.prod(shape)
    n=len(G);b=D.shape[0];bands=3;probes=8
    q=np.array([.125,.25,-.125])if three_d else np.array([.125,0.,0.]);T=np.sum((G+q)**2,axis=1)
    B=np.column_stack([np.ones(n)/16,(-1.)**np.arange(n)/32])if b else np.zeros((n,0),complex)
    B=B.astype(complex)
    if three_d and b:B[:,1]*=1j
    r=np.array(np.unravel_index(np.arange(grid),shape,order='F')).T
    V=-2+.07*np.sin(2*np.pi*r[:,0]/shape[0])+.03*np.cos(2*np.pi*r[:,1]/shape[1])+.05*np.sin(2*np.pi*r[:,2]/shape[2])if three_d else np.full(grid,-2.)
    Ugrid=np.exp(2j*np.pi*((r/np.array(shape))@G.T))/np.sqrt(grid)
    H=np.diag(T)+(Ugrid.conj().T@(V[:,None]*Ugrid))+B@D@B.conj().T;H=(H+H.conj().T)/2
    e,U=np.linalg.eigh(H);frame=U[:,:bands].astype(complex)
    probe=np.eye(n,dtype=complex)[:,:probes]
    def record(f,data):f.write(struct.pack('<i',len(data)));f.write(data);f.write(struct.pack('<i',len(data)))
    def arr(f,value,dtype):record(f,np.asarray(value,dtype=dtype).tobytes(order='F'))
    with path.open('xb')as f:
        record(f,b'NCS_NATIVE_NC_V2'.ljust(32,b' '))
        arr(f,[1,n,n,bands,b,1,1,1,*shape,*shape,grid,probes],'<i4')
        arr(f,q,'<f8');arr(f,np.eye(3),'<f8');arr(f,e[:bands],'<f8');arr(f,T,'<f8')
        arr(f,G.T,'<i4');arr(f,np.ravel_multi_index(tuple((G%np.array(shape)).T),shape,order='F')+1,'<i4');arr(f,V,'<f8')
        arr(f,B,'<c16');arr(f,D,'<f8');arr(f,frame,'<c16');arr(f,H@frame,'<c16');arr(f,probe,'<c16');arr(f,H@probe,'<c16')
        arr(f,[1,1,b,1 if b else -1,1,1,1 if b else 0,1,b,1,*shape],'<i4')
        arr(f,[1.,1.,1.],'<f8');arr(f,np.eye(3),'<f8');arr(f,np.zeros((3,1)),'<f8');arr(f,[1],'<i4')
        arr(f,[b],'<i4');arr(f,[0],'<i4')
        for values in([0,1]if b else[],[1,2]if b else[],[1,1]if b else[]):arr(f,values,'<i4')
        arr(f,[.1]if b else[],'<f8')
    return H

def main():
    out=HERE/('controls_'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S')+'_'+uuid.uuid4().hex[:6]);out.mkdir(parents=True)
    code={str(p):sha(p)for p in(SCI/'finite_certificate.py',SCI/'native_reader.py')}
    rows=[]
    for label,D in [('local-only',np.zeros((0,0))),('signed-diagonal',np.diag([-1.,2.])),('offdiagonal-indefinite',np.array([[2.,3.],[3.,2.]])),('complex-three-dimensional',np.array([[2.,3.],[3.,2.]]))]:
        folder=out/label;folder.mkdir();source=folder/'ncs_native_k00001.bin';H=fixture(source,D,three_d=label=='complex-three-dimensional')
        audit=Native.audit_one(source,1e-9);assert audit['status']=='PASS_NATIVE_FULL_FACTOR_ACTION_AUDIT'
        p=FC.one(source,folder,1,max_core=64)
        assert p['finite_point_spectrum_certified']is True and p['infinite_scf_certified']is False and p['global_BZ_certified']is False
        assert p['negative_count_at_lower_cut']==1 and p['positive_count_at_upper_cut']==len(H)-1
        assert p['source_sha256']==sha(source) and p['tail_and_core']['tail']>0
        if label=='local-only':assert p['D_negative_comparison_exact']==[] and p['tail_and_core']['signed_tail_comparison']is None
        else:assert any(Fraction(v)>0 for v in p['D_negative_comparison_exact']) and p['tail_and_core']['signed_tail_comparison']['certified']is True
        # A direct numerical eigenspectrum is only an independent diagnostic;
        # the pass above comes from the actual Arb negative/positive counts.
        w=np.linalg.eigvalsh(H);a,b=map(Fraction,p['cuts_Ry']);assert w[0]<float(a)<float(b)<w[1]
        rows.append(dict(control=label,passed=True,finite_point=True,tail_rows=p['tail_and_core']['tail'],source_sha256=sha(source)))
    resource=out/'resource';resource.mkdir();source=resource/'ncs_native_k00001.bin';fixture(source,np.diag([-1.,2.]))
    try:FC.one(source,resource,1,max_core=2)
    except ValueError as e:assert 'resource guard'in str(e)
    else:raise AssertionError('A resource guard cannot certify an unchecked positive core')
    assert not(resource/'ncs_native_k00001.json').exists();rows.append(dict(control='core-resource-refuses-certificate',passed=True))
    target=out/'hash-change';target.mkdir();source=target/'ncs_native_k00001.bin';fixture(source,np.zeros((0,0)));actual_sha=Native.sha;calls=[]
    def unstable(p):
        calls.append(str(p));return actual_sha(p)if len(calls)==1 else'changed-source'
    try:
        Native.sha=unstable
        try:FC.one(source,target,1,max_core=64)
        except ValueError as e:assert 'changed while certifying'in str(e)
        else:raise AssertionError('Changed source cannot obtain a point certificate')
    finally:Native.sha=actual_sha
    assert not(target/'ncs_native_k00001.json').exists();rows.append(dict(control='before-after-source-change-refuses-certificate',passed=True))
    collection=out/'collection-input';collection.mkdir()
    for i in(1,2):fixture(collection/('ncs_native_k%05d.bin'%i),np.diag([-1.,2.]))
    previous=sys.argv[:]
    try:
        sys.argv=['finite_certificate.py','--input',str(collection),'--out',str(out/'collection-result'),'--rank','1','--max-points','1']
        with contextlib.redirect_stdout(io.StringIO()):rc=FC.main()
    finally:sys.argv=previous
    result=json.loads((out/'collection-result/RESULTS.json').read_text(encoding='utf8'))
    assert rc==3 and result['finite_point_spectrum_certified']is False and result['points_certified']==1 and result['points_requested']==2
    assert any(v['reason']=='point-resource-guard'for v in result['remaining_obligations'])
    rows.append(dict(control='point-resource-partial-cannot-certify-all',passed=True))
    assert code=={p:sha(Path(p))for p in code}
    for p in code:shutil.copy2(p,out/Path(p).name)
    report=dict(status='PASS_INDEPENDENT_TINY_FINITE_SOURCE_CONTROLS',scientific_sources=code,synthetic_sources_only=True,qe_started=False,controls=rows)
    (out/'SUMMARY.json').write_text(json.dumps(report,indent=2)+'\n',encoding='utf8')
    (HERE/'LATEST_CONTROLS.json').write_text(json.dumps({'report':str(out/'SUMMARY.json'),'status':report['status'],'controls':len(rows)},indent=2)+'\n',encoding='utf8')
    print(json.dumps({'status':report['status'],'controls':len(rows),'out':str(out)}))
if __name__=='__main__':main()
