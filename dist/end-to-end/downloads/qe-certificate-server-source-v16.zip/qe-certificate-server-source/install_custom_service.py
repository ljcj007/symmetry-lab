"""Register the new custom-material extension without changing frozen Si code."""
from pathlib import Path
import argparse,hashlib,json,os,sys,time
HERE=Path(__file__).resolve().parent
def pin(p):
    p=Path(p)
    with p.open('rb')as f:h=hashlib.file_digest(f,'sha256').hexdigest()
    return{'bytes':p.stat().st_size,'sha256':h}
def save(p,v):
    p=Path(p);temp=p.with_name(p.name+'.pending');temp.write_text(json.dumps(v,ensure_ascii=False,indent=2)+'\n',encoding='utf8');temp.chmod(0o600);os.replace(temp,p)
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--root',type=Path,required=True);ap.add_argument('--qe-executable',type=Path,required=True);ap.add_argument('--export-executable',type=Path,required=True);ap.add_argument('--scientific-pythonpath',default='');ap.add_argument('--qe-library-path',default='');ap.add_argument('--qe-mpi-launcher',type=Path);ap.add_argument('--qe-mpi-ranks',type=int,default=1);ap.add_argument('--activate',action='store_true');a=ap.parse_args();root=a.root.resolve()
    if not HERE.resolve().is_relative_to(root/'extensions'):raise ValueError('Install into a new versioned extension under the existing server root')
    reference=root/'paper/portable/service.py'
    for p in(reference,a.qe_executable,a.export_executable):
        if not p.is_file():raise ValueError('Required existing program absent: '+str(p))
    if not(1<=a.qe_mpi_ranks<=16):raise ValueError('SCF MPI ranks must remain between1 and16')
    if a.qe_mpi_ranks>1 and(a.qe_mpi_launcher is None or not a.qe_mpi_launcher.is_file()):raise ValueError('Explicit existing MPI launcher required for parallel SCF')
    library_paths=[Path(p).resolve()for p in a.qe_library_path.split(os.pathsep)if p]
    if any(not p.is_dir()for p in library_paths):raise ValueError('QE library directory is absent')
    library_files={str(p/name):pin(p/name)for p in library_paths for name in('libmkl_sequential.so.2','libmkl_core.so.2','libmkl_intel_lp64.so.2')if(p/name).is_file()}
    config={'schema':'custom-QE-server-extension.v1','root':str(root),'reference_entry':str(reference),'qe_executable':str(a.qe_executable.resolve()),'qe_mpi_launcher':str(a.qe_mpi_launcher.resolve())if a.qe_mpi_launcher else None,'qe_mpi_ranks':a.qe_mpi_ranks,'export_executable':str(a.export_executable.resolve()),'scientific_pythonpath':a.scientific_pythonpath,'qe_library_path':os.pathsep.join(map(str,library_paths)),'qe_library_sources':library_files,'qe_timeout':1800,'export_timeout':1800,'proof_timeout':1800,'max_native_points':64,'max_proof_core':512}
    save(HERE/'server-config.json',config)
    record={'schema':'custom-QE-server-installation.v1','python':sys.executable,'new_trusted_code':{p.name:pin(p)for p in sorted(HERE.glob('*.py'))},'qe_program':pin(a.qe_executable),'export_program':pin(a.export_executable),'qe_library_paths':list(map(str,library_paths)),'qe_library_sources':library_files,'reference_entry':pin(reference),'old_sources_modified':False,'activated':False,'created_at':time.time()}
    if a.qe_mpi_launcher:record['qe_mpi_launcher']=pin(a.qe_mpi_launcher)
    if a.activate:
        registry=Path.home()/'.local/share/qe-certificate/server.json';old=json.loads(registry.read_text(encoding='utf8'))
        if old['schema']!='qe-certificate-server.v1'or Path(old['root']).resolve()!=root:raise ValueError('Existing server registration differs')
        backup=HERE/'REGISTRY_BEFORE.json'
        if backup.exists():raise ValueError('Preserve old activation; choose a fresh extension directory')
        save(backup,old);cap=old.get('capabilities',{});cap=cap if isinstance(cap,dict)else{}
        new=old|{'entry':str(HERE/'custom_service.py'),'custom_entry':str(HERE/'custom_service.py'),'capabilities':cap|{'custom_qe':True,'protocol':2},'custom_qe':True}
        save(registry,new);record['activated']=True
    save(HERE/'installation.json',record);print(json.dumps({'status':'ACTIVATED_CUSTOM_QE_EXTENSION'if a.activate else'PREPARED_CUSTOM_QE_EXTENSION','entry':str(HERE/'custom_service.py')}))
if __name__=='__main__':main()
