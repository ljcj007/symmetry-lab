"""Recompute rigorous finite-source point spectra for imported scalar NC QE.

The proof defines H exactly by the recorded binary64 T,V,beta,D and unitary
discrete Fourier compression on every exported plane-wave row. Approximate
eigenvalues/vectors propose only cuts and congruences; Arb accepts every bound.
This is not an infinite-basis, continuous-k or nonlinear SCF certificate.
SPDX-License-Identifier: GPL-3.0-or-later
"""
from pathlib import Path
from fractions import Fraction as Q
import argparse,hashlib,json,math,os,sys,time,traceback
for _n in('OMP_NUM_THREADS','MKL_NUM_THREADS','OPENBLAS_NUM_THREADS'):os.environ[_n]='1'
sys.set_int_max_str_digits(0);sys.dont_write_bytecode=True
import numpy as np
import flint
from flint import arb,acb,acb_mat,ctx
import native_reader as Native
ctx.prec=160;ctx.threads=1

def need(v,s):
    if not v:raise ValueError(s)
def R(v):
    f=Q(float(v))if isinstance(v,(float,np.floating))else Q(v)
    return arb(f.numerator)/f.denominator
def C(v):return acb(R(float(v.real)),R(float(v.imag)))
def qstr(v):return str(v.fmpq())
def adj(A):return acb_mat([[A[j,i].conjugate()for j in range(A.nrows())]for i in range(A.ncols())])
def herm(A):return(A+adj(A))/2
def mat(A):return acb_mat([[C(v)for v in row]for row in A])
def eye(n,s=1):return acb_mat([[acb(s)if i==j else acb(0)for j in range(n)]for i in range(n)])
def lower_gersh(A):
    need(A.nrows()==A.ncols()and A.nrows()>0,'Nonempty Hermitian comparison form')
    values=[]
    for i in range(A.nrows()):
        v=A[i,i].real-sum((abs(A[i,j])for j in range(A.ncols())if j!=i),arb(0))
        need(v.is_finite(),'Finite Arb Gershgorin bound');values.append(v.lower())
    return min(values,key=lambda v:v.fmpq())
def positive(A):
    numerical=np.array([[complex(A[i,j])for j in range(A.ncols())]for i in range(A.nrows())])
    need(np.isfinite(numerical).all(),'Finite proposed congruence')
    w,U=np.linalg.eigh((numerical+numerical.conj().T)/2);U=mat(U)
    lower=lower_gersh(herm(adj(U)*A*U))
    return {'certified':bool(lower>0),'lower_exact':qstr(lower),'dimension':A.nrows()}
def dft3(values,nr,inverse=False):
    n1,n2,n3=nr;a=list(values);need(len(a)==n1*n2*n3,'Full Fourier grid')
    def index(i,j,k):return i+n1*(j+n2*k)
    for k in range(n3):
        for j in range(n2):
            ids=[index(i,j,k)for i in range(n1)];v=acb.dft([a[t]for t in ids],inverse=inverse)
            for t,z in zip(ids,v):a[t]=z
    for k in range(n3):
        for i in range(n1):
            ids=[index(i,j,k)for j in range(n2)];v=acb.dft([a[t]for t in ids],inverse=inverse)
            for t,z in zip(ids,v):a[t]=z
    for j in range(n2):
        for i in range(n1):
            ids=[index(i,j,k)for k in range(n3)];v=acb.dft([a[t]for t in ids],inverse=inverse)
            for t,z in zip(ids,v):a[t]=z
    return a
def save(path,obj):path.write_text(json.dumps(obj,indent=2)+'\n',encoding='utf8')
def one(path,out,rank,max_core=512,max_grid=2097152,proposed_cuts=None):
    t0=time.monotonic();before=Native.sha(path);x=Native.read_native(path);n=x['npw'];m=x['nkb']
    need(1<=rank<x['nbnd']and rank<n,'An exported trial frame and unoccupied spectral proposal are required')
    nr=tuple(x['nr'+str(i)]for i in(1,2,3));need(nr==tuple(x['nr'+str(i)+'x']for i in(1,2,3)),'Strict proof currently requires the full unpadded serial Fourier grid')
    need(math.prod(nr)<=max_grid,'Fourier grid exceeds the rigorous proof resource guard')
    D=x['D_Ry'];need(np.array_equal(D,D.T),'Exact real symmetric nonlocal D')
    G=[tuple(map(int,v))for v in x['G']];need(len(set(G))==n,'Every exported G row must be unique')
    slots=[g[0]%nr[0]+nr[0]*(g[1]%nr[1]+nr[1]*(g[2]%nr[2]))for g in G]
    need(len(set(slots))==n and np.array_equal(np.array(slots)+1,x['fft_nl_1based']),'Exact injective full-grid carrier map')
    et=x['energies_Ry'];need(np.isfinite(et).all()and et[rank]>et[rank-1],'The proposed finite point gap is positive')
    lo,hi=Q(float(et[rank-1])),Q(float(et[rank]));a,b=proposed_cuts if proposed_cuts is not None else(lo+(hi-lo)/5,hi-(hi-lo)/5)
    need(a<b,'Strict ordered spectral cuts')
    T=[R(v)for v in x['kinetic_Ry']];pot=[acb(R(v))for v in x['local_potential_Ry']]
    vmin=min(Q(float(v))for v in x['local_potential_Ry']);vh=[v/len(pot)for v in dft3(pot,nr)]
    B=mat(x['beta'])if m else None;DM=mat(D)if m else None
    # Exact dyadic diagonal dominance proves D >= -diag(c), for arbitrary
    # signed real symmetric D. Positive channels are never assumed for a new
    # material, and the full original D remains in Hcc, Htc and H*E.
    dq=[[Q(float(D[i,j]))for j in range(m)]for i in range(m)]
    c=[max(Q(0),sum(abs(dq[i][j])for j in range(m)if j!=i)-dq[i][i])for i in range(m)]
    active=[i for i,v in enumerate(c)if v>0]
    def block(rows,cols):
        A=acb_mat(len(rows),len(cols))
        for ri,i in enumerate(rows):
            for cj,j in enumerate(cols):
                diff=tuple(G[i][t]-G[j][t]for t in range(3));slot=diff[0]%nr[0]+nr[0]*(diff[1]%nr[1]+nr[1]*(diff[2]%nr[2]))
                A[ri,cj]=vh[slot]+(T[i]if i==j else 0)
        if m:
            Br=acb_mat([[B[i,k]for k in range(m)]for i in rows]);Bc=acb_mat([[B[j,k]for k in range(m)]for j in cols]);A+=Br*DM*adj(Bc)
        return A
    # Test the full recorded source on all rank trial vectors with rigorous
    # Fourier transforms. No saved h_psi action defines the mathematical H.
    E=mat(x['frame'][:,:rank]);HE=acb_mat(n,rank)
    for j in range(rank):
        grid=[acb(0)for _ in pot]
        for i,s in enumerate(slots):grid[s]=E[i,j]
        real=dft3(grid,nr,inverse=True);rec=dft3([v*w for v,w in zip(real,pot)],nr)
        for i,s in enumerate(slots):HE[i,j]=T[i]*E[i,j]+rec[s]
    if m:HE+=B*DM*(adj(B)*E)
    negative=positive(-herm(adj(E)*(HE-E*acb(R(a)))))
    need(negative['certified'],'The full-source rank-dimensional negative subspace remains unresolved')
    tmax=max(Q(float(v))for v in x['kinetic_Ry']);start=max(Q(10),Q(math.floor(float(b-vmin)))+2)
    cuts=[]
    for step in range(16):
        cut=min(tmax,start+5*step)
        if cut not in cuts:cuts.append(cut)
        if cut==tmax:break
    attempts=[];accepted=None
    for cutoff in cuts:
        core=[i for i,v in enumerate(x['kinetic_Ry'])if Q(float(v))<=cutoff];cs=set(core);tail=[i for i in range(n)if i not in cs];nc=len(core);nt=len(tail)
        if nc<=rank:continue
        if nc>max_core:attempts.append({'corecut_Ry':str(cutoff),'core':nc,'reason':'core-resource-guard'});break
        Hcc=herm(block(core,core));schur=Hcc-eye(nc,acb(R(b)));smallproof=None
        if nt:
            dt=[T[i]+R(vmin-b)for i in tail]
            if not all(v>0 for v in dt):continue
            Htc=block(tail,core);IF=acb_mat([[Htc[i,j]/dt[i]for j in range(nc)]for i in range(nt)])
            schur-=adj(Htc)*IF
            if active:
                Z=acb_mat([[B[i,k]*R(c[k]).sqrt()for k in active]for i in tail]);IZ=acb_mat([[Z[i,j]/dt[i]for j in range(len(active))]for i in range(nt)])
                small=herm(eye(len(active))-adj(Z)*IZ);smallproof=positive(small)
                if not smallproof['certified']:attempts.append({'corecut_Ry':str(cutoff),'core':nc,'reason':'signed-tail-comparison'});continue
                cross=adj(Z)*IF;schur-=adj(cross)*small.solve(cross)
        schur=herm(schur);numeric=np.array([[complex(schur[i,j])for j in range(nc)]for i in range(nc)])
        _,U=np.linalg.eigh((numeric+numeric.conj().T)/2);Fplus=mat(U[:,rank:]);positive_core=positive(herm(adj(Fplus)*schur*Fplus))
        attempts.append({'corecut_Ry':str(cutoff),'core':nc,'positive_form_received':positive_core['certified']})
        if positive_core['certified']:
            accepted={'corecut_Ry':str(cutoff),'core':nc,'tail':nt,'signed_tail_comparison':smallproof,'positive_core':positive_core};break
    need(accepted is not None,'Complete positive-count certificate remains unresolved within the declared core resource guard')
    need(Native.sha(path)==before,'Native factors changed while certifying')
    report={'schema':'custom-QE-exact-finite-point-spectrum.v1','status':'CERTIFIED_COMPLETE_EXPORTED_FINITE_POINT_GAP','file':path.name,'source_sha256':before,'finite_point_spectrum_certified':True,'infinite_basis_certified':False,'infinite_scf_certified':False,'global_BZ_certified':False,'dimension':n,'spectral_index':rank,'negative_count_at_lower_cut':rank,'positive_count_at_upper_cut':n-rank,'cuts_Ry':[str(a),str(b)],'gap_lower_Ry':str(b-a),'gap_lower_eV':float(b-a)*Native.RY_EV,'k_inverse_bohr':x['k_inverse_bohr'].tolist(),'D_negative_comparison_exact':[str(v)for v in c],'negative_trial_form':negative,'tail_and_core':accepted,'attempts':attempts,'all_nonlocal_channels_retained_in_source':True,'precision_bits':ctx.prec,'seconds':round(time.monotonic()-t0,3),'source_definition':'Exact recorded binary64 T,V,beta,D factors; exact unitary discrete Fourier multiplication/compression on all exported G rows at this point.','theorem':'D+diag(c) is weakly diagonally dominant with nonnegative diagonal, hence PSD. Htt-b>=diag(Ttail+min(V)-b)-Btail diag(c) Btail*. Positive Woodbury comparison plus nc-r positive Schur directions gives n-r positive directions of H-b. The full source has r negative trial directions at a<b. Thus exactly r eigenvalues are below the open interval and none occur between the two strict cuts.','scope':'Complete finite exported plane-wave source at this k only. Numerical SCF convergence and native h_psi audits are separate; no native-unrounded, infinite-basis, continuous-k or nonlinear-SCF claim.'}
    save(out/(path.stem+'.json'),report);return report
def main():
    ap=argparse.ArgumentParser();ap.add_argument('--input',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);ap.add_argument('--rank',type=int,required=True);ap.add_argument('--max-core',type=int,default=512);ap.add_argument('--max-points',type=int,default=64);a=ap.parse_args();need(not a.out.exists(),'Preserve earlier results');a.out.mkdir(parents=True)
    files=sorted(a.input.glob('ncs_native_k*.bin'));need(files,'At least one complete native export');start=time.monotonic();rows=[];missing=[]
    before={p.name:Native.sha(p)for p in files};proposed_cuts=None
    candidates=[Native.read_native(path)['energies_Ry']for path in files]
    if all(1<=a.rank<len(values)for values in candidates):
        lo=max(Q(float(v[a.rank-1]))for v in candidates);hi=min(Q(float(v[a.rank]))for v in candidates)
        if lo<hi:proposed_cuts=(lo+(hi-lo)/5,hi-(hi-lo)/5)
    for path in files:
        if len(rows)+len(missing)>=a.max_points:missing.append({'file':path.name,'reason':'point-resource-guard'});continue
        try:
            row=one(path,a.out,a.rank,a.max_core,proposed_cuts=proposed_cuts);rows.append(row)
            print(json.dumps({k:row[k]for k in('file','status','dimension','seconds')}),flush=True)
        except Exception as e:
            missing.append({'file':path.name,'reason':str(e),'exception':type(e).__name__});save(a.out/(path.stem+'.UNRESOLVED.json'),missing[-1]);print(json.dumps(missing[-1]),flush=True)
    need(before=={p.name:Native.sha(p)for p in files},'All native sources unchanged')
    passed=len(rows)==len(files)and not missing
    common=None
    if passed:
        aa=max(Q(row['cuts_Ry'][0])for row in rows);bb=min(Q(row['cuts_Ry'][1])for row in rows)
        if aa<bb:common={'cuts_Ry':[str(aa),str(bb)],'gap_lower_Ry':str(bb-aa),'gap_lower_eV':float(bb-aa)*Native.RY_EV}
    result={'schema':'custom-QE-finite-spectrum-collection.v1','status':'CERTIFIED_ALL_EXPORTED_FINITE_K_POINTS'if passed else'UNRESOLVED_FINITE_POINT_SPECTRUM','finite_point_spectrum_certified':passed,'finite_kpoint_common_gap_certified':bool(common),'points_requested':len(files),'points_certified':len(rows),'spectral_index':a.rank,'rows':rows,'remaining_obligations':missing,'common_finite_point_gap':common,'infinite_scf_certified':False,'full_chain_certified':False,'full_chain_recomputed':False,'finite_proof_recomputed':True,'source_files':before,'program_sha256':Native.sha(Path(__file__)),'reader_sha256':Native.sha(Path(Native.__file__)),'flint_version':flint.__version__,'seconds':round(time.monotonic()-start,3)}
    save(a.out/'RESULTS.json',result);print(json.dumps({k:result[k]for k in('status','points_requested','points_certified','seconds')}),flush=True);return 0 if passed else 3
if __name__=='__main__':raise SystemExit(main())
