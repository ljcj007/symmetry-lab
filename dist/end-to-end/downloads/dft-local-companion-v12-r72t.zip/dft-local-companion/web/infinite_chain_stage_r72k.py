"""Run both complete energy existence and full response receivers for this QE job."""
from pathlib import Path
import argparse,os,subprocess,sys
import runner as R
from infinite_chain_stage_r72b import native_inputs

def main():
 ap=argparse.ArgumentParser();ap.add_argument('--recipe',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
 out=a.out.resolve();R.require(not out.exists(),'Fresh proof output required');out.mkdir(parents=True)
 job=Path(os.environ['DFT_PORTAL_JOB_ROOT']).resolve();state=R.load(job/'RUN.json')
 R.require(state['id']==os.environ['DFT_PORTAL_RUN_ID']and state['source_fingerprint']==os.environ['DFT_PORTAL_SOURCE_FINGERPRINT'],'Actual job context changed')
 pins={};accepted=False;root=False;response_ok=False;reason=None
 try:
  recipe=R.load(a.recipe);pins[str(a.recipe.resolve())]=R.digest(a.recipe)
  R.require(recipe.get('schema')=='registered-infinite-SCF-proof-recipe.r72k'and recipe.get('proof_kind')=='orbital-energy','Unsupported complete energy/response recipe')
  for key in ('native-dft','ionic-input'):
   row=next((s for s in state['stages']if s['id']==key and s['state']=='SUCCEEDED'),None)
   R.require(row is not None,'Required actual source stage absent: '+key)
   path=job/'stages'/key/'output/stage-receipt.json';R.require(R.digest(path)==row['receipt_pin'],'Actual source stage changed');pins[str(path)]=R.digest(path)
  native=job/'stages/native-dft/output';actual=native_inputs(native)
  for key in ('composer','contract','mathematical_input_identity','response_composer','response_contract'):
   path=R.inside(R.PAPER,recipe[key]['path']);R.require(R.digest(path)==recipe[key]['pin'],'Registered scientific source changed: '+key);pins[str(path)]=R.digest(path)
  identity=R.inside(R.PAPER,recipe['mathematical_input_identity']['path'])
  R.require(actual==R.load(identity)['files'],'This QE mathematical source differs from the theorem source')
  R.save(out/'ACTUAL_NATIVE_INPUT_IDENTITY.json',dict(status='IDENTICAL_COMPLETE_NATIVE_MATHEMATICAL_INPUTS',actual_run_id=state['id'],files=actual))
  def execute(name,keys,extra):
   command=[sys.executable,'-X','utf8','-B',str(R.inside(R.PAPER,recipe[keys[0]]['path'])),'--contract',str(R.inside(R.PAPER,recipe[keys[1]]['path'])),*extra,'--out',str(out/name)]
   with(out/(name+'.stdout')).open('xb')as fo,(out/(name+'.stderr')).open('xb')as fe:run=subprocess.run(command,stdout=fo,stderr=fe,timeout=1200)
   R.require(run.returncode==0,'The registered '+name+' checker failed')
   return R.load(out/name/'RESULTS.json')
  proof=execute('energy-proof',('composer','contract'),[])
  R.require(proof.get('schema')=='infinite-orbital-H1-energy-direct-method-existence-composition.r72b','Wrong full energy theorem output')
  root=proof.get('root_exists')is True and proof.get('fresh_source_root_exists')is True
  response=execute('response-proof',('response_composer','response_contract'),['--root-proof',str(out/'energy-proof/RESULTS.json')])
  R.require(isinstance(recipe.get('response_schema'),str)and response.get('schema')==recipe['response_schema'],'Wrong full response theorem output')
  R.require(response.get('target_identity_sha256')==proof['target_identity_sha256'],'Response and root target identities differ')
  response_ok=response.get('complete_infinite_response_invertibility_received')is True
  accepted=root and response_ok
  R.require(all(R.digest(Path(p))==h for p,h in pins.items())and native_inputs(native)==actual,'Native or proof source changed during reception')
  missing=list(proof.get('remaining_obligations',[]))+list(response.get('remaining_obligations',[]))
  reason=None if accepted else '; '.join(missing)or'Complete root or response theorem remains unresolved'
  R.save(out/'RESULTS.json',dict(status='ACCEPTED_SOURCE_BOUND_INFINITE_SCF_EXISTS_AND_FULL_RESPONSE'if accepted else'UNRESOLVED_INFINITE_SCF_AND_FULL_RESPONSE',actual_run_id=state['id'],root_exists=root,complete_response_received=response_ok,full_infinite_chain_received=accepted,reason=reason,source_and_program_pins=pins,mathematical_proof=dict(path='energy-proof/RESULTS.json',**R.digest(out/'energy-proof/RESULTS.json')),response_proof=dict(path='response-proof/RESULTS.json',**R.digest(out/'response-proof/RESULTS.json')),infinite_root_uniqueness_claimed=False,literal_unexported_QE_infinite_generator_certified=False))
 except(ValueError,KeyError,OSError,subprocess.TimeoutExpired)as exc:
  accepted=False;response_ok=False
  reason=str(exc);R.save(out/'RESULTS.json',dict(status='UNRESOLVED_INFINITE_SCF_AND_FULL_RESPONSE',root_exists=root,complete_response_received=False,full_infinite_chain_received=False,reason=reason,source_and_program_pins=pins))
 artifacts=[dict(path=p.relative_to(out).as_posix(),**R.digest(p))for p in sorted(out.rglob('*'))if p.is_file()]
 R.save(out/'stage-receipt.json',dict(schema='dft-portal-stage-receipt.v1',run_id=state['id'],source_fingerprint=state['source_fingerprint'],status='ACCEPTED'if accepted else'UNRESOLVED',reason=reason,reexecution='received_proof_composition',claims=['infinite_orbital_nonlinear_scf_root_enclosed','complete_infinite_scf_response_invertibility_enclosed']if accepted else[],artifacts=artifacts))

if __name__=='__main__':main()
