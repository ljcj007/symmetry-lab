"""Manufactured orchestration controls; no material or SCF proof is inferred."""
from pathlib import Path
import json,os,sys,uuid
HERE=Path(__file__).resolve().parent;WEB=HERE.parent
sys.path.insert(0,str(WEB))
import runner as R
import infinite_chain_stage_r72k as G

def main():
 base=WEB/'qa'/('energy-response-'+uuid.uuid4().hex[:12]);base.mkdir(parents=True)
 original_paper=R.PAPER;original_native=G.native_inputs;original_argv=sys.argv
 keys=('DFT_PORTAL_JOB_ROOT','DFT_PORTAL_RUN_ID','DFT_PORTAL_SOURCE_FINGERPRINT');saved={k:os.environ.get(k)for k in keys}
 results=[]
 try:
  for mode in ('positive','response-unresolved','late-source-change','wrong-response-target'):
   root=base/mode;root.mkdir();job=root/'job';job.mkdir();R.PAPER=root
   stages=[]
   for name in ('native-dft','ionic-input'):
    out=job/'stages'/name/'output';out.mkdir(parents=True);R.save(out/'stage-receipt.json',{'manufactured_protocol_control':True})
    stages.append(dict(id=name,state='SUCCEEDED',receipt_pin=R.digest(out/'stage-receipt.json')))
   R.save(job/'RUN.json',dict(id='manufactured-control',source_fingerprint='control-source',stages=stages))
   G.native_inputs=lambda path:{'manufactured-input':{'bytes':1,'sha256':'a'*64}}
   identity=root/'identity.json';R.save(identity,{'files':G.native_inputs(None)})
   for name in ('energy-contract.json','response-contract.json'):R.save(root/name,{'manufactured_protocol_control':True})
   energy=root/'energy.py';energy.write_text("from pathlib import Path\nimport argparse,json\np=argparse.ArgumentParser();p.add_argument('--contract');p.add_argument('--out',type=Path);a=p.parse_args();a.out.mkdir();(a.out/'RESULTS.json').write_text(json.dumps(dict(schema='infinite-orbital-H1-energy-direct-method-existence-composition.r72b',root_exists=True,fresh_source_root_exists=True,target_identity_sha256='control-target',remaining_obligations=[])),encoding='utf8')\n",encoding='utf8')
   response=root/'response.py'
   mutation="Path(a.contract).with_name('energy-contract.json').write_text('changed',encoding='utf8')\n"if mode=='late-source-change'else''
   response.write_text("from pathlib import Path\nimport argparse,json\np=argparse.ArgumentParser();p.add_argument('--contract');p.add_argument('--root-proof');p.add_argument('--out',type=Path);a=p.parse_args();a.out.mkdir()\n"+mutation+"(a.out/'RESULTS.json').write_text(json.dumps(dict(schema='manufactured-response-control',target_identity_sha256="+repr('different-target'if mode=='wrong-response-target'else'control-target')+",complete_infinite_response_invertibility_received="+repr(mode!='response-unresolved')+",remaining_obligations="+repr(['manufactured missing response']if mode=='response-unresolved'else[])+")),encoding='utf8')\n",encoding='utf8')
   def entry(p):return dict(path=p.relative_to(root).as_posix(),pin=R.digest(p))
   recipe=root/'recipe.json';R.save(recipe,dict(schema='registered-infinite-SCF-proof-recipe.r72k',proof_kind='orbital-energy',composer=entry(energy),contract=entry(root/'energy-contract.json'),mathematical_input_identity=entry(identity),response_composer=entry(response),response_contract=entry(root/'response-contract.json'),response_schema='manufactured-response-control'))
   os.environ.update(DFT_PORTAL_JOB_ROOT=str(job),DFT_PORTAL_RUN_ID='manufactured-control',DFT_PORTAL_SOURCE_FINGERPRINT='control-source')
   output=root/'actual-output';sys.argv=[str(WEB/'infinite_chain_stage_r72k.py'),'--recipe',str(recipe),'--out',str(output)];G.main()
   receipt=R.load(output/'stage-receipt.json');expected='ACCEPTED'if mode=='positive'else'UNRESOLVED';assert receipt['status']==expected
   assert (bool(receipt['claims']))==(mode=='positive')
   if mode=='late-source-change':assert not R.load(output/'RESULTS.json')['full_infinite_chain_received']
   results.append(dict(control=mode,status='PASS',actual_subprocess_outputs_preserved=True))
 finally:
  R.PAPER=original_paper;G.native_inputs=original_native;sys.argv=original_argv
  for k,v in saved.items():
   if v is None:os.environ.pop(k,None)
   else:os.environ[k]=v
 result=dict(status='PASS_MANUFACTURED_ENERGY_RESPONSE_GATE_CONTROLS',controls=results,actual_material_certificate=False,scope='Manufactured source/proof subprocess controls only, including late source mutation after successful checker flags.')
 R.save(base/'RESULTS.json',result);print(json.dumps(dict(status=result['status'],controls=len(results),actual_material_certificate=False,qa=str(base))))

if __name__=='__main__':main()
