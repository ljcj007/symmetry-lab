"""Receive the registered full H1-energy theorem for this actual native run."""
from pathlib import Path
import argparse,json,os,subprocess,sys
import runner as R
from infinite_chain_stage_r72b import native_inputs

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--recipe',type=Path,required=True);ap.add_argument('--out',type=Path,required=True);a=ap.parse_args()
    out=a.out.resolve();R.require(not out.exists(),'Fresh proof-stage output required');out.mkdir(parents=True)
    job=Path(os.environ['DFT_PORTAL_JOB_ROOT']).resolve();state=R.load(job/'RUN.json')
    R.require(state['id']==os.environ['DFT_PORTAL_RUN_ID'] and state['source_fingerprint']==os.environ['DFT_PORTAL_SOURCE_FINGERPRINT'],'Actual source job context changed')
    pins={};accepted=False;reason=None
    try:
        recipe=R.load(a.recipe);pins[str(a.recipe.resolve())]=R.digest(a.recipe)
        R.require(recipe.get('schema')=='registered-infinite-SCF-proof-recipe.r72e' and recipe.get('proof_kind')=='orbital-energy','Unsupported energy proof recipe')
        for key in ('native-dft','ionic-input'):
            row=next((s for s in state['stages']if s['id']==key and s['state']=='SUCCEEDED'),None)
            R.require(row is not None,'Required actual source stage missing: '+key)
            p=job/'stages'/key/'output/stage-receipt.json';R.require(R.digest(p)==row['receipt_pin'],'Actual source-stage receipt changed');pins[str(p)]=R.digest(p)
        native=job/'stages/native-dft/output';actual=native_inputs(native)
        for key in ('composer','contract','mathematical_input_identity'):
            path=R.inside(R.PAPER,recipe[key]['path']);R.require(R.digest(path)==recipe[key]['pin'],'Registered scientific input changed: '+key);pins[str(path)]=R.digest(path)
        identity=R.inside(R.PAPER,recipe['mathematical_input_identity']['path'])
        R.require(actual==R.load(identity)['files'],'This actual QE mathematical source differs from the theorem source')
        R.save(out/'ACTUAL_NATIVE_INPUT_IDENTITY.json',{'status':'IDENTICAL_COMPLETE_NATIVE_MATHEMATICAL_INPUTS','actual_run_id':state['id'],'files':actual})
        composer=R.inside(R.PAPER,recipe['composer']['path']);contract=R.inside(R.PAPER,recipe['contract']['path'])
        command=[sys.executable,'-X','utf8','-B',str(composer),'--contract',str(contract),'--out',str(out/'energy-proof')]
        with(out/'receiver.stdout').open('xb')as fo,(out/'receiver.stderr').open('xb')as fe:run=subprocess.run(command,stdout=fo,stderr=fe,timeout=1200)
        R.require(run.returncode==0,'The registered complete energy theorem checker failed')
        proof=R.load(out/'energy-proof/RESULTS.json')
        R.require(proof.get('schema')=='infinite-orbital-H1-energy-direct-method-existence-composition.r72b','Wrong energy theorem output')
        R.require(all(R.digest(Path(p))==h for p,h in pins.items()) and native_inputs(native)==actual,'Native or proof source changed during reception')
        accepted=proof.get('root_exists') is True and proof.get('fresh_source_root_exists') is True
        reason=None if accepted else '; '.join(proof.get('remaining_obligations',proof.get('missing_received_inequalities',[])))
        R.save(out/'RESULTS.json',{'status':'ACCEPTED_SOURCE_BOUND_INFINITE_SCF_EXISTS'if accepted else'UNRESOLVED_INFINITE_SCF_EXISTS','actual_run_id':state['id'],'root_exists':accepted,'reason':reason,'source_and_program_pins':pins,'mathematical_proof':{'path':'energy-proof/RESULTS.json',**R.digest(out/'energy-proof/RESULTS.json')},'infinite_root_uniqueness_claimed':False,'literal_unexported_QE_infinite_generator_certified':False})
    except(ValueError,KeyError,OSError,subprocess.TimeoutExpired)as exc:
        reason=str(exc);R.save(out/'RESULTS.json',{'status':'UNRESOLVED_INFINITE_SCF_EXISTS','root_exists':False,'reason':reason,'source_and_program_pins':pins})
    artifacts=[{'path':p.relative_to(out).as_posix(),**R.digest(p)}for p in sorted(out.rglob('*'))if p.is_file()]
    R.save(out/'stage-receipt.json',{'schema':'dft-portal-stage-receipt.v1','run_id':state['id'],'source_fingerprint':state['source_fingerprint'],'status':'ACCEPTED'if accepted else'UNRESOLVED','reason':reason,'reexecution':'received_proof_composition','claims':['infinite_orbital_nonlinear_scf_root_enclosed']if accepted else[],'artifacts':artifacts})

if __name__=='__main__':main()
