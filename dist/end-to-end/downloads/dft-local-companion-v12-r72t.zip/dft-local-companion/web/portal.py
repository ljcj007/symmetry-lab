"""Loopback-only web portal for explicitly registered DFT verification jobs."""
from pathlib import Path
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
import argparse
import hmac
import getpass
import json
import mimetypes
import os
import secrets
import subprocess
import sys
import threading
import urllib.parse
import webbrowser

import runner

HERE = Path(__file__).resolve().parent
STATIC = HERE / 'site'
MAX_BODY = 8192


def public_profile(profile):
    result = {k: profile.get(k) for k in ('id', 'label', 'engine', 'description', 'scope', 'target_claims', 'full_chain_kind')}
    result['stages'] = [{'id': s['id'], 'label': s['label'],
                         'configured': s.get('program') is not None,
                         'unavailable_reason': s.get('unavailable_reason'),
                         'claims': s.get('claims', [])} for s in profile.get('stages', [])]
    try:
        runner.validate_profile(profile)
        result['ready'] = bool(profile['stages'][0].get('program'))
        result['reason'] = '' if result['ready'] else profile['stages'][0]['unavailable_reason']
        if profile.get('requires_server_auth') and not os.environ.get('DFT_SSH_PASSWORD'):
            result.update(ready=False, reason='请从服务器启动入口打开本机页面，以在本机连接服务器。')
    except Exception as exc:
        result.update(ready=False, reason=str(exc))
    return result


class Portal(ThreadingHTTPServer):
    daemon_threads = True

    def __init__(self, address):
        self.capability = secrets.token_urlsafe(32)
        self.job_lock = threading.Lock()
        self.children = {}
        super().__init__(address, Handler)

    def start_job(self, profile_id):
        with self.job_lock:
            profile=runner.load(runner.profile_path(profile_id))
            runner.require(not profile.get('requires_server_auth') or bool(os.environ.get('DFT_SSH_PASSWORD')),
                           '请从服务器启动入口连接服务器；网页不接收密码。')
            for path in runner.JOBS.glob('*/RUN.json'):
                previous = runner.load(path)
                if previous.get('status') in ('RUNNING', 'QUEUED'):
                    raise RuntimeError('已有任务正在运行；请先查看该任务的状态与日志。')
            job_id = runner.create_job(profile_id)
            folder = runner.JOBS / job_id
            flags = subprocess.CREATE_NO_WINDOW if os.name == 'nt' else 0
            with (folder/'runner.stdout').open('xb') as stdout, (folder/'runner.stderr').open('xb') as stderr:
                child = subprocess.Popen([sys.executable, '-B', str(HERE/'runner.py'), 'execute', job_id],
                                         cwd=HERE, stdout=stdout, stderr=stderr, creationflags=flags,
                                         start_new_session=os.name != 'nt')
            self.children[job_id] = child
            return job_id


class Handler(BaseHTTPRequestHandler):
    server_version = 'DFTLocalPortal/1'

    def log_message(self, *_):
        pass  # Capabilities and user paths are never printed in HTTP access logs.

    def secure_request(self, *, protected=False):
        expected = '127.0.0.1:' + str(self.server.server_address[1])
        runner.require(self.headers.get('Host') == expected, 'Use the launcher-provided loopback address')
        origin = self.headers.get('Origin')
        runner.require(not origin or origin == 'http://' + expected, 'Cross-origin access is refused')
        if protected:
            actual = self.headers.get('X-DFT-Portal-Capability', '')
            runner.require(hmac.compare_digest(actual, self.server.capability),
                           '请从本机启动入口打开此页面，再执行计算。')

    def send_data(self, status, body, content_type='application/json; charset=utf-8', extra=None):
        self.send_response(status)
        self.send_header('Content-Type', content_type)
        self.send_header('Content-Length', str(len(body)))
        self.send_header('Cache-Control', 'no-store')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')
        self.send_header('Cross-Origin-Resource-Policy', 'same-origin')
        self.send_header('Content-Security-Policy', "default-src 'self'; script-src 'self'; style-src 'self'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'; form-action 'self'")
        for key, value in (extra or {}).items():
            self.send_header(key, value)
        self.end_headers()
        self.wfile.write(body)

    def json(self, status, value):
        self.send_data(status, json.dumps(value, ensure_ascii=False).encode('utf8'))

    def do_GET(self):
        try:
            self.secure_request()
            url = urllib.parse.urlsplit(self.path)
            if not url.path.startswith('/api/'):
                name = url.path.lstrip('/') or 'index.html'
                file = runner.inside(STATIC, urllib.parse.unquote(name))
                runner.require(file.is_file() and file.suffix in ('.html', '.css', '.js', '.svg'), 'Unsupported static asset')
                types={'.html':'text/html','.js':'application/javascript','.css':'text/css','.svg':'image/svg+xml'}
                self.send_data(200, file.read_bytes(), types[file.suffix] + '; charset=utf-8')
                return
            self.secure_request(protected=True)
            if url.path == '/api/profiles':
                profiles = []
                for file in sorted(runner.PROFILES.glob('*.json')):
                    try:
                        profile = runner.load(file)
                        if not profile.get('hidden', False):
                            profiles.append(public_profile(profile))
                    except Exception as exc:
                        profiles.append({'id': file.stem, 'label': file.stem, 'ready': False, 'reason': str(exc), 'stages': []})
                self.json(200, {'profiles': profiles, 'claim_labels': runner.CLAIMS})
                return
            if url.path == '/api/jobs':
                jobs = [runner.load(f) for f in runner.JOBS.glob('*/RUN.json')]
                jobs = [job for job in jobs if job.get('engine') != 'control']
                jobs.sort(key=lambda x: x['created_at'], reverse=True)
                self.json(200, {'jobs': jobs[:100]})
                return
            parts = url.path.strip('/').split('/')
            runner.require(len(parts) in (3, 4) and parts[:2] == ['api', 'jobs'], 'Unknown API route')
            job_id = parts[2]
            runner.require(runner.ID.fullmatch(job_id) is not None, 'Invalid job identifier')
            folder = runner.inside(runner.JOBS, job_id)
            state = runner.load(folder/'RUN.json')
            if len(parts) == 3:
                self.json(200, state)
            elif parts[3] == 'report':
                self.send_data(200, json.dumps(state, ensure_ascii=False, indent=2).encode('utf8'),
                               extra={'Content-Disposition': 'attachment; filename="' + job_id + '-run.json"'})
            elif parts[3] == 'log':
                query = urllib.parse.parse_qs(url.query)
                runner.require(set(query) <= {'stage', 'stream', 'offset'}, 'Unknown log option')
                stage_id = query.get('stage', [''])[0]
                stream = query.get('stream', ['stdout'])[0]
                runner.require(stage_id in {s['id'] for s in state['stages']}, 'Unknown stage')
                runner.require(stream in ('stdout', 'stderr'), 'Unknown log stream')
                offset = int(query.get('offset', ['0'])[0])
                runner.require(0 <= offset <= 2**53, 'Invalid log offset')
                file = folder/'stages'/stage_id/(stream+'.log')
                data = b''
                if file.is_file():
                    with file.open('rb') as handle:
                        handle.seek(offset)
                        data = handle.read(65536)
                self.json(200, {'text': data.decode('utf8', errors='replace'), 'next_offset': offset+len(data)})
            else:
                raise ValueError('Unknown API route')
        except (ValueError, KeyError, FileNotFoundError) as exc:
            self.json(403 if 'origin' in str(exc).lower() or '启动入口' in str(exc) or 'loopback' in str(exc) else 400,
                      {'error': str(exc)})

    def do_POST(self):
        try:
            self.secure_request(protected=True)
            runner.require(self.path == '/api/jobs', 'Unknown API route')
            length = int(self.headers.get('Content-Length', '-1'))
            runner.require(0 <= length <= MAX_BODY, 'Request is too large')
            runner.require(self.headers.get('Content-Type', '').split(';')[0] == 'application/json', 'Use JSON')
            body = json.loads(self.rfile.read(length))
            runner.require(isinstance(body, dict), 'Use a JSON object')
            runner.require(set(body) == {'profile_id'}, 'Only a registered profile can be submitted')
            job_id = self.server.start_job(body['profile_id'])
            self.json(201, {'id': job_id})
        except RuntimeError as exc:
            self.json(409, {'error': str(exc)})
        except (ValueError, KeyError, FileNotFoundError) as exc:
            self.json(400, {'error': str(exc)})


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--port', type=int, default=4329)
    parser.add_argument('--open', action='store_true')
    password_mode=parser.add_mutually_exclusive_group()
    password_mode.add_argument('--ssh-password-stdin', action='store_true')
    password_mode.add_argument('--ask-ssh-password', action='store_true')
    args = parser.parse_args()
    if args.ssh_password_stdin:
        password=sys.stdin.readline().rstrip('\r\n')
        runner.require(bool(password),'No SSH password was provided on the local launcher input')
        os.environ['DFT_SSH_PASSWORD']=password
        password=None
    elif args.ask_ssh_password and not os.environ.get('DFT_SSH_PASSWORD'):
        password=getpass.getpass('SSH password (local process only): ')
        runner.require(bool(password),'An SSH password is required for the server profile')
        os.environ['DFT_SSH_PASSWORD']=password
        password=None
    runner.require(0 <= args.port <= 65535, 'Invalid port')
    runner.JOBS.mkdir(exist_ok=True)
    runner.PROFILES.mkdir(exist_ok=True)
    server = Portal(('127.0.0.1', args.port))
    url = 'http://127.0.0.1:' + str(server.server_address[1]) + '/#cap=' + server.capability
    print('Local portal (keep this local launcher URL private): ' + url, flush=True)
    print('Closing this window stops the web portal. Started jobs retain their own logs and runner process.', flush=True)
    if args.open:
        webbrowser.open(url)
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == '__main__':
    main()
