"""Operator-side registration. No browser-supplied commands or credentials."""
import argparse
import json
from pathlib import Path
import sys
import runner as R


def code_pin(path):
    return {'path':path.relative_to(R.PAPER).as_posix(),**R.digest(path)}


def main():
    p=argparse.ArgumentParser()
    p.add_argument('--id',required=True)
    p.add_argument('--label',required=True)
    p.add_argument('--engine',choices=['qe','vasp'],required=True)
    p.add_argument('--mode',choices=['intake','run','ssh-run'],default='intake')
    p.add_argument('--chain',choices=['source','source-ionic','reference','infinite'],default='source')
    p.add_argument('--proof-recipe',help='Registered proof recipe filename inside the explicit source root')
    p.add_argument('--source-root',required=True)
    p.add_argument('--inputs-json',type=Path,required=True)
    p.add_argument('--python',default=sys.executable)
    p.add_argument('--executable')
    p.add_argument('--qe-input',default='pw.in')
    p.add_argument('--ssh-config',default='server_profile.json')
    p.add_argument('--timeout',type=int,default=1800)
    a=p.parse_args()
    source=Path(a.source_root).resolve()
    R.require(source.is_relative_to(R.PAPER),'Source must stay inside paper')
    inputs=R.load(a.inputs_json.resolve())
    native=R.HERE.parent/'native'
    driver=native/'raw_dft.py'
    R.require(driver.is_file(),'Actual native driver is absent')
    R.require(a.mode!='ssh-run' or a.engine=='qe','SSH native path supports QE only')
    R.require(a.chain!='reference' or a.mode=='ssh-run','Reference chain requires the fresh complete72 SSH source bridge')
    action='intake' if a.mode=='intake' else 'run-ssh-qe' if a.mode=='ssh-run' else 'run-'+a.engine
    argv=[action,'--engine',a.engine,'--source-root','{source_root}','--inputs-json','{input_list}','--out','{stage_output}']
    claim='raw_source_intake' if a.mode=='intake' else 'native_dft_executed'
    fresh_scf=False
    if a.mode=='ssh-run':
        cfg=R.load(R.inside(source,a.ssh_config))
        fresh_scf='scfInput' in cfg
        R.require(not fresh_scf or 'scfExecutable' in cfg, 'Fresh SCF needs an explicit executable')
        R.inside(source,a.ssh_config)
        R.require(a.ssh_config in inputs,'Nonsecret SSH config must occur in the explicit source manifest')
        argv+=['--ssh-config',str(source/a.ssh_config),'--timeout',str(a.timeout)]
    elif a.mode=='run':
        argv+=['--qe-input',a.qe_input,'--timeout',str(a.timeout)]
        if a.executable:argv+=['--executable',a.executable]
    dependency_names=['qe_native_adapter.py','ssh_qe.py','fresh_native_remote.py','fresh_scf_remote_v1.py','unmixed_input_remote.py','receive_fresh_remote.py']
    dependencies=[code_pin(native/name) for name in dependency_names if (native/name).is_file()]
    first={'id':'raw-intake' if a.mode=='intake' else 'native-dft',
           'label':'原生源接收' if a.mode=='intake' else '全新数值 SCF、非自洽导出与源接收' if fresh_scf else '已有 SCF 父源的 '+a.engine.upper()+' 非自洽导出与源接收' if a.mode=='ssh-run' else '实际原生 '+a.engine.upper()+' 计算与源接收',
           'program':driver.relative_to(R.PAPER).as_posix(),'program_pin':R.digest(driver),
           'dependencies':dependencies,'arguments':argv,'timeout_seconds':a.timeout+30,
           'receipt':'stage-receipt.json','claims':[claim]+(['native_scf_executed'] if fresh_scf else []),
           'optional_claims':['raw_source_intake','operator_identity_bridge'] if a.mode=='ssh-run' else ['raw_source_intake'] if a.mode=='run' else []}
    stages=[first]
    if a.chain in ('source-ionic','infinite'):
        R.require(a.mode=='ssh-run' and cfg.get('exportUnmixedInputState') is True,
                  'The ionic chain needs an actual unmixed input-state export')
        receiver=R.PAPER/'work/infinite_scf_20261121/math/proof_closure_20261122/receive_ionic_input_bridge_v2.py'
        wrapper=R.HERE/'source_chain_stage.py'
        fixed=[R.HERE/'runner.py',receiver,
               R.PAPER/'work/qe_si_end_to_end_20261117/scf_validation/decode_scf_stream.py']
        stages.append({'id':'ionic-input','label':'原始输入势独立解码及离子势衔接',
                       'program':wrapper.relative_to(R.PAPER).as_posix(),'program_pin':R.digest(wrapper),
                       'dependencies':[code_pin(f) for f in fixed],
                       'arguments':['--out','{stage_output}'],'timeout_seconds':600,
                       'receipt':'stage-receipt.json','claims':['ionic_input_source_bridge_enclosed']})
    if a.chain=='infinite':
        R.require(fresh_scf and a.proof_recipe in inputs,'The infinite chain needs fresh SCF and an explicit source-pinned proof recipe')
        recipe_path=R.inside(source,a.proof_recipe);recipe=R.load(recipe_path)
        complete_response=recipe.get('schema')=='registered-infinite-SCF-proof-recipe.r72k'
        energy=recipe.get('schema')in ('registered-infinite-SCF-proof-recipe.r72e','registered-infinite-SCF-proof-recipe.r72k') and recipe.get('proof_kind')=='orbital-energy'
        R.require(energy or recipe.get('schema')=='registered-infinite-SCF-proof-recipe.r72b','Unsupported infinite proof recipe')
        wrapper=R.HERE/('infinite_chain_stage_r72k.py'if complete_response else'infinite_chain_stage_r72e.py' if energy else 'infinite_chain_stage_r72b.py')
        dependencies=[R.HERE/'runner.py',native/'raw_dft.py',native/'qe_native_adapter.py']
        if energy:dependencies.append(R.HERE/'infinite_chain_stage_r72b.py')
        if complete_response:
            R.require(isinstance(recipe.get('response_schema'),str)and recipe['response_schema'],'Complete response schema required')
            for key in ('response_composer','response_contract'):
                path=R.inside(R.PAPER,recipe[key]['path']);R.require(R.digest(path)==recipe[key]['pin'],'Registered complete response input changed');dependencies.append(path)
        for key in ['composer','contract','mathematical_input_identity']:
            path=R.inside(R.PAPER,recipe[key]['path'])
            R.require(R.digest(path)==recipe[key]['pin'],'Registered mathematical input or receiver changed: '+key)
            dependencies.append(path)
        if energy:
            contract=R.load(R.inside(R.PAPER,recipe['contract']['path']))
            for stage in contract.get('stages',{}).values():
                if stage and stage.get('receipt'):
                    path=Path(stage['receipt']).resolve()
                    R.require(path.is_relative_to(R.PAPER) and R.digest(path)['sha256']==stage['sha256'],'Energy theorem stage identity changed')
                    dependencies.append(path)
        for key in ('all72_map','full_response','whole_ball','fresh_source_bridge'):
            record=recipe.get(key)
            if record is not None:
                path=R.inside(R.PAPER,record['path']);R.require(R.digest(path)==record['pin'],'Registered science receipt changed');dependencies.append(path)
        stages.append({'id':'infinite-scf','label':'全 72 点、完整响应与整球自洽证书接收',
                       'program':wrapper.relative_to(R.PAPER).as_posix(),'program_pin':R.digest(wrapper),
                       'dependencies':[code_pin(f) for f in dependencies],
                       'arguments':['--recipe',str(recipe_path),'--out','{stage_output}'],'timeout_seconds':1800,
                       'receipt':'stage-receipt.json','claims':['infinite_orbital_nonlinear_scf_root_enclosed']+(['complete_infinite_scf_response_invertibility_enclosed']if complete_response else[])})
    if a.chain=='reference':
        wrapper=R.HERE/'reference_chain_stage.py'
        task=R.PAPER/'work/qe_si_end_to_end_20261117'
        fixed=[R.HERE/'runner.py',native/'raw_dft.py',native/'qe_native_adapter.py',
               task/'root/verify_native72_canonical_ideal_bridge.py',
               task/'source_rounding/source_adapter.py',task/'source_rounding/verify_source_rounding.py',
               task/'scf_validation/C1_center/finalize_reference_scf_v1.py',
               task/'scf_validation/C1_center/aggregate_susceptibility_v3.py',
               task/'scf_validation/C1_center/compose_finite_scf_certificate.py',
               task/'scf_high_modes/receive_center_inverse.py',task/'scf_high_modes/strict_real_matrix_tools.py',
               task/'root/compose_scf_frozen_global_gap.py']
        specifications=[
            ('construction-rounding','72 点完整算符构造与舍入接收','construction',['construction_rounding_enclosed'],3600),
            ('finite-scf','72 点汇总、完整逆矩阵与有限自洽根','finite-scf',['finite_reference_scf_root_enclosed'],1800),
            ('frozen-spectrum','同势无限冻结谱（接收 925 域证明）','frozen-spectrum',['infinite_basis_tail_enclosed','same_potential_infinite_global_gap'],1800)]
        for stage_id,label,action,claims,budget in specifications:
            stages.append({'id':stage_id,'label':label,'program':wrapper.relative_to(R.PAPER).as_posix(),
                           'program_pin':R.digest(wrapper),'dependencies':[code_pin(f) for f in fixed],
                           'arguments':[action,'--out','{stage_output}'],'timeout_seconds':budget,
                           'receipt':'stage-receipt.json','claims':claims})
        stages.append({'id':'nonlinear-scf','label':'无限轨道非线性自洽根','program':None,
                       'claims':['infinite_orbital_nonlinear_scf_root_enclosed'],
                       'unavailable_reason':'尚未有本次源对应的无限轨道非线性自洽根接收器；有限根与冻结谱不替代此目标。'})
    scope='仅接收登记的原生执行或源结构，不据此证明构造误差、谱尾项或自洽根。'
    if a.chain=='source-ionic':scope='实际重算 QE、导出并独立接收原始输入态离子势；此配置的终点为源衔接。'
    if a.chain=='infinite':scope='实际重算 QE 并验证完整原生数学输入身份，再运行登记的无限轨道闭合接收器。目标为固定48³电荷网格、规范72点求积和明确的UPF节点C¹延拓；缺少严格整球闭合时返回未完成。'
    if a.chain=='reference':scope='参考链固定 80 Ry、48³ 电荷网格、规范 12³ k 求积和指定 C¹/PBE。无限轨道非线性自洽根另行接收；缺少时保留未完成。'
    profile={'schema':'dft-portal-profile.v1','id':a.id,'label':a.label,'engine':a.engine,
             'source_root':source.relative_to(R.PAPER).as_posix(),'inputs':inputs,
             'python_executable':str(Path(a.python).resolve()),'requires_server_auth':a.mode=='ssh-run','fresh_scf_requested':fresh_scf,
             'description':('从原子初猜实际求解新 SCF，再执行 Γ 与 72 点非自洽原生导出；改变的算符源不能继承旧证明。' if fresh_scf else '从已有 SCF 父源重新执行非自洽原生导出；每次新建任务，保留原始日志和证据。' if a.mode=='ssh-run' else '实际执行登记的计算与科学接收器；每次新建任务，保留原始日志和证据。'),
             'scope':scope,'full_chain_kind':'infinite' if a.chain=='infinite' else 'reference',
             'target_claims':R.INFINITE_CHAIN if a.chain=='infinite' else R.FULL_CHAIN if a.chain=='reference' else [claim,'ionic_input_source_bridge_enclosed'] if a.chain=='source-ionic' else [claim],'stages':stages}
    if a.chain=='infinite'and complete_response:profile['target_claims']=[*profile['target_claims'],'complete_infinite_scf_response_invertibility_enclosed']
    R.validate_profile(profile)
    target=R.profile_path(a.id)
    R.require(not target.exists(),'Choose a new profile identifier; previous profiles are retained')
    target.parent.mkdir(exist_ok=True)
    with target.open('x',encoding='utf8',newline='\n') as stream:
        json.dump(profile,stream,ensure_ascii=False,indent=2);stream.write('\n')
    print(json.dumps({'status':'REGISTERED','profile':a.id,'chain':a.chain,'full_chain_certified':False},ensure_ascii=False))


if __name__=='__main__':main()
